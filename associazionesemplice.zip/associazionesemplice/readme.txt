=== Associazione Semplice ===
Contributors: wegastudios
Tags: nonprofit, members, membership, association, accounting
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.3.25
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Members, events and courses, and a cash book for small Italian non-profit associations (APS and other third-sector entities).

== Description ==

Associazione Semplice helps a small association keep members, activities and accounts in order directly from its own WordPress site. Optional features are off at first: a guided setup asks a few questions and turns on only what is needed.

The plugin is built around Italian third-sector rules (APS, ETS, registers, tax rules), so its interface and texts are in Italian. An English text pack is included and can be selected in the settings, and further language packs can be uploaded as CSV, Excel or JSON files; the plugin does not use the WordPress translation files.

* **Member register**: member records, one membership fee (with an option for founding members), QR membership cards, guests, import from CSV or Excel files, export of the register.
* **Courses and events**: registrations, limited seats with a waiting list, a payment grace period for bank transfer and cash, participant lists, a calendar.
* **Cash book**: income and expenses in a single cash account, bank transfer details for members, export of the cash book.
* **Registers and privacy**: minutes book, privacy notice, consents, anonymisation, personal data download.
* **Members' area** on the site, with notices, the rules to accept, the card and the events and courses, through shortcodes, blocks and Elementor widgets.
* **Roles**: president, vice president, treasurer, councillors and secretary, with separate permissions.
* **Donations with PayPal**: a form that takes the donor to PayPal's own donation page.
* **Backup and reset**: download a full copy of the data; reset the data to start over.
* Works with WP All Import and Elementor if you use them.

Advanced features (online payments, several accounts and funds, accounting and reports, mass emails, app and wallet cards, receipts, VAT) are in the separate Associazione Semplice Pro add-on.

== External services ==

The plugin works fully on its own. This copy, downloaded from associazionesemplice.it, contacts the Associazione Semplice website to look for updates (first item below). The optional features that involve a third party are described after it.

= Updates from the associazionesemplice.it website (only in the copy downloaded from associazionesemplice.it) =
This copy of the plugin was downloaded from https://associazionesemplice.it, not from WordPress.org. To offer updates in Dashboard - Updates, it asks that website for the latest version: it sends a request to https://associazionesemplice.it/api/plugin/update, at most every 12 hours or more (24 hours by default; Settings - Limits and thresholds lets you choose from 12 to 168 hours), even without a license key, and never from local development sites (localhost, IP addresses, .local, .test and similar). The request contains only the product name ("free") and the installed plugin version. It does not contain a license key, a domain name or any member or association data. As with any web request, the website receives the IP address of your server and the standard WordPress User-Agent, which includes your site address. When you press Update, the plugin asks the website again for the update package, which is signed and checked before it is installed. You can turn this off in Settings - Limits and thresholds (the option "Direct updates of Associazione Semplice and of Pro"): nothing is then sent, and updates must be downloaded from the customer area and uploaded by hand. If the Associazione Semplice Pro add-on is active, the request also carries its license key and your domain name, as described in the readme of that add-on. This website is run by the plugin's authors. The copy of the plugin distributed on WordPress.org does not contain this feature, never contacts that website and is updated by WordPress.org.

= PayPal donations (optional) =
If you turn on donations, your website shows a form whose button opens PayPal's donation page (www.paypal.com/donate) in the visitor's browser, with the PayPal account, the purpose and the chosen amount you set. Nothing is sent from your server to PayPal. Terms: https://www.paypal.com/legalhub - Privacy: https://www.paypal.com/privacy

= Google Places search (optional) =
If you turn on place search and enter your own Google Maps API key, the "Location" fields of courses and events in the administration screens load Google's script (maps.googleapis.com) and show place suggestions while you type. The text typed in the field is sent to Google from the administrator's browser; no member data is sent. Off by default. Terms: https://cloud.google.com/maps-platform/terms - Privacy: https://policies.google.com/privacy

== Installation ==

1. Upload the `associazionesemplice` folder to `/wp-content/plugins/`, or install the plugin from the Plugins screen.
2. Activate it from the Plugins screen.
3. Follow the guided setup that opens on first activation (it can be started again from the Tools menu).

== Frequently Asked Questions ==

= What happens to the data if I delete the plugin? =
By default it stays. In the settings you can choose to delete it permanently when the plugin is deleted.

= Can I import my existing member list? =
Yes, from a CSV or Excel file, with a preview before confirming.

= Where do the donations go? =
Straight to the PayPal account you enter in the settings. They are recorded in the cash book by hand.

== Credits ==

The interface uses the Montserrat typeface (SIL Open Font License 1.1, copy in `assets/fonts/OFL.txt`) and icons from Lucide (ISC license, https://lucide.dev), both bundled with the plugin; nothing is loaded from external servers.

== Changelog ==

= 1.3.25 =
* Prima di aggiornare fai una copia di sicurezza. Dopo l'aggiornamento: 1) inserisci email e telefono della segreteria e i dati dell'associazione che la banda gialla in alto ti chiede (forma, codice fiscale, sede, RUNTS, PEC, partita IVA: se l'associazione non ce l'ha, spunta «non ce l'ha»); 2) in Impostazioni → Copia di sicurezza premi «Cifra i file già caricati»: i file nuovi si salvano già cifrati, quelli vecchi si cifrano da quel momento; 3) nella stessa pagina trovi la frase che riapre i documenti: conservala fuori dal sito.
* Quota doppia: la prima nota rifiuta una seconda quota dello stesso anno e lo spiega; due incassi insieme non registrano due volte; annullando un incasso la tessera si toglie solo se non ce ne sono altri validi
* Contatti della segreteria obbligatori: email e telefono vanno inseriti; finché mancano, la segreteria non può inviare messaggi ai soci a mano (gli invii automatici, come il link di accesso, partono lo stesso); i messaggi riportano i contatti e le risposte arrivano alla segreteria
* Dati dell'associazione obbligatori: forma, codice fiscale, sede, numero RUNTS, PEC e partita IVA, ognuno con la casella «non ce l'ha»; il legale rappresentante è la persona con la carica di presidente; una banda gialla in alto elenca cosa manca, con il pulsante «Completali ora»
* File riservati cifrati (documenti e scansioni, allegati dei movimenti, foto dell'inventario) con una frase per riaprirli e il foglio stampabile; la copia di sicurezza porta i file cifrati. Protegge da chi porta via la sola cartella dei file; per una protezione più alta scegli una frase tua e lunga
* Cartella dei file riservati: ogni settimana il programma controlla che non sia raggiungibile da internet e avvisa l'amministratore; la cartella si può tenere fuori dalla parte pubblica del sito e «Sposta i file» copia e controlla prima di cancellare
* Ripristino della copia più sicuro: le copie sono firmate e una copia modificata viene rifiutata; una copia fatta su un altro sito si ripristina solo con una conferma scritta e la password; soci e prima nota si ripristinano anche se manca la frase; le password dei soci non fanno parte del ripristino (i soci rientrano con il link). Dopo un cambio dei codici di sicurezza le copie fatte prima chiedono la conferma per altro sito
* Le pagine riservate ai soci non vengono salvate dalla cache delle pagine
* Più sicurezza su file temporanei e lavori simultanei (chiavi, numerazione)
* Le copie di sicurezza e i file CSV si aprono bene in Excel (accenti corretti)
* Più messaggi e frasi con numeri anche in inglese
* Il rendiconto e la prima nota non cambiano: nessuna modifica ai dati contabili.

= 1.3.24 =
* La tessera segue l'anno sociale: l'etichetta è «2026» oppure «2026/2027», e negli ultimi giorni prima della scadenza si può rinnovare in anticipo; se cambi il mese, vale solo per le tessere nuove
* Anno sociale e anno fiscale si scelgono subito all'installazione, al primo passo della procedura guidata
* Il mese dell'anno fiscale si blocca alla prima chiusura, anche se poi l'anno viene riaperto
* I verbali hanno un numero fisso che non cambia mai
* Assemblee, votazioni e verbali di un anno fiscale chiuso non si modificano più
* Il nome e il tipo di un conto con movimenti in un anno fiscale chiuso non si cambiano
* La pagina «Esercizi» si chiama ora «Anni fiscali» e i testi parlano di «anno fiscale», «bozza» e «definitivo»
* Quando un anno fiscale è chiuso i messaggi sono più chiari: si riapre dalla pagina «Anni fiscali», ma solo l'ultimo


Le versioni precedenti sono nel file CHANGELOG.md del plugin.
