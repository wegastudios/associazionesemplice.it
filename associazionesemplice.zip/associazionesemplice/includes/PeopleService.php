<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/**
 * Soci, ospiti e tessere. Ogni socio (fondatore, ordinario, volontario) corrisponde a un utente
 * WordPress (email obbligatoria); l'ospite è una persona collegata al socio che lo ospita.
 * Gli errori di regola sono \InvalidArgumentException con un messaggio mostrabile all'utente.
 */
class PeopleService {

	private function db(): \wpdb {
		return Db::db();
	}

	// ---------- Lettura ----------

	public function get( int $id ): ?array {
		$row = $this->db()->get_row( $this->db()->prepare( 'SELECT * FROM ' . Db::t( 'people' ) . ' WHERE id = %d AND deleted_at IS NULL', $id ), ARRAY_A );
		return $row ?: null;
	}

	public function full_name( array $p ): string {
		return trim( $p['first_name'] . ' ' . $p['last_name'] );
	}

	public function find_by_card( string $card, ?int $except_id = null ): ?array {
		$row = $this->db()->get_row(
			$this->db()->prepare( 'SELECT * FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND UPPER(card_number) = UPPER(%s) AND id <> %d LIMIT 1', $card, (int) $except_id ),
			ARRAY_A
		);
		return $row ?: null;
	}

	public function find_by_email( string $email, ?int $except_id = null ): ?array {
		$row = $this->db()->get_row(
			$this->db()->prepare( 'SELECT * FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND email = %s AND id <> %d LIMIT 1', strtolower( trim( $email ) ), (int) $except_id ), // le email si salvano in minuscolo: il confronto usa l'indice
			ARRAY_A
		);
		return $row ?: null;
	}

	/** Prossimo numero libero: massimo tra le tessere puramente numeriche + 1. */
	public function next_free_card(): string {
		$cards = $this->db()->get_col( 'SELECT card_number FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND card_number IS NOT NULL' );
		$max   = 0;
		foreach ( $cards as $c ) {
			if ( ctype_digit( trim( $c ) ) ) {
				$max = max( $max, (int) $c );
			}
		}
		return (string) ( $max + 1 );
	}

	/**
	 * @param array $f type, q (testo libero), status (active|expired), host_id
	 * @return array[] righe con 'active_until' (ultimo giorno di validità della tessera) e 'host_name'
	 */
	public function search( array $f = array() ): array {
		$db    = $this->db();
		$today = Db::today();
		$where = array( 'p.deleted_at IS NULL', 'p.anonymized_at IS NULL' ); // le persone anonimizzate non compaiono più negli elenchi
		if ( empty( $f['applications'] ) ) {
			$where[] = 'p.application_status IS NULL'; // chi ha chiesto di aderire e non è ancora stato approvato non è nell'anagrafica
		} else {
			$where[] = 'p.application_status = \'requested\'';
		}
		$args  = array( $today, $today, $today ); // tre volte: serve alla scadenza della tessera (vedi active_until)
		if ( ! empty( $f['type'] ) ) {
			$where[] = 'p.type = %s';
			$args[]  = $f['type'];
		}
		if ( ! empty( $f['host_id'] ) ) {
			$where[] = 'p.host_person_id = %d';
			$args[]  = (int) $f['host_id'];
		}
		if ( isset( $f['q'] ) && '' !== trim( $f['q'] ) ) {
			$like    = '%' . $db->esc_like( trim( $f['q'] ) ) . '%';
			$where[] = '(p.first_name LIKE %s OR p.last_name LIKE %s OR CONCAT(p.first_name, " ", p.last_name) LIKE %s OR CONCAT(p.last_name, " ", p.first_name) LIKE %s OR p.card_number LIKE %s OR p.email LIKE %s OR p.tax_code LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like, $like, $like );
		}
		$sql = 'SELECT p.*, '
			. '(SELECT MAX(m.valid_to) FROM ' . Db::t( 'memberships' ) . ' m WHERE m.person_id = p.id AND m.deleted_at IS NULL AND (m.valid_from <= %s OR EXISTS (SELECT 1 FROM ' . Db::t( 'memberships' ) . ' c WHERE c.person_id = p.id AND c.deleted_at IS NULL AND c.valid_from <= %s AND c.valid_to >= %s))) AS active_until, '
			. 'CONCAT(h.first_name, " ", h.last_name) AS host_name '
			. 'FROM ' . Db::t( 'people' ) . ' p LEFT JOIN ' . Db::t( 'people' ) . ' h ON h.id = p.host_person_id '
			. 'WHERE ' . implode( ' AND ', $where ) . ' ORDER BY p.last_name, p.first_name';
		$rows = $db->get_results( $db->prepare( $sql, $args ), ARRAY_A ) ?: array();

		if ( ! empty( $f['status'] ) ) {
			$rows = array_values(
				array_filter(
					$rows,
					function ( $r ) use ( $f, $today ) {
						if ( 'norules' === $f['status'] ) {
							return Regulation::applies_to( $r ) && ! Regulation::accepted( $r );
						}
						if ( 'noconsent' === $f['status'] ) {
							return empty( $r['privacy_consent_at'] );
						}
						if ( ! MemberType::is_member( $r['type'] ) && 'noaccess' !== $f['status'] ) {
							return false; // ospiti e genitori/tutori non hanno la tessera
						}
						if ( MemberType::GUEST === $r['type'] ) {
							return false;
						}
						if ( 'noaccess' === $f['status'] ) {
							return empty( $r['wp_user_id'] );
						}
						if ( 'suspended' === $f['status'] ) {
							return ! empty( $r['suspended_at'] );
						}
						$active = ! empty( $r['active_until'] ) && $r['active_until'] >= $today;
						return 'active' === $f['status'] ? $active : ! $active;
					}
				)
			);
		}
		return $rows;
	}

	public function guests_of( int $member_id ): array {
		return $this->search( array( 'host_id' => $member_id ) );
	}

	/** I minori (e i ragazzi ancora collegati) di cui il socio è tutore. */
	public function dependents_of( int $guardian_id ): array {
		return Guardians::dependents_of( $guardian_id );
	}

	/** Chi un socio gestisce dalla sua area: i suoi ospiti e le persone di cui è tutore. */
	public function managed_by( int $member_id ): array {
		return array_merge( $this->guests_of( $member_id ), $this->dependents_of( $member_id ) );
	}

	/**
	 * Fino a quando vale la tessera: la scadenza PIÙ LONTANA tra le tessere del socio. Se oggi è in regola e ha già pagato anche l'anno dopo,
	 * la scadenza è la fine di quell'anno. Se non è in regola, conta l'ultima tessera già iniziata (le future da sole non lo rendono socio in regola).
	 */
	public function active_until( int $person_id, ?string $date = null ): ?string {
		$date = $date ?? Db::today();
		$v    = $this->db()->get_var(
			$this->db()->prepare(
				'SELECT MAX(m.valid_to) FROM ' . Db::t( 'memberships' ) . ' m WHERE m.person_id = %d AND m.deleted_at IS NULL AND (m.valid_from <= %s OR EXISTS (SELECT 1 FROM ' . Db::t( 'memberships' ) . ' c WHERE c.person_id = m.person_id AND c.deleted_at IS NULL AND c.valid_from <= %s AND c.valid_to >= %s))',
				$person_id,
				$date,
				$date,
				$date
			)
		);
		return $v ?: null;
	}

	public function is_active_member( int $person_id, ?string $date = null ): bool {
		if ( $this->is_suspended( $person_id ) ) {
			return false; // un socio sospeso è inattivo anche con la tessera valida
		}
		$date  = $date ?? Db::today();
		$until = $this->active_until( $person_id, $date );
		return null !== $until && $until >= $date;
	}

	// ---------- Consiglio direttivo ----------

	/** Soci con una carica: presidente, poi vicepresidente, poi consiglieri. Ognuno con 'in_regola' (tessera valida e non sospeso). */
	public function board(): array {
		$rows = $this->db()->get_results( 'SELECT * FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND board_role IS NOT NULL AND board_role <> \'\' ORDER BY last_name, first_name', ARRAY_A ) ?: array();
		$order = array_flip( array_keys( BoardRole::labels() ) );
		foreach ( $rows as &$r ) {
			$r['in_regola'] = $this->is_active_member( (int) $r['id'] );
		}
		unset( $r );
		usort(
			$rows,
			function ( $a, $b ) use ( $order ) {
				return ( $order[ $a['board_role'] ] ?? 9 ) <=> ( $order[ $b['board_role'] ] ?? 9 );
			}
		);
		return $rows;
	}

	/**
	 * Assegna (o toglie, con null) una carica. Solo soci fondatori e ordinari in regola; i posti sono limitati (1 presidente, 1 vicepresidente, N consiglieri).
	 *
	 * @throws \InvalidArgumentException
	 */
	public function set_board_role( int $person_id, ?string $role ): void {
		$p = $this->get( $person_id );
		if ( ! $p ) {
			throw new \InvalidArgumentException( 'Persona non trovata.' );
		}
		$role = null === $role || '' === $role ? null : $role;
		if ( null !== $role ) {
			if ( ! BoardRole::is_valid( $role ) ) {
				throw new \InvalidArgumentException( 'Carica non valida.' );
			}
			if ( ! BoardRole::eligible_type( $p['type'] ) ) {
				throw new \InvalidArgumentException( 'Una carica può averla solo un socio fondatore o ordinario.' );
			}
			if ( ! $this->is_active_member( $person_id ) ) {
				throw new \InvalidArgumentException( 'Per avere una carica il socio deve essere in regola con la tessera.' );
			}
			if ( (string) $p['board_role'] !== $role ) {
				$taken = (int) $this->db()->get_var( $this->db()->prepare( 'SELECT COUNT(*) FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND board_role = %s AND id <> %d', $role, $person_id ) );
				$max   = BoardRole::seats( $role, Settings::councillors() );
				if ( $taken >= $max ) {
					throw new \InvalidArgumentException( 'Posti già coperti per questa carica (' . $max . '): togli prima la carica a qualcun altro.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
			}
		}
		$this->db()->update( Db::t( 'people' ), array( 'board_role' => $role ), array( 'id' => $person_id ) );
		Audit::log( 'board.role', 'person', $person_id, array( 'role' => $role ) );
	}

	/**
	 * Livello di socio (null = quello predefinito della base) e capofamiglia (null = nessun nucleo familiare).
	 * Il livello deve avere la stessa base del tipo della persona; il capofamiglia deve essere un socio e non un familiare a sua volta.
	 *
	 * @throws \InvalidArgumentException
	 */
	public function set_level_and_family( int $person_id, ?int $level_id, ?int $head_id ): void {
		$p = $this->get( $person_id );
		if ( ! $p ) {
			throw new \InvalidArgumentException( 'Persona non trovata.' );
		}
		$level_id = $level_id ? $level_id : null;
		$head_id  = $head_id ? $head_id : null;
		if ( ! MemberType::is_member( $p['type'] ) ) {
			$level_id = null;
			$head_id  = null; // gli ospiti non hanno livello né nucleo familiare
		}
		if ( null !== $level_id ) {
			$lv = Levels::get( $level_id );
			if ( ! $lv ) {
				throw new \InvalidArgumentException( 'Livello non trovato.' );
			}
			if ( $lv['base_type'] !== $p['type'] ) {
				throw new \InvalidArgumentException( 'Il livello «' . $lv['name'] . '» non corrisponde al tipo scelto (' . MemberType::label( $p['type'] ) . ').' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			if ( ! (int) $lv['active'] && (int) $p['level_id'] !== $level_id ) {
				throw new \InvalidArgumentException( 'Il livello «' . $lv['name'] . '» non è più attivo.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
		}
		if ( null !== $head_id ) {
			$head = $this->get( $head_id );
			if ( ! $head || ! MemberType::is_member( $head['type'] ) ) {
				throw new \InvalidArgumentException( 'Il capofamiglia deve essere un socio.' );
			}
			if ( $head_id === $person_id ) {
				throw new \InvalidArgumentException( 'Una persona non può essere capofamiglia di se stessa.' );
			}
			if ( ! empty( $head['family_head_id'] ) ) {
				throw new \InvalidArgumentException( 'Il capofamiglia scelto è a sua volta familiare di qualcun altro: scegli il capofamiglia del nucleo.' );
			}
			if ( (int) $this->db()->get_var( $this->db()->prepare( 'SELECT COUNT(*) FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND family_head_id = %d', $person_id ) ) > 0 ) {
				throw new \InvalidArgumentException( 'Questo socio è già capofamiglia di altri soci: togli prima loro dal nucleo.' );
			}
		}
		$this->db()->update( Db::t( 'people' ), array( 'level_id' => $level_id, 'family_head_id' => $head_id, 'updated_at' => Db::now() ), array( 'id' => $person_id ) );
		Audit::log( 'person.level', 'person', $person_id, array( 'level' => $level_id, 'head' => $head_id ) );
	}

	/** Familiari di un capofamiglia. @return array[] */
	public function family_of( int $head_id ): array {
		return $this->db()->get_results( $this->db()->prepare( 'SELECT * FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND family_head_id = %d ORDER BY last_name, first_name', $head_id ), ARRAY_A ) ?: array();
	}

	// ---------- Profilo completo (indirizzo e codice fiscale) ----------

	/**
	 * Che cosa manca al profilo di un socio per essere completo: codice fiscale valido, indirizzo, CAP e comune. La provincia è facoltativa.
	 *
	 * @return string[] etichette dei dati mancanti (vuoto = completo)
	 */
	public function profile_missing( array $p ): array {
		$out = array();
		if ( ! TaxCode::is_valid( (string) ( $p['tax_code'] ?? '' ) ) ) {
			$out[] = 'codice fiscale';
		}
		foreach ( array( 'address' => 'indirizzo', 'zip' => 'CAP', 'city' => 'comune' ) as $k => $label ) {
			if ( '' === trim( (string) ( $p[ $k ] ?? '' ) ) ) {
				$out[] = $label;
			}
		}
		return $out;
	}

	public function profile_complete( array $p ): bool {
		return array() === $this->profile_missing( $p );
	}

	/** Segna che il socio deve completare il profilo (si è attivato dal sito) oppure che lo ha fatto. */
	public function set_profile_due( int $person_id, bool $due ): void {
		$this->db()->update( Db::t( 'people' ), array( 'profile_due' => $due ? 1 : 0 ), array( 'id' => $person_id ) );
	}

	/** Il socio si è attivato dal sito e non ha ancora completato il profilo: finché è così (e se il blocco è attivo) non può prenotare né pagare online. */
	public function profile_blocks( array $p ): bool {
		return ! empty( $p['profile_due'] ) && Limits::flag( 'profile_gate' ) && ! $this->profile_complete( $p );
	}

	public function is_suspended( int $person_id ): bool {
		return (bool) $this->db()->get_var( $this->db()->prepare( 'SELECT suspended_at FROM ' . Db::t( 'people' ) . ' WHERE id = %d', $person_id ) );
	}

	/** Sospende un socio (inattivo: non prenota e non compare tra quelli da rinnovare) finché non rinnova o non lo si riattiva. */
	public function suspend( int $person_id ): void {
		$p = $this->get( $person_id );
		if ( ! $p || ! MemberType::is_member( $p['type'] ) || MemberType::is_auto_renewed( $p['type'] ) ) {
			throw new \InvalidArgumentException( 'Si possono sospendere solo i soci (non i fondatori né gli ospiti).' );
		}
		$this->db()->update( Db::t( 'people' ), array( 'suspended_at' => Db::now() ), array( 'id' => $person_id ) );
		Audit::log( 'person.suspended', 'person', $person_id );
	}

	/**
	 * Sospende i soci con la tessera scaduta da più di $months mesi (non i fondatori, né chi non ha mai pagato).
	 *
	 * @return int soci sospesi
	 */
	public function suspend_expired( int $months = 8 ): int {
		$n = 0;
		foreach ( $this->expired_for_months( $months ) as $p ) {
			$this->suspend( (int) $p['id'] );
			$n++;
		}
		return $n;
	}

	/** Soci attivi in anagrafica con la tessera scaduta da più di $months mesi. @return array[] */
	public function expired_for_months( int $months = 8 ): array {
		$limit = gmdate( 'Y-m-d', strtotime( Db::today() . ' -' . $months . ' months' ) );
		$out   = array();
		foreach ( $this->search() as $p ) {
			if ( ! MemberType::is_member( $p['type'] ) || MemberType::is_auto_renewed( $p['type'] ) || ! empty( $p['suspended_at'] ) || empty( $p['active_until'] ) ) {
				continue;
			}
			if ( $p['active_until'] < $limit ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	public function reactivate( int $person_id ): void {
		$p = $this->get( $person_id );
		if ( ! $p ) {
			throw new \InvalidArgumentException( 'Persona non trovata.' );
		}
		if ( ! empty( $p['left_on'] ) ) {
			throw new \InvalidArgumentException( 'Ha lasciato l\'associazione: per riammettere il socio togli prima la cessazione dal riquadro «Libro soci».' );
		}
		$this->db()->update( Db::t( 'people' ), array( 'suspended_at' => null ), array( 'id' => $person_id ) );
		Audit::log( 'person.reactivated', 'person', $person_id );
	}

	/** Iscrizioni (tessere) di una persona, dalla più recente. */
	public function memberships( int $person_id ): array {
		return $this->db()->get_results(
			$this->db()->prepare( 'SELECT * FROM ' . Db::t( 'memberships' ) . ' WHERE person_id = %d AND deleted_at IS NULL ORDER BY valid_from DESC', $person_id ),
			ARRAY_A
		) ?: array();
	}

	/** Numero di soci iscritti nell'anno sociale, per tipo. @return array tipo => numero */
	public function count_by_type_for_year( SocialYear $year ): array {
		$db   = $this->db();
		$rows = $db->get_results(
			$db->prepare(
				'SELECT p.type, COUNT(DISTINCT p.id) AS n FROM ' . Db::t( 'people' ) . ' p JOIN ' . Db::t( 'memberships' ) . ' m ON m.person_id = p.id '
				. 'AND m.deleted_at IS NULL AND m.valid_from <= %s AND m.valid_to >= %s WHERE p.deleted_at IS NULL GROUP BY p.type',
				$year->end()->format( 'Y-m-d' ),
				$year->start()->format( 'Y-m-d' )
			),
			ARRAY_A
		) ?: array();
		$out = array();
		foreach ( $rows as $r ) {
			$out[ $r['type'] ] = (int) $r['n'];
		}
		return $out;
	}

	// ---------- Scrittura ----------

	private function normalize( array $d ): array {
		$t = function ( $k ) use ( $d ) {
			$v = isset( $d[ $k ] ) ? trim( (string) $d[ $k ] ) : '';
			return '' === $v ? null : $v;
		};
		return array(
			'type'           => (string) ( $d['type'] ?? '' ),
			'card_number'    => $t( 'card_number' ),
			'first_name'     => (string) ( $t( 'first_name' ) ?? '' ),
			'last_name'      => (string) ( $t( 'last_name' ) ?? '' ),
			'email'          => null === $t( 'email' ) ? null : strtolower( $t( 'email' ) ),
			'phone'          => $t( 'phone' ),
			'tax_code'       => null === $t( 'tax_code' ) ? null : strtoupper( str_replace( ' ', '', $t( 'tax_code' ) ) ),
			'birth_date'     => null === $t( 'birth_date' ) ? null : ( Age::parse( (string) $t( 'birth_date' ) ) ?? (string) $t( 'birth_date' ) ),
			'birth_place'    => $t( 'birth_place' ),
			'address'        => $t( 'address' ),
			'zip'            => $t( 'zip' ),
			'city'           => $t( 'city' ),
			'province'       => null === $t( 'province' ) ? null : strtoupper( $t( 'province' ) ),
			'host_person_id' => ! empty( $d['host_person_id'] ) ? (int) $d['host_person_id'] : null,
			'joined_on'      => $t( 'joined_on' ),
			'approved_on'    => $t( 'approved_on' ),
			'notes'          => $t( 'notes' ),
			'prior_visits'   => max( 0, min( 9999, (int) ( $d['prior_visits'] ?? 0 ) ) ),
			'image_consent'  => isset( $d['image_consent'] ) && in_array( (string) $d['image_consent'], array( '0', '1' ), true ) ? (int) $d['image_consent'] : null,
			'affiliation_role' => MembershipRoles::is_valid( $d['affiliation_role'] ?? null ) ? (string) $d['affiliation_role'] : null,
			'subject_kind'   => RuntsRules::kind( $d['subject_kind'] ?? '' ), // persona fisica o ente (la denominazione sta in «cognome»)
			'runts_same_section' => isset( $d['runts_same_section'] ) && in_array( (string) $d['runts_same_section'], array( '0', '1' ), true ) ? (int) $d['runts_same_section'] : null,
		);
	}

	/** Chi risponde della liberatoria immagini: per un minore il tutore che opera sul sito, per un maggiorenne nessuno (è lui). */
	private function image_consent_giver( array $person ): ?int {
		if ( ! Age::is_minor( $person['birth_date'] ?? null, Db::today() ) ) {
			return null;
		}
		$g = Guardians::operative_of( (int) $person['id'] );
		return $g ? (int) $g['id'] : null;
	}

	private function assert_valid( array $d, ?int $except_id ): void {
		$host   = $d['host_person_id'] ? $this->get( (int) $d['host_person_id'] ) : null;
		$errors = Rules::validate_person( $d, $host, array( 'phone' => ! Limits::flag( 'guest_phone_required' ), 'host' => ! Limits::flag( 'guest_host_required' ) ) );
		if ( $errors ) {
			throw new \InvalidArgumentException( implode( ' ', $errors ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		if ( null !== $d['card_number'] ) {
			$holder = $this->find_by_card( $d['card_number'], $except_id );
			if ( $holder ) {
				throw new \InvalidArgumentException( 'La tessera ' . $d['card_number'] . ' è già assegnata a ' . $this->full_name( $holder ) . '.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
		}
		if ( null !== $d['email'] ) {
			$holder = $this->find_by_email( $d['email'], $except_id );
			if ( $holder ) {
				throw new \InvalidArgumentException( 'L\'email ' . $d['email'] . ' è già usata da ' . $this->full_name( $holder ) . '.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
		}
	}

	/** Crea una persona. Per i soci crea (o collega) l'utente WordPress con la stessa email. */
	public function create( array $input ): int {
		$d = $this->normalize( $input );
		if ( MemberType::GUEST === $d['type'] && ! Settings::guests_enabled() ) {
			throw new \InvalidArgumentException( 'L\'ente non accetta ospiti: si possono registrare solo soci.' );
		}
		$this->assert_valid( $d, null );

		$user_id = null;
		if ( MemberType::can_login( $d['type'] ) && null !== $d['email'] && MemberSession::wp_users_wanted() ) { // senza email: nessun utente finché il socio non si attiva col suo link; con l'accesso proprio i soci semplici non hanno un utente WordPress, salvo scelta dell'amministratore
			$user_id = $this->ensure_wp_user( $d, null ) ?: null; // 0 = l'email è di un dipendente: nessun collegamento
		}
		$now = Db::now();
		$ok  = $this->db()->insert(
			Db::t( 'people' ),
			array(
				'wp_user_id'     => $user_id,
				'type'           => $d['type'],
				'card_number'    => $d['card_number'],
				'first_name'     => $d['first_name'],
				'last_name'      => $d['last_name'],
				'email'          => $d['email'],
				'phone'          => $d['phone'],
				'tax_code'       => $d['tax_code'], 'birth_date' => $d['birth_date'],
				'birth_place'    => $d['birth_place'],
				'address'        => $d['address'],
				'zip'            => $d['zip'],
				'city'           => $d['city'],
				'province'       => $d['province'],
				'host_person_id' => $d['host_person_id'],
				'joined_on'      => $d['joined_on'] ?: Db::today(),
				'approved_on'    => $d['approved_on'],
				'notes'          => $d['notes'],
				'prior_visits'   => $d['prior_visits'],
				'affiliation_role' => $d['affiliation_role'],
				'subject_kind'   => $d['subject_kind'],
				'runts_same_section' => RuntsRules::ENTITY === $d['subject_kind'] ? $d['runts_same_section'] : null,
				'image_consent'  => $d['image_consent'],
				'image_consent_at' => null === $d['image_consent'] ? null : $now,
				'created_at'     => $now,
				'updated_at'     => $now,
			)
		);
		if ( ! $ok ) {
			throw new \InvalidArgumentException( 'Impossibile salvare la persona (errore del database).' );
		}
		$id = (int) $this->db()->insert_id;
		if ( MemberType::is_auto_renewed( $d['type'] ) ) {
			$this->set_founder_membership( $id, $d['joined_on'] ?: Db::today() );
		}
		MemberBook::ensure_matricola( $id ); // il socio ha la sua matricola, per sempre
		Audit::log( 'person.created', 'person', $id, array( 'type' => $d['type'] ) );
		return $id;
	}

	/**
	 * Attiva l'accesso di un socio registrato senza email: crea il suo utente WordPress con l'email e la password scelte da lui.
	 *
	 * @return int id dell'utente WordPress
	 * @throws \InvalidArgumentException
	 */
	public function activate( int $id, string $email, string $phone, string $password ): int {
		$p = $this->get( $id );
		if ( ! $p || ! MemberType::can_login( $p['type'] ) ) {
			throw new \InvalidArgumentException( 'Socio non trovato.' );
		}
		if ( ! empty( $p['wp_user_id'] ) ) {
			throw new \InvalidArgumentException( 'L\'accesso è già attivo.' );
		}
		if ( ! MemberSession::wp_users_wanted() ) {
			return $this->activate_own( $p, $email, $phone, $password );
		}
		$email = strtolower( trim( $email ) );
		if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			throw new \InvalidArgumentException( 'Inserisci un indirizzo email valido.' );
		}
		if ( ! Phone::is_valid( $phone ) ) {
			throw new \InvalidArgumentException( 'Inserisci il tuo numero di cellulare.' );
		}
		if ( strlen( $password ) < 8 ) {
			throw new \InvalidArgumentException( 'La password deve avere almeno 8 caratteri.' );
		}
		if ( get_user_by( 'email', $email ) ) {
			throw new \InvalidArgumentException( 'Questa email è già registrata sul sito: usa "Password dimenticata" oppure scrivi alla segreteria.' );
		}
		$this->update( $id, array( 'email' => $email, 'phone' => trim( $phone ) ) ); // crea l'utente WordPress
		$uid = (int) ( $this->get( $id )['wp_user_id'] ?? 0 );
		if ( ! $uid ) {
			throw new \InvalidArgumentException( 'Non è stato possibile creare l\'accesso: riprova o scrivi alla segreteria.' );
		}
		wp_set_password( $password, $uid );
		Audit::log( 'person.activated', 'person', $id );
		return $uid;
	}

	/**
	 * Attivazione con l'accesso proprio: email e cellulare sulla scheda, nessun utente WordPress. La password è obbligatoria (si sceglie qui).
	 *
	 * @return int 0: nessun utente WordPress
	 */
	private function activate_own( array $p, string $email, string $phone, string $password ): int {
		$id    = (int) $p['id'];
		$email = strtolower( trim( $email ) );
		if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			throw new \InvalidArgumentException( 'Inserisci un indirizzo email valido.' );
		}
		if ( ! Phone::is_valid( $phone ) ) {
			throw new \InvalidArgumentException( 'Inserisci il tuo numero di cellulare.' );
		}
		$problem = MemberPassword::problem( $password ); // la password si sceglie subito, è obbligatoria
		if ( '' !== $problem ) {
			throw new \InvalidArgumentException( $problem ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$this->update( $id, array( 'email' => $email, 'phone' => trim( $phone ) ) );
		$err = MemberLogin::set_password( $id, $password );
		if ( '' !== $err ) {
			throw new \InvalidArgumentException( $err ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		Audit::log( 'person.activated', 'person', $id, array( 'own' => true ) );
		return 0;
	}

	/**
	 * Chi ha un potere (segreteria, tesoriere, staff) lavora con un utente WordPress: lo si crea (o si collega quello con la stessa email)
	 * solo quando il potere viene dato. I soci semplici non ne hanno.
	 *
	 * @return int id dell'utente WordPress
	 */
	public function ensure_user( int $id ): int {
		$p = $this->get( $id );
		if ( ! $p || ! MemberType::can_login( $p['type'] ) ) {
			throw new \InvalidArgumentException( 'Socio non trovato.' );
		}
		if ( ! empty( $p['wp_user_id'] ) ) {
			return (int) $p['wp_user_id'];
		}
		if ( '' === trim( (string) $p['email'] ) ) {
			throw new \InvalidArgumentException( 'Prima inserisci l\'email nella scheda: serve per l\'accesso.' );
		}
		$uid = $this->ensure_wp_user( $this->normalize( $p ), $id );
		if ( $uid <= 0 ) {
			throw new \InvalidArgumentException( 'Con questa email c\'è già un dipendente del sito: i due accessi restano separati. Per dare al socio un potere (segreteria, tesoriere, staff) serve un\'altra email nella sua scheda.' );
		}
		$this->db()->update( Db::t( 'people' ), array( 'wp_user_id' => $uid, 'updated_at' => Db::now() ), array( 'id' => $id ) );
		Audit::log( 'person.wp_user_created', 'person', $id );
		return $uid;
	}

	/**
	 * Un socio che non ha più poteri torna all'accesso con link: l'utente WordPress si elimina. Lo decide l'amministratore, sempre caso per caso.
	 * Non si elimina un utente che ha ancora poteri, scritto contenuti o fatto ordini nel negozio: serve a loro.
	 *
	 * @throws \InvalidArgumentException con il motivo per cui non si può
	 */
	public function release_wp_user( int $id ): void {
		$p   = $this->get( $id );
		$uid = $p ? (int) $p['wp_user_id'] : 0;
		if ( ! $p || $uid <= 0 ) {
			throw new \InvalidArgumentException( 'Questo socio non ha un utente WordPress.' );
		}
		if ( ! MemberSession::enabled() ) {
			throw new \InvalidArgumentException( 'L\'accesso con link è spento (Impostazioni → Limiti e soglie): accendilo prima.' );
		}
		if ( '' === trim( (string) $p['email'] ) ) {
			throw new \InvalidArgumentException( 'Prima inserisci la sua email nella scheda: il link di accesso arriva lì.' );
		}
		if ( Access::has_powers( $uid ) ) {
			throw new \InvalidArgumentException( 'Ha ancora dei poteri (segreteria, presidente o vicepresidente, tesoriere, staff o altri ruoli del sito): toglili prima.' );
		}
		if ( get_userdata( $uid ) ) {
			if ( count_user_posts( $uid, 'any' ) > 0 ) {
				throw new \InvalidArgumentException( 'L\'utente ha scritto contenuti sul sito: non si elimina da qui.' );
			}
			if ( function_exists( 'wc_get_customer_order_count' ) && (int) wc_get_customer_order_count( $uid ) > 0 ) {
				throw new \InvalidArgumentException( 'L\'utente ha ordini nel negozio WooCommerce: resta, serve allo storico degli ordini.' );
			}
			\WP_Session_Tokens::get_instance( $uid )->destroy_all();
			require_once ABSPATH . 'wp-admin/includes/user.php';
			if ( ! wp_delete_user( $uid ) ) {
				throw new \InvalidArgumentException( 'Non è stato possibile eliminare l\'utente WordPress.' );
			}
		}
		$this->db()->update( Db::t( 'people' ), array( 'wp_user_id' => null, 'updated_at' => Db::now() ), array( 'id' => $id ) );
		do_action( 'asem_member_access_forgotten', $id, $uid ); // le funzioni avanzate tolgono ciò che avevano legato all'utente (ad esempio le notifiche)
		Audit::log( 'person.wp_user_released', 'person', $id );
	}

	/**
	 * Il socio ha un accesso: un utente WordPress oppure, quando i soci entrano con l'accesso proprio (cioè non si creano utenti WordPress),
	 * l'email con cui riceve il link. Con la scelta «anche un utente WordPress» chi non ce l'ha deve ancora attivarsi dal link.
	 */
	public static function has_access( array $p ): bool {
		if ( ! empty( $p['wp_user_id'] ) ) {
			return true;
		}
		return ! MemberSession::wp_users_wanted() && MemberType::can_login( (string) $p['type'] ) && '' !== trim( (string) $p['email'] ) && empty( $p['application_status'] );
	}

	/** Persone (soci e ospiti) con lo stesso cellulare, comunque sia scritto (+39, spazi, trattini). */
	public function find_by_phone( string $raw, ?int $except_id = null ): array {
		if ( ! Phone::is_valid( $raw ) ) {
			return array();
		}
		$key = Phone::key( $raw );
		$out = array();
		// Solo chi ha un cellulare, senza le sottointerrogazioni dell'elenco completo: la ricerca è chiamata anche da pagine pubbliche.
		$rows = $this->db()->get_results( 'SELECT * FROM ' . Db::t( 'people' ) . " WHERE deleted_at IS NULL AND anonymized_at IS NULL AND application_status IS NULL AND phone IS NOT NULL AND phone <> ''", ARRAY_A ) ?: array();
		foreach ( $rows as $p ) {
			if ( (int) $p['id'] !== (int) $except_id && Phone::key( (string) $p['phone'] ) === $key ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/** Persone con lo stesso nome e cognome (senza maiuscole né accenti): serve a non registrare due volte lo stesso ospite. */
	public function find_homonyms( string $first, string $last, ?int $except_id = null ): array {
		$key = Text::normalize( $first . $last );
		$out = array();
		foreach ( $this->search( array( 'q' => $last ) ) as $p ) {
			if ( (int) $p['id'] !== (int) $except_id && Text::normalize( $p['first_name'] . $p['last_name'] ) === $key ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/**
	 * Un ospite diventa socio: la sua scheda resta la stessa, quindi tutte le sue partecipazioni (eventi, corsi, pagamenti) restano collegate.
	 *
	 * @param array $in email (obbligatoria), type (ordinary|volunteer), card_number (facoltativo), membership (bool: segna l'iscrizione all'anno sociale corrente)
	 * @throws \InvalidArgumentException
	 */
	public function promote_guest( int $id, array $in ): void {
		$p = $this->get( $id );
		if ( ! $p || MemberType::GUEST !== $p['type'] ) {
			throw new \InvalidArgumentException( 'Solo un ospite può essere iscritto come socio da qui.' );
		}
		$type = MemberType::is_member( (string) ( $in['type'] ?? '' ) ) && ! MemberType::is_auto_renewed( (string) $in['type'] ) ? (string) $in['type'] : MemberType::ORDINARY;
		$this->update(
			$id,
			array(
				'type' => $type, 'email' => trim( (string) ( $in['email'] ?? '' ) ), 'card_number' => isset( $in['card_number'] ) && '' !== trim( (string) $in['card_number'] ) ? trim( (string) $in['card_number'] ) : null,
				'host_person_id' => null, 'joined_on' => Db::today(),
			)
		);
		if ( ! empty( $in['membership'] ) ) {
			$this->set_membership( $id, Settings::membership_year()->label(), true, 'manual' );
		}
		Audit::log( 'person.promoted', 'person', $id, array( 'from' => 'guest', 'to' => $type ) );
	}

	/** Chiavi con cui si riconosce la stessa persona registrata più volte: nome e cognome, email, telefono. @return array<string,string> chiave => motivo */
	private static function identity_keys( array $g ): array {
		$keys = array( 'n:' . Text::normalize( $g['first_name'] . $g['last_name'] ) => 'stesso nome' );
		if ( ! empty( $g['email'] ) ) {
			$keys[ 'e:' . Text::lower( (string) $g['email'] ) ] = 'stessa email';
		}
		$phone = Phone::key( (string) ( $g['phone'] ?? '' ) );
		if ( Phone::is_valid( (string) ( $g['phone'] ?? '' ) ) ) {
			$keys[ 'p:' . $phone ] = 'stesso cellulare';
		}
		return $keys;
	}

	/**
	 * Quadro degli ospiti per chi gestisce: quante volte è venuto ognuno e se lo stesso ospite risulta registrato più volte
	 * (stesso nome, email o telefono, anche da soci diversi): le partecipazioni delle registrazioni gemelle si sommano.
	 * Nessun blocco: serve a "intercettare" chi aggira il conto delle partecipazioni.
	 *
	 * @return array<int,array> ospite => count, total (sue + dei gemelli), twins [id, name, host, count, why], flag (total ha raggiunto la soglia)
	 */
	public function guest_overview(): array {
		$acts   = Plugin::activities();
		$guests = $this->search( array( 'type' => MemberType::GUEST ) );
		$counts = $acts->participation_counts( array_column( $guests, 'id' ) );
		foreach ( $guests as $g ) { // le volte già venuto prima di usare il programma (da scheda o da importazione) si sommano a quelle registrate
			$counts[ (int) $g['id'] ] = (int) ( $counts[ (int) $g['id'] ] ?? 0 ) + (int) ( $g['prior_visits'] ?? 0 );
		}
		$limit  = $acts->guest_limit();
		$by_key = array();
		foreach ( $guests as $g ) {
			foreach ( array_keys( self::identity_keys( $g ) ) as $k ) {
				$by_key[ $k ][] = (int) $g['id'];
			}
		}
		$by_id = array();
		foreach ( $guests as $g ) {
			$by_id[ (int) $g['id'] ] = $g;
		}
		$out = array();
		foreach ( $guests as $g ) {
			$id    = (int) $g['id'];
			$twins = array();
			foreach ( self::identity_keys( $g ) as $k => $why ) {
				foreach ( $by_key[ $k ] as $other ) {
					if ( $other === $id ) {
						continue;
					}
					if ( ! isset( $twins[ $other ] ) ) {
						$o              = $by_id[ $other ];
						$twins[ $other ] = array( 'id' => $other, 'name' => trim( $o['first_name'] . ' ' . $o['last_name'] ), 'host' => (string) $o['host_name'], 'count' => (int) ( $counts[ $other ] ?? 0 ), 'why' => array() );
					}
					$twins[ $other ]['why'][] = $why;
				}
			}
			$total = (int) ( $counts[ $id ] ?? 0 ) + array_sum( array_column( $twins, 'count' ) );
			$out[ $id ] = array( 'count' => (int) ( $counts[ $id ] ?? 0 ), 'total' => $total, 'twins' => array_values( $twins ), 'flag' => $limit > 0 && $total >= $limit );
		}
		return $out;
	}

	/** Ospiti da invitare a iscriversi: hanno raggiunto la soglia di partecipazioni (anche sommando le registrazioni gemelle). @return array[] persone con 'overview' */
	public function guests_to_invite(): array {
		$ov  = $this->guest_overview();
		$out = array();
		foreach ( $this->search( array( 'type' => MemberType::GUEST ) ) as $g ) {
			if ( ! empty( $ov[ (int) $g['id'] ]['flag'] ) ) {
				$g['overview'] = $ov[ (int) $g['id'] ];
				$out[]         = $g;
			}
		}
		return $out;
	}
	public function update( int $id, array $input ): void {
		$current = $this->get( $id );
		if ( ! $current ) {
			throw new \InvalidArgumentException( 'Persona non trovata.' );
		}
		$d = $this->normalize( array_merge( $current, $input ) );
		if ( MemberType::is_member( $current['type'] ) && MemberType::GUEST === $d['type'] ) {
			throw new \InvalidArgumentException( 'Un socio non può diventare ospite.' );
		}
		$this->assert_valid( $d, $id );

		$user_id = $current['wp_user_id'] ? (int) $current['wp_user_id'] : null;
		if ( MemberType::can_login( $d['type'] ) ) {
			if ( null === $user_id ) {
				if ( null !== $d['email'] && MemberSession::wp_users_wanted() ) {
					$user_id = $this->ensure_wp_user( $d, $id ) ?: null; // ad es. ospite diventato socio, o socio che ha dato l'email
				}
			} else {
				$this->sync_wp_user( $user_id, $d );
			}
		}

		$this->db()->update(
			Db::t( 'people' ),
			array(
				'wp_user_id'     => $user_id,
				'type'           => $d['type'],
				'card_number'    => $d['card_number'],
				'first_name'     => $d['first_name'],
				'last_name'      => $d['last_name'],
				'email'          => $d['email'],
				'phone'          => $d['phone'],
				'tax_code'       => $d['tax_code'], 'birth_date' => $d['birth_date'],
				'birth_place'    => $d['birth_place'],
				'address'        => $d['address'],
				'zip'            => $d['zip'],
				'city'           => $d['city'],
				'province'       => $d['province'],
				'host_person_id' => $d['host_person_id'],
				'joined_on'      => $d['joined_on'] ?: $current['joined_on'],
				'approved_on'    => $d['approved_on'],
				'notes'          => $d['notes'],
				'prior_visits'   => $d['prior_visits'],
				'affiliation_role' => $d['affiliation_role'],
				'subject_kind'   => $d['subject_kind'],
				'runts_same_section' => RuntsRules::ENTITY === $d['subject_kind'] ? $d['runts_same_section'] : null,
				'image_consent'  => $d['image_consent'],
				'image_consent_at' => $d['image_consent'] === ( null === $current['image_consent'] ? null : (int) $current['image_consent'] ) ? $current['image_consent_at'] : ( null === $d['image_consent'] ? null : Db::now() ),
				'image_consent_by' => $d['image_consent'] === ( null === $current['image_consent'] ? null : (int) $current['image_consent'] ) ? $current['image_consent_by'] : $this->image_consent_giver( $current ),
				'updated_at'     => Db::now(),
			),
			array( 'id' => $id )
		);

		$was_founder = MemberType::is_auto_renewed( $current['type'] );
		$is_founder  = MemberType::is_auto_renewed( $d['type'] );
		if ( $is_founder ) {
			$this->set_founder_membership( $id, $d['joined_on'] ?: (string) $current['joined_on'] );
		} elseif ( $was_founder ) {
			$this->db()->update( Db::t( 'memberships' ), array( 'deleted_at' => Db::now() ), array( 'person_id' => $id, 'social_year' => 'FOUNDER' ) );
		}
		MemberBook::ensure_matricola( $id ); // un ospite diventato socio entra nel libro: prende la matricola
		Audit::log( 'person.updated', 'person', $id, $current['type'] === $d['type'] ? array() : array( 'type' => array( $current['type'], $d['type'] ) ) );
	}

	/**
	 * Scollega l'email di un socio: si riparte senza email (e senza accesso all'area riservata) ma lo storico resta.
	 * L'utente WordPress non viene cancellato; si rifiuta se ha altri ruoli oltre a quello di socio.
	 */
	public function detach_email( int $id ): void {
		$p = $this->get( $id );
		if ( ! $p || ! MemberType::is_member( $p['type'] ) ) {
			throw new \InvalidArgumentException( 'L\'email si scollega solo dai soci.' );
		}
		if ( empty( $p['email'] ) && empty( $p['wp_user_id'] ) ) {
			throw new \InvalidArgumentException( 'Il socio non ha un\'email collegata.' );
		}
		if ( ! empty( $p['wp_user_id'] ) ) {
			$user = get_userdata( (int) $p['wp_user_id'] );
			if ( $user && array( Plugin::ROLE_MEMBER ) !== array_values( $user->roles ) ) {
				throw new \InvalidArgumentException( 'L\'utente collegato ha altri ruoli oltre a quello di socio (amministratore, segreteria…): togli prima quei ruoli.' );
			}
			if ( $user ) {
				\WP_Session_Tokens::get_instance( $user->ID )->destroy_all(); // chiude gli accessi aperti
			}
		}
		$this->db()->update( Db::t( 'people' ), array( 'email' => null, 'wp_user_id' => null, 'updated_at' => Db::now() ), array( 'id' => $id ) );
		Audit::log( 'person.email_detached', 'person', $id );
	}

	/** Scollega il numero di telefono di un socio (gli ospiti no: il cellulare è il loro dato d'identità). */
	public function detach_phone( int $id ): void {
		$p = $this->get( $id );
		if ( ! $p || ! MemberType::is_member( $p['type'] ) ) {
			throw new \InvalidArgumentException( 'Il telefono si scollega solo dai soci.' );
		}
		if ( empty( $p['phone'] ) ) {
			throw new \InvalidArgumentException( 'Il socio non ha un numero di telefono collegato.' );
		}
		$this->db()->update( Db::t( 'people' ), array( 'phone' => null, 'updated_at' => Db::now() ), array( 'id' => $id ) );
		Audit::log( 'person.phone_detached', 'person', $id );
	}

	/** Eliminazione logica: libera la tessera e il collegamento all'utente WordPress (che NON viene cancellato). */
	public function delete( int $id ): void {
		$p = $this->get( $id );
		if ( ! $p ) {
			return;
		}
		if ( $this->guests_of( $id ) ) {
			throw new \InvalidArgumentException( 'Il socio ha degli ospiti collegati: eliminali o spostali prima.' );
		}
		$this->db()->update(
			Db::t( 'people' ),
			array( 'deleted_at' => Db::now(), 'card_number' => null, 'wp_user_id' => null ),
			array( 'id' => $id )
		);
		Guardians::forget( $id );
		MemberSession::forget_person( $id ); // sessioni, password e codici di accesso proprio
		Audit::log( 'person.deleted', 'person', $id, array( 'type' => $p['type'] ) );
	}

	// ---------- Utenti WordPress ----------

	private function ensure_wp_user( array $d, ?int $person_id ): int {
		$existing = get_user_by( 'email', $d['email'] );
		if ( $existing && Employees::is_employee( $existing ) ) {
			return 0; // l'utente è un dipendente: non si collega mai a un socio. Da socio si entra con l'accesso personale (link o codice via email), da dipendente con l'utente del sito
		}
		if ( $existing ) {
			$linked = $this->db()->get_var(
				$this->db()->prepare( 'SELECT id FROM ' . Db::t( 'people' ) . ' WHERE wp_user_id = %d AND deleted_at IS NULL AND id <> %d', $existing->ID, (int) $person_id )
			);
			if ( $linked ) {
				throw new \InvalidArgumentException( 'L\'utente WordPress con questa email è già collegato a un altro socio.' );
			}
			if ( array_diff( (array) $existing->roles, array( 'subscriber', 'customer', Plugin::ROLE_MEMBER ) ) && ! current_user_can( Plugin::CAP ) ) {
				throw new \InvalidArgumentException( 'Con questa email esiste già un utente del sito con altri ruoli (ad esempio redattore o amministratore): solo un amministratore può collegarlo a un socio.' );
			}
			$this->secure_existing_user( $existing ); // si collega l'utente esistente senza cambiargli il ruolo
			return (int) $existing->ID;
		}
		$uid = wp_insert_user(
			array(
				'user_login'   => $this->unique_login( $d['email'] ),
				'user_email'   => $d['email'],
				'user_pass'    => wp_generate_password( 24 ),
				'first_name'   => $d['first_name'],
				'last_name'    => $d['last_name'],
				'display_name' => trim( $d['first_name'] . ' ' . $d['last_name'] ),
				'role'         => Plugin::ROLE_MEMBER,
			)
		);
		if ( is_wp_error( $uid ) ) {
			throw new \InvalidArgumentException( 'Impossibile creare l\'utente WordPress: ' . $uid->get_error_message() ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		return (int) $uid;
	}

	/**
	 * Collegare a un socio un utente WordPress già esistente con la stessa email: se l'utente ha solo ruoli da semplice visitatore (iscritto da solo al
	 * sito, cliente del negozio) non si può sapere chi ha scelto la sua password. Si cambia con una casuale e si chiudono gli accessi aperti: il socio
	 * entra col «Primo accesso» (il link va all'email del socio). Chi ha altri ruoli (amministratori, segreteria…) non si tocca.
	 */
	private function secure_existing_user( \WP_User $user ): void {
		if ( $user->roles && ! array_diff( $user->roles, array( 'subscriber', 'customer' ) ) ) {
			wp_set_password( wp_generate_password( 32 ), (int) $user->ID );
			\WP_Session_Tokens::get_instance( (int) $user->ID )->destroy_all();
			Audit::log( 'person.wp_user_secured', 'user', (int) $user->ID );
		}
	}

	private function unique_login( string $email ): string {
		$base  = sanitize_user( $email, true );
		$login = $base;
		$i     = 2;
		while ( username_exists( $login ) ) {
			$login = $base . $i++;
		}
		return $login;
	}

	/**
	 * Chi ha una carica (presidente, vicepresidente), è tesoriere o staff dell'ente ha più poteri di un socio: la segreteria non può spostare la sua email
	 * di accesso (con «Password dimenticata» si entrerebbe al suo posto). Solo un amministratore, o la persona stessa, la cambia.
	 */
	private function email_change_needs_admin( \WP_User $user ): bool {
		if ( get_current_user_id() === (int) $user->ID || current_user_can( Plugin::CAP ) ) {
			return false;
		}
		$uid = (int) $user->ID;
		return Access::is_board_operator( $uid ) || Access::is_treasurer( $uid ) || Access::is_entity_staff( $uid );
	}

	/** Allinea email e nome dell'utente WordPress, ma solo se è un utente "solo socio" (mai admin o altri ruoli). */
	private function sync_wp_user( int $user_id, array $d ): void {
		$user = get_userdata( $user_id );
		if ( ! $user || array( Plugin::ROLE_MEMBER ) !== array_values( $user->roles ) ) {
			return;
		}
		$args = array( 'ID' => $user_id, 'first_name' => $d['first_name'], 'last_name' => $d['last_name'], 'display_name' => trim( $d['first_name'] . ' ' . $d['last_name'] ) );
		if ( null !== $d['email'] && strtolower( $user->user_email ) !== $d['email'] && ! $this->email_change_needs_admin( $user ) ) {
			$args['user_email'] = $d['email'];
		}
		$res = wp_update_user( $args );
		if ( is_wp_error( $res ) ) {
			throw new \InvalidArgumentException( 'Impossibile aggiornare l\'utente WordPress: ' . $res->get_error_message() ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
	}

	// ---------- Iscrizioni (tessere) ----------

	/** Ripristina la tessera sempre rinnovata di un fondatore (dopo una cessazione tolta). */
	public function refresh_founder_membership( int $person_id ): void {
		$p = $this->get( $person_id );
		if ( $p && MemberType::is_auto_renewed( $p['type'] ) ) {
			$this->set_founder_membership( $person_id, (string) $p['joined_on'] );
		}
	}

	/** Il fondatore ha una sola iscrizione che dura N anni (default 99): sempre rinnovata. */
	private function set_founder_membership( int $person_id, string $joined_on ): void {
		$from = new \DateTimeImmutable( $joined_on ?: Db::today() );
		$to   = $from->modify( '+' . (int) Settings::get( 'founder_years' ) . ' years' );
		$this->upsert_membership( $person_id, 'FOUNDER', $from->format( 'Y-m-d' ), $to->format( 'Y-m-d' ), 'founder', null );
	}

	private function upsert_membership( int $person_id, string $label, string $from, string $to, string $source, ?int $tx_id ): void {
		$db  = $this->db();
		$tbl = Db::t( 'memberships' );
		$row = $db->get_row( $db->prepare( "SELECT id FROM $tbl WHERE person_id = %d AND social_year = %s", $person_id, $label ), ARRAY_A );
		$data = array( 'valid_from' => $from, 'valid_to' => $to, 'source' => $source, 'transaction_id' => $tx_id, 'deleted_at' => null );
		if ( $row ) {
			$db->update( $tbl, $data, array( 'id' => (int) $row['id'] ) );
		} else {
			$db->insert( $tbl, array_merge( $data, array( 'person_id' => $person_id, 'social_year' => $label, 'created_at' => Db::now() ) ) );
		}
	}

	/** Iscrive o toglie l'iscrizione per un anno sociale (es. "2025/2026"). Non vale per fondatori e ospiti. */
	public function set_membership( int $person_id, string $year_label, bool $enabled, string $source = 'manual', ?int $tx_id = null ): void {
		$p = $this->get( $person_id );
		if ( ! $p ) {
			throw new \InvalidArgumentException( 'Persona non trovata.' );
		}
		if ( ! MemberType::is_member( $p['type'] ) ) {
			throw new \InvalidArgumentException( MemberType::GUARDIAN === $p['type'] ? 'Un genitore o tutore non è un socio: non ha iscrizione né tessera.' : 'Gli ospiti non sono soci: non hanno iscrizione.' );
		}
		if ( MemberType::is_auto_renewed( $p['type'] ) ) {
			throw new \InvalidArgumentException( 'Il socio fondatore ha la tessera sempre rinnovata.' );
		}
		$year = SocialYear::from_label( $year_label, Settings::start_month() );
		YearLock::assert_range_open( $year->start()->format( 'Y-m-d' ), $year->end()->format( 'Y-m-d' ) ); // una tessera che cade interamente in esercizi chiusi non si aggiunge né si toglie: l'esercizio va riaperto
		if ( $enabled ) {
			$this->upsert_membership( $person_id, $year->label(), $year->start()->format( 'Y-m-d' ), $year->end()->format( 'Y-m-d' ), $source, $tx_id );
		} else {
			$this->db()->update( Db::t( 'memberships' ), array( 'deleted_at' => Db::now() ), array( 'person_id' => $person_id, 'social_year' => $year->label() ) );
		}
		Audit::log( $enabled ? 'membership.set' : 'membership.removed', 'person', $person_id, array( 'social_year' => $year->label(), 'source' => $source ) );
	}

	/** Il socio ha un'iscrizione (non cancellata) per quell'anno della tessera (es. "2026")? */
	public function has_membership( int $person_id, string $label ): bool {
		return (bool) $this->db()->get_var( $this->db()->prepare( 'SELECT COUNT(*) FROM ' . Db::t( 'memberships' ) . ' WHERE person_id = %d AND social_year = %s AND deleted_at IS NULL', $person_id, $label ) );
	}

	/**
	 * Per quale anno paga la quota un socio che versa oggi, e quale anno gli è regalato.
	 * La quota va all'anno solare più recente creato. Se non è quello in corso:
	 *  - chi ha già l'anno in corso rinnova in anticipo (paga il più recente);
	 *  - chi è nuovo (non aveva la tessera nemmeno l'anno scorso) paga il più recente e ha l'anno in corso in omaggio;
	 *  - chi non ha rinnovato l'anno in corso, ma aveva la tessera l'anno scorso, paga prima l'anno in corso (poi la segreteria gestisce il resto a mano).
	 *
	 * @return array{year:string, free:?string}
	 */
	public function membership_plan( int $person_id, string $date ): array {
		$cur    = (int) substr( $date, 0, 4 );
		$latest = FiscalYears::latest();
		$year   = (string) $cur;
		$free   = null;
		if ( null !== $latest && $latest > $cur ) {
			if ( $this->has_membership( $person_id, (string) $cur ) ) {
				$year = (string) $latest;
			} elseif ( ! $this->has_membership( $person_id, (string) ( $cur - 1 ) ) ) {
				$year = (string) $latest;
				$free = (string) $cur;
			}
		}
		return array( 'year' => $year, 'free' => $free );
	}

	/** Quanto copre ciò che è stato incassato per la quota associativa di un anno della tessera (movimenti non annullati, sconti compresi). */
	public function membership_paid( int $person_id, string $year_label ): int {
		return (int) $this->db()->get_var(
			$this->db()->prepare(
				'SELECT COALESCE(SUM(t.amount_cents + t.discount_cents), 0) FROM ' . Db::t( 'transactions' ) . ' t JOIN ' . Db::t( 'categories' ) . " c ON c.id = t.category_id WHERE t.person_id = %d AND t.social_year = %s AND t.type = 'income' AND t.voided_at IS NULL AND c.kind = 'membership'", // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- nomi tabella interni
				$person_id,
				$year_label
			)
		);
	}

	/**
	 * Quanto manca per completare la quota di quell'anno quando si paga a rate («tessera solo al saldo» attivo e almeno un versamento già fatto); altrimenti 0.
	 */
	public function membership_missing( array $person, string $year_label ): int {
		if ( ! Limits::flag( 'membership_on_balance' ) ) {
			return 0;
		}
		$fee  = Levels::fee_for( $person );
		$paid = $this->membership_paid( (int) $person['id'], $year_label );
		return $fee > 0 && $paid > 0 ? max( 0, $fee - $paid ) : 0;
	}

	/** Annulla l'iscrizione nata da un incasso (usato quando si annulla il movimento). */
	public function remove_membership_of_transaction( int $tx_id ): void {
		$row = $this->db()->get_row( $this->db()->prepare( 'SELECT person_id, social_year FROM ' . Db::t( 'memberships' ) . ' WHERE transaction_id = %d AND deleted_at IS NULL', $tx_id ), ARRAY_A );
		if ( ! $row ) {
			return;
		}
		foreach ( $this->db()->get_results( $this->db()->prepare( 'SELECT valid_from, valid_to FROM ' . Db::t( 'memberships' ) . ' WHERE transaction_id = %d AND deleted_at IS NULL', $tx_id ), ARRAY_A ) ?: array() as $m ) {
			YearLock::assert_range_open( (string) $m['valid_from'], (string) $m['valid_to'] ); // la tessera di un esercizio chiuso non decade
		}
		$this->db()->update( Db::t( 'memberships' ), array( 'deleted_at' => Db::now() ), array( 'transaction_id' => $tx_id ) );
		Audit::log( 'membership.removed', 'person', (int) $row['person_id'], array( 'social_year' => $row['social_year'], 'source' => 'void', 'transaction' => $tx_id ) );
	}

	/** Dopo l'annullamento di un versamento: se la quota dell'anno non è più completa, la tessera data al saldo decade. */
	public function recheck_membership_after_void( int $tx_id ): void {
		$row = $this->db()->get_row( $this->db()->prepare( 'SELECT t.person_id, t.social_year FROM ' . Db::t( 'transactions' ) . ' t JOIN ' . Db::t( 'categories' ) . " c ON c.id = t.category_id WHERE t.id = %d AND c.kind = 'membership' AND t.person_id IS NOT NULL", $tx_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- nomi tabella interni
		$p   = $row ? $this->get( (int) $row['person_id'] ) : null;
		if ( ! $p || '' === (string) $row['social_year'] || ! $this->has_membership( (int) $p['id'], (string) $row['social_year'] ) ) {
			return;
		}
		if ( $this->membership_missing( $p, (string) $row['social_year'] ) > 0 ) {
			$sy = SocialYear::from_label( (string) $row['social_year'], Settings::start_month() );
			YearLock::assert_range_open( $sy->start()->format( 'Y-m-d' ), $sy->end()->format( 'Y-m-d' ) ); // la tessera di un esercizio chiuso non decade
			$this->db()->update( Db::t( 'memberships' ), array( 'deleted_at' => Db::now() ), array( 'person_id' => (int) $p['id'], 'social_year' => (string) $row['social_year'] ) );
			Audit::log( 'membership.removed', 'person', (int) $p['id'], array( 'social_year' => $row['social_year'], 'source' => 'void_partial', 'transaction' => $tx_id ) );
		}
	}
}
