<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/**
 * Documenti stampabili dei registri: libro soci, registro volontari, presenze, verbali e rendiconto, in PDF (e CSV per gli elenchi).
 * Il PDF è generato dal plugin (classe Pdf), senza librerie esterne.
 */
final class Docs {

	const LEFT   = 50.0;
	const RIGHT  = 545.0; // Pdf::W - 50
	const BOTTOM = 790.0;

	public static function register(): void {
		add_action( 'admin_post_asem_doc', array( __CLASS__, 'handle' ) );
	}

	/**
	 * Le tessere dei soci su fogli A4 con più tessere per foglio, da stampare e ritagliare (i posti che restano sono modelli vuoti).
	 *
	 * @param string $filter filtro del libro soci ('' = i soci in carica)
	 * @param int    $per    tessere per foglio (0 = quante ne stanno)
	 * @throws \InvalidArgumentException
	 */
	public static function cards( string $filter = '', int $per = 0 ): array {
		$people = array();
		foreach ( MemberBook::rows( '' === $filter ? MemberBook::IN_FORCE : $filter ) as $r ) {
			$p = Plugin::people()->get( (int) $r['id'] );
			if ( $p && MemberType::is_member( $p['type'] ) ) {
				$people[] = $p;
			}
		}
		if ( ! $people ) {
			throw new \InvalidArgumentException( 'Nessun socio per cui stampare la tessera.' );
		}
		return array( 'body' => CardLayout::pdf_sheets( $people, max( 0, $per ) ), 'filename' => 'tessere.pdf', 'mime' => 'application/pdf' );
	}

	public static function url( string $what, array $args = array(), string $format = 'pdf' ): string {
		return wp_nonce_url( add_query_arg( array_merge( array( 'action' => 'asem_doc', 'what' => $what, 'format' => $format ), $args ), admin_url( 'admin-post.php' ) ), 'asem_doc' );
	}

	public static function d( ?string $ymd ): string {
		return $ymd ? ( new \DateTimeImmutable( $ymd ) )->format( 'd/m/Y' ) : '';
	}

	public static function fit( string $s, float $w, float $size, bool $bold = false ): string {
		if ( Pdf::width( $s, $size, $bold ) <= $w ) {
			return $s;
		}
		while ( '' !== $s && Pdf::width( $s . '…', $size, $bold ) > $w ) {
			$s = function_exists( 'mb_substr' ) ? mb_substr( $s, 0, -1, 'UTF-8' ) : substr( $s, 0, -1 );
		}
		return $s . '…';
	}

	public static function csv_line( array $cells ): string {
		$out = array();
		foreach ( $cells as $c ) {
			$v     = Admin\Exports::neutralize( null === $c ? '' : (string) $c );
			$out[] = preg_match( '/[;"\r\n]/', $v ) ? '"' . str_replace( '"', '""', $v ) . '"' : $v;
		}
		return implode( ';', $out ) . "\r\n";
	}

	public static function csv( array $cols, array $rows ): string {
		$s = self::csv_line( array_column( $cols, 'label' ) );
		foreach ( $rows as $r ) {
			$s .= self::csv_line( $r );
		}
		return "\xEF\xBB\xBF" . $s;
	}

	public static function president(): string {
		foreach ( Plugin::people()->board() as $b ) {
			if ( BoardRole::PRESIDENT === $b['board_role'] ) {
				return trim( $b['first_name'] . ' ' . $b['last_name'] );
			}
		}
		return '';
	}

	/** Intestazione dell'associazione, titolo e sottotitolo. @return float la y da cui continuare */
	public static function head( Pdf $pdf, string $title, string $subtitle = '', ?array $entity = null ): float {
		$name = null !== $entity ? (string) ( $entity['name'] ?? '' ) : (string) Settings::get( 'association_name' ); // un documento emesso porta l'ente di quel giorno, non quello di oggi
		$cf   = null !== $entity ? (string) ( $entity['tax_code'] ?? '' ) : (string) Settings::get( 'tax_code' );
		$pdf->text( self::LEFT, 56, '' !== $name ? $name : 'Associazione', 15, true );
		if ( '' !== $cf ) {
			$pdf->text( self::LEFT, 72, 'Codice fiscale: ' . $cf, 9 );
		}
		$pdf->line( self::LEFT, 82, self::RIGHT, 82, 1.0 );
		$pdf->text( self::LEFT, 106, $title, 13, true );
		$y = 106.0;
		if ( '' !== $subtitle ) {
			$y += 15;
			$pdf->text( self::LEFT, $y, $subtitle, 9 );
		}
		return $y + 20;
	}

	/**
	 * Tabella a più pagine.
	 *
	 * @param array[] $cols [label, w (punti), align L|R|C]
	 * @param array[] $rows celle di testo
	 */
	public static function table_pdf( string $title, string $subtitle, array $cols, array $rows, string $foot = '' ): string {
		Pdf::$filter = array( Texts::class, 'plain' );
		$pdf         = new Pdf();
		$y           = self::head( $pdf, $title, $subtitle );
		$header      = function ( Pdf $pdf, float $y ) use ( $cols ) {
			$pdf->rect( self::LEFT, $y - 11, self::RIGHT - self::LEFT, 17 );
			$x = self::LEFT;
			foreach ( $cols as $c ) {
				$pdf->text( 'R' === ( $c['align'] ?? 'L' ) ? $x + $c['w'] - 3 : $x + 3, $y + 1, self::fit( (string) $c['label'], $c['w'] - 6, 8, true ), 8, true, $c['align'] ?? 'L' );
				$x += $c['w'];
			}
		};
		$header( $pdf, $y );
		$y += 20;
		foreach ( $rows as $i => $r ) {
			if ( $y > self::BOTTOM ) {
				$pdf->add_page();
				$y = 60.0;
				$header( $pdf, $y );
				$y += 20;
			}
			if ( 0 === $i % 2 ) {
				$pdf->rect( self::LEFT, $y - 9, self::RIGHT - self::LEFT, 13, 0.97 );
			}
			$x = self::LEFT;
			foreach ( $cols as $k => $c ) {
				$pdf->text( 'R' === ( $c['align'] ?? 'L' ) ? $x + $c['w'] - 3 : ( 'C' === ( $c['align'] ?? 'L' ) ? $x + $c['w'] / 2 : $x + 3 ), $y, self::fit( (string) ( $r[ $k ] ?? '' ), $c['w'] - 6, 8 ), 8, false, $c['align'] ?? 'L' );
				$x += $c['w'];
			}
			$y += 13;
		}
		if ( ! $rows ) {
			$pdf->text( self::LEFT + 3, $y, 'Nessun dato.', 9 );
			$y += 13;
		}
		if ( '' !== $foot ) {
			$y += 14;
			foreach ( Pdf::wrap( $foot, self::RIGHT - self::LEFT, 8 ) as $line ) {
				$pdf->text( self::LEFT, min( $y, self::BOTTOM + 30 ), $line, 8 );
				$y += 11;
			}
		}
		$out         = $pdf->output();
		Pdf::$filter = null;
		return $out;
	}

	// ---------- Libro soci ----------

	/** Colonne del libro soci che nella fotografia non ci sono (recapiti, domanda, quota, tutore: non si copiano). */
	private static function book_snapshot_gaps(): array {
		return array( 'Email', 'Telefono', 'Data domanda', 'Ultima quota versata', 'Anno della quota', 'Genitore o tutore firmatario' );
	}

	private static function book_cols( bool $snap = false ): array {
		$labels = array( 'N.', 'Matricola', 'Cognome e nome', 'Tipo', 'Codice fiscale', 'Data di nascita', 'Luogo di nascita', 'Residenza', 'Email', 'Telefono', 'Data domanda', 'Data delibera', 'Ingresso', 'Ultima quota versata', 'Anno della quota', 'Cessazione (recesso/esclusione)', 'Motivo', 'Genitore o tutore firmatario', 'Livello' );
		if ( $snap ) {
			$labels = array_values( array_diff( $labels, self::book_snapshot_gaps() ) );
		}
		return array_map(
			function ( $l ) {
				return array( 'label' => $l, 'w' => 60 );
			},
			$labels
		);
	}

	private static function book_rows( array $rows, bool $snap = false ): array {
		$out = array();
		foreach ( $rows as $r ) {
			if ( $snap ) {
				$out[] = array(
					(string) $r['n'], (int) $r['matricola'] > 0 ? (string) (int) $r['matricola'] : '', $r['name'], MemberBook::kind_label( (string) $r['kind'] ), $r['tax_code'], '' !== $r['birth_date'] ? self::d( $r['birth_date'] ) : '', $r['birth_place'], $r['residence'],
					self::d( $r['approved_on'] ), self::d( $r['joined_on'] ), $r['left_on'] ? self::d( $r['left_on'] ) : '', $r['left_reason'], $r['level'],
				);
				continue;
			}
			$out[] = array(
				(string) $r['n'], (int) $r['matricola'] > 0 ? (string) (int) $r['matricola'] : '', $r['name'], MemberBook::kind_label( (string) $r['kind'] ), $r['tax_code'], '' !== $r['birth_date'] ? self::d( $r['birth_date'] ) : '', $r['birth_place'], $r['residence'], $r['email'], $r['phone'],
				self::d( $r['applied_on'] ), self::d( $r['approved_on'] ), self::d( $r['joined_on'] ), $r['fee_cents'] > 0 ? Money::format( $r['fee_cents'] ) : '', $r['fee_year'],
				$r['left_on'] ? self::d( $r['left_on'] ) : '', $r['left_reason'], $r['guardian'], $r['level'],
			);
		}
		return $out;
	}

	/** Libro soci in PDF: ogni socio occupa tre righe (anagrafica, recapiti, date e quota), perché i dati richiesti non stanno su una riga sola. */
	private static function book_pdf( array $rows, string $subtitle, bool $snap = false, string $title = 'LIBRO DEI SOCI' ): string {
		Pdf::$filter = array( Texts::class, 'plain' );
		$pdf         = new Pdf();
		$y           = self::head( $pdf, $title, $subtitle );
		$w           = self::RIGHT - self::LEFT;
		foreach ( $rows as $i => $r ) {
			if ( $y + 40 > self::BOTTOM ) {
				$pdf->add_page();
				$y = 60.0;
			}
			if ( 0 === $i % 2 ) {
				$pdf->rect( self::LEFT, $y - 9, $w, 38, 0.97 );
			}
			$born = trim( ( '' !== $r['birth_date'] ? 'nato/a il ' . self::d( $r['birth_date'] ) : '' ) . ( '' !== $r['birth_place'] ? ' a ' . $r['birth_place'] : '' ) );
			$pdf->text( self::LEFT + 3, $y, self::fit( $r['n'] . '. ' . ( (int) $r['matricola'] > 0 ? '[matr. ' . (int) $r['matricola'] . '] ' : '' ) . $r['name'] . ( '' !== $r['tax_code'] ? ' · CF ' . $r['tax_code'] : '' ), 240, 8, true ), 8, true );
			$pdf->text( self::LEFT + 250, $y, self::fit( $born, $w - 253, 8 ), 8 );
			$y += 12;
			$pdf->text( self::LEFT + 3, $y, self::fit( 'Tipo: ' . MemberBook::kind_label( (string) $r['kind'] ) . ( '' !== $r['residence'] ? ' · Residenza: ' . $r['residence'] : '' ), 300, 8 ), 8 );
			$pdf->text( self::LEFT + 310, $y, self::fit( $snap ? (string) $r['level'] : trim( $r['email'] . ( '' !== $r['phone'] ? ' · ' . $r['phone'] : '' ) ), $w - 313, 8 ), 8 );
			$y += 12;
			$parts = $snap ? array( 'Delibera ' . self::d( $r['approved_on'] ), 'Ingresso ' . self::d( $r['joined_on'] ) ) : array( 'Domanda ' . self::d( $r['applied_on'] ), 'Delibera ' . self::d( $r['approved_on'] ), 'Ingresso ' . self::d( $r['joined_on'] ) );
			if ( ! $snap && $r['fee_cents'] > 0 ) {
				$parts[] = 'Quota ' . Money::format( $r['fee_cents'] ) . ( '' !== $r['fee_year'] ? ' (' . $r['fee_year'] . ')' : '' );
			}
			if ( $r['left_on'] ) {
				$parts[] = 'Cessato il ' . self::d( $r['left_on'] ) . ( '' !== $r['left_reason'] ? ' · ' . $r['left_reason'] : '' );
			}
			if ( ! $snap && '' !== $r['guardian'] ) {
				$parts[] = 'Tutore ' . $r['guardian'];
			}
			$pdf->text( self::LEFT + 3, $y, self::fit( implode( ' · ', $parts ), $w - 6, 8 ), 8 );
			$y += 18;
		}
		if ( ! $rows ) {
			$pdf->text( self::LEFT + 3, $y, 'Nessun dato.', 9 );
		}
		$out         = $pdf->output();
		Pdf::$filter = null;
		return $out;
	}

	/** @return array{body:string,filename:string,mime:string} */
	public static function book( string $filter = '', string $format = 'pdf', ?int $year = null, ?int $version = null ): array {
		$rows   = MemberBook::rows( $filter, $year, $version );
		$all    = MemberBook::rows( '', $year, $version );
		$active = count( MemberBook::rows( MemberBook::IN_FORCE, $year, $version ) );
		$cap    = null === $year ? null : MemberBook::caption( $year, $version );
		$snap   = $cap && 'snapshot' === $cap['state'];
		$name   = 'libro-soci' . ( null === $year ? '' : '-' . str_replace( '/', '-', FiscalYears::label( $year ) ) . ( $version ? '-chiusura-' . $version : '' ) );
		if ( 'csv' === $format ) {
			return array( 'body' => self::csv( self::book_cols( $snap ), self::book_rows( $rows, $snap ) ), 'filename' => $name . '.csv', 'mime' => 'text/csv; charset=utf-8' );
		}
		$sub = ( $cap ? mb_substr( $cap['title'], mb_strlen( 'Libro soci — ' ) ) : 'Aggiornato al ' . self::d( Db::today() ) ) . ' · ' . count( $all ) . ( 1 === count( $all ) ? ' socio, ' : ' soci, ' ) . $active . ( 1 === $active ? ' non cessato' : ' non cessati' );
		return array( 'body' => self::book_pdf( $rows, $sub, $snap ), 'filename' => $name . '.pdf', 'mime' => 'application/pdf' );
	}

	// ---------- Verbale ----------

	/** @return array{body:string,filename:string,mime:string} @throws \InvalidArgumentException */
	public static function minute( int $id ): array {
		$m = Minutes::get( $id );
		if ( ! $m ) {
			throw new \InvalidArgumentException( 'Verbale non trovato.' );
		}
		Pdf::$filter = array( Texts::class, 'plain' );
		$pdf         = new Pdf();
		$kinds       = Minutes::kinds();
		$y           = self::head( $pdf, 'VERBALE N. ' . $m['number'] . ' — ' . mb_strtoupper( $kinds[ $m['kind'] ] ), $m['title'] );
		$w           = self::RIGHT - self::LEFT;
		$put         = function ( string $text, float $size = 10, bool $bold = false ) use ( $pdf, &$y, $w ) {
			foreach ( preg_split( "/\r\n|\n|\r/", $text ) ?: array( '' ) as $para ) {
				foreach ( '' === trim( $para ) ? array( '' ) : Pdf::wrap( $para, $w, $size, $bold ) as $line ) {
					if ( $y > self::BOTTOM ) {
						$pdf->add_page();
						$y = 60.0;
					}
					$pdf->text( self::LEFT, $y, $line, $size, $bold );
					$y += $size + 4;
				}
			}
		};
		$put( 'Data: ' . self::d( $m['meeting_date'] ) . ( '' !== (string) $m['place'] ? ' · Luogo: ' . $m['place'] : '' ) );
		$y += 6;
		if ( '' !== (string) $m['attendees'] ) {
			$put( 'Presenti', 10, true );
			$put( (string) $m['attendees'] );
			$y += 6;
		}
		if ( '' !== (string) $m['agenda'] ) {
			$put( 'Ordine del giorno', 10, true );
			$put( (string) $m['agenda'] );
			$y += 6;
		}
		$put( 'Svolgimento e deliberazioni', 10, true );
		$put( (string) $m['body'] );
		$y += 10;
		if ( $m['approved_on'] ) {
			$put( 'Verbale letto e approvato il ' . self::d( $m['approved_on'] ) . '.' );
		}
		$y += 24;
		if ( $y > self::BOTTOM - 40 ) {
			$pdf->add_page();
			$y = 80.0;
		}
		$pdf->line( self::LEFT, $y + 24, self::LEFT + 170, $y + 24 );
		$pdf->text( self::LEFT, $y + 37, 'Il Segretario', 9 );
		$pdf->line( self::RIGHT - 170, $y + 24, self::RIGHT, $y + 24 );
		$pres = self::president();
		$pdf->text( self::RIGHT, $y + 37, 'Il Presidente' . ( '' !== $pres ? ' ' . $pres : '' ), 9, false, 'R' );
		$out         = $pdf->output();
		Pdf::$filter = null;
		return array( 'body' => $out, 'filename' => 'verbale-' . str_replace( '/', '-', $m['number'] ) . '-' . $m['kind'] . '.pdf', 'mime' => 'application/pdf' );
	}

	// ---------- Risultati di una votazione ----------

	/** Verbale (PDF) o tabella (CSV) dei risultati. @return array{body:string,filename:string,mime:string} @throws \InvalidArgumentException */
	public static function poll( int $id, string $format = 'pdf' ): array {
		$poll = Polls::get( $id );
		if ( ! $poll ) {
			throw new \InvalidArgumentException( 'Votazione non trovata.' );
		}
		if ( $poll['secret'] && PollRules::CLOSED !== $poll['status'] ) { // a voto aperto i conteggi parziali, confrontati tra un download e l'altro, rivelerebbero le scelte
			throw new \InvalidArgumentException( 'Nel voto segreto i risultati si scaricano a votazione chiusa.' );
		}
		$res  = Polls::results( $id, true );
		$slug = 'risultati-votazione-' . $id;
		if ( 'csv' === $format ) {
			$rows = array();
			foreach ( $res['options'] as $o ) {
				$rows[] = array( $o['label'], $o['count'], $o['percent'] . '%', implode( ', ', $o['names'] ) );
			}
			$cols = array( array( 'label' => 'Risposta' ), array( 'label' => 'Voti' ), array( 'label' => 'Sul totale dei votanti' ), array( 'label' => $poll['secret'] ? 'Chi ha scelto (voto segreto: non registrato)' : 'Chi ha scelto' ) );
			return array( 'body' => self::csv( $cols, $rows ), 'filename' => $slug . '.csv', 'mime' => 'text/csv; charset=utf-8' );
		}
		Pdf::$filter = array( Texts::class, 'plain' );
		$pdf         = new Pdf();
		$y           = self::head( $pdf, 'VERBALE DEI RISULTATI — ' . mb_strtoupper( PollRules::kinds()[ $poll['kind'] ] ), $poll['title'] );
		$w           = self::RIGHT - self::LEFT;
		$put         = function ( string $text, float $size = 10, bool $bold = false ) use ( $pdf, &$y, $w ) {
			foreach ( preg_split( "/\r\n|\n|\r/", $text ) ?: array( '' ) as $para ) {
				foreach ( '' === trim( $para ) ? array( '' ) : Pdf::wrap( $para, $w, $size, $bold ) as $line ) {
					if ( $y > self::BOTTOM ) {
						$pdf->add_page();
						$y = 60.0;
					}
					$pdf->text( self::LEFT, $y, $line, $size, $bold );
					$y += $size + 4;
				}
			}
		};
		$fmt = function ( string $dt ): string {
			return mysql2date( 'd/m/Y H:i', $dt );
		};
		if ( '' !== (string) $poll['question'] ) {
			$put( (string) $poll['question'] );
			$y += 6;
		}
		$aud = PollRules::AUDIENCE_ACTIVITY === $poll['audience'] ? 'iscritti all\'attività «' . ( Plugin::activities()->get( (int) $poll['activity_id'] )['name'] ?? '' ) . '»' : 'tutti i soci in regola';
		$put( 'Votazione aperta dal ' . $fmt( $poll['opens_at'] ) . ' al ' . $fmt( $poll['closes_at'] ) . '. Hanno diritto al voto: ' . $aud . '.' );
		$put( ( $poll['secret'] ? 'Voto segreto: si è registrato chi ha votato, non cosa ha scelto. ' : 'Voto palese. ' ) . ( $poll['multiple'] ? 'Si potevano scegliere più risposte' . ( $poll['max_choices'] ? ' (al massimo ' . (int) $poll['max_choices'] . ')' : '' ) . '.' : 'Si sceglieva una sola risposta.' ) );
		$put( 'Hanno votato ' . $res['voters'] . ' soci su ' . $res['eligible'] . ' con diritto al voto.' );
		$y += 8;
		$put( 'Risultati', 10, true );
		foreach ( $res['options'] as $o ) {
			$put( $o['label'] . ': ' . $o['count'] . ' voti (' . $o['percent'] . '%)' . ( in_array( $o['id'], $res['winners'], true ) ? ' (più votata)' : '' ) );
			if ( $o['names'] ) {
				$put( '   ' . implode( ', ', $o['names'] ), 9 );
			}
		}
		if ( PollRules::CLOSED !== $poll['status'] ) {
			$y += 8;
			$put( 'Attenzione: la votazione non è ancora chiusa, i risultati sono provvisori.', 9, true );
		}
		$y += 8;
		$put( 'Documento generato il ' . self::d( Db::today() ) . '.', 9 );
		$y += 24;
		if ( $y > self::BOTTOM - 40 ) {
			$pdf->add_page();
			$y = 80.0;
		}
		$pdf->line( self::LEFT, $y + 24, self::LEFT + 170, $y + 24 );
		$pdf->text( self::LEFT, $y + 37, 'Il Segretario', 9 );
		$pdf->line( self::RIGHT - 170, $y + 24, self::RIGHT, $y + 24 );
		$pres = self::president();
		$pdf->text( self::RIGHT, $y + 37, 'Il Presidente' . ( '' !== $pres ? ' ' . $pres : '' ), 9, false, 'R' );
		$out         = $pdf->output();
		Pdf::$filter = null;
		return array( 'body' => $out, 'filename' => $slug . '.pdf', 'mime' => 'application/pdf' );
	}

	// ---------- Download ----------

	private static function send( array $doc ): void {
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Content-Type: ' . $doc['mime'] );
		header( 'X-Content-Type-Options: nosniff' );
		header( ( 0 === strpos( $doc['mime'], 'text/csv' ) ? 'Content-Disposition: attachment' : 'Content-Disposition: inline' ) . '; filename="' . preg_replace( '/[^A-Za-z0-9._-]+/', '_', $doc['filename'] ) . '"' );
		header( 'Content-Length: ' . strlen( $doc['body'] ) );
		Download::bytes( (string) $doc['body'] );
		exit;
	}

	public static function handle(): void {
		if ( ! current_user_can( Plugin::CAP_OPS ) ) {
			wp_die( 'Non hai il permesso per questa operazione: chiedilo a un amministratore.', 403 );
		}
		check_admin_referer( 'asem_doc' );
		if ( ! Edition::allows( 'export' ) ) {
			wp_die( 'L\'esportazione dei dati è sospesa perché la licenza di Associazione Semplice non risulta in regola.', 'Licenza non in regola', array( 'response' => 402, 'back_link' => true ) );
		}
		$g      = (array) map_deep( wp_unslash( $_GET ), 'sanitize_text_field' ); // phpcs:ignore WordPress.Security.NonceVerification -- nonce controllato sopra con check_admin_referer()
		$what   = (string) ( $g['what'] ?? '' );
		$format = 'csv' === ( $g['format'] ?? '' ) ? 'csv' : 'pdf';
		try {
			switch ( $what ) {
				case 'book':
					$doc = self::book( (string) ( $g['filter'] ?? '' ), $format, ! empty( $g['year'] ) ? (int) $g['year'] : null, ! empty( $g['version'] ) ? (int) $g['version'] : null );
					break;
				case 'cards':
					$doc = self::cards( (string) ( $g['filter'] ?? '' ), (int) ( $g['per'] ?? 0 ) );
					break;
				case 'minute':
					$doc = self::minute( (int) ( $g['id'] ?? 0 ) );
					break;
				case 'privacy':
					$doc = PrivacyNotice::pdf();
					break;
				case 'poll':
					$doc = self::poll( (int) ( $g['id'] ?? 0 ), $format );
					break;
				case 'items':
					$doc = array( 'body' => Inventory::items_csv(), 'filename' => 'inventario.csv', 'mime' => 'text/csv; charset=utf-8' );
					break;
				case 'loans':
					$doc = array( 'body' => Inventory::loans_csv(), 'filename' => 'prestiti.csv', 'mime' => 'text/csv; charset=utf-8' );
					break;
				default:
					$doc = apply_filters( 'asem_document', null, $what, $g, $format ); // le estensioni forniscono altri documenti
					if ( ! is_array( $doc ) ) {
						wp_die( 'Documento non valido.', 400 );
					}
			}
		} catch ( \InvalidArgumentException $e ) {
			wp_die( esc_html( $e->getMessage() ), 404 );
		}
		Audit::log( 'export.downloaded', 'export', 0, array( 'what' => sanitize_key( $what ), 'format' => $format ) );
		self::send( $doc );
	}
}
