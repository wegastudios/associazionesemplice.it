<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/**
 * Domande di adesione online. Chi non è ancora socio compila il modulo pubblico: la domanda entra come persona con stato «richiesta»
 * (fuori dall'anagrafica, dagli elenchi e dai conti) finché la segreteria non la approva, assegnando il numero di tessera, o la rifiuta.
 *
 * Chi risulta minorenne dalla data di nascita indica anche un genitore o tutore: all'approvazione il genitore viene collegato (ed eventualmente
 * registrato) e riceve il link per entrare nell'area soci, da dove segue il minore. Nessun dato personale va nel registro azioni.
 */
final class Applications {

	const REQUESTED = 'requested';
	const REJECTED  = 'rejected';
	const PAY_DAYS  = 7;
	/** Domanda arrivata dal modulo ma non ancora confermata via email da chi l'ha scritta: non compare in segreteria e non produce altre email. */
	const UNCONFIRMED       = 'unconfirmed';
	const CONFIRM_HOURS     = 48; // validità del link di conferma
	const UNCONFIRMED_DAYS  = 30; // dopo tanti giorni una domanda mai confermata si cancella
	const REJECTED_DAYS     = 90; // dopo tanti giorni dalla risposta una domanda respinta con quota pagata perde tutti i dati tranne il nome

	private static function db(): \wpdb {
		return Db::db();
	}

	public static function enabled(): bool {
		return ! empty( Settings::get( 'apply_enabled' ) ) && Edition::allows( 'member_area' );
	}

	/** Tipi di socio che si possono chiedere: tipo => etichetta. */
	public static function types(): array {
		$out = array( MemberType::ORDINARY => MemberType::label( MemberType::ORDINARY ) );
		if ( ! empty( Settings::get( 'apply_volunteer' ) ) ) {
			$out[ MemberType::VOLUNTEER ] = MemberType::label( MemberType::VOLUNTEER );
		}
		return $out;
	}

	/** Quota associativa per un tipo di socio (centesimi). */
	public static function fee_cents( string $type ): int {
		return Levels::fee_for( array( 'type' => $type, 'level_id' => null, 'family_head_id' => null ) );
	}

	/** La quota si può pagare online dalla domanda? */
	public static function online_payment(): bool {
		return ! empty( Settings::get( 'apply_pay_online' ) ) && Plugin::payments()->enabled() && Plugin::payments()->application_online();
	}

	public static function notify_email(): string {
		$mail = trim( (string) Settings::get( 'apply_email' ) );
		if ( is_email( $mail ) ) {
			return $mail;
		}
		return '' !== Contacts::email() ? Contacts::email() : (string) get_option( 'admin_email' ); // senza avviso dedicato: la segreteria, solo in mancanza l'email del sito
	}

	// ---------- Lettura ----------

	public static function pending_count(): int {
		return (int) self::db()->get_var( 'SELECT COUNT(*) FROM ' . Db::t( 'people' ) . " WHERE deleted_at IS NULL AND application_status = 'requested'" );
	}

	private static function row( int $id ): ?array {
		$row = self::db()->get_row( self::db()->prepare( 'SELECT * FROM ' . Db::t( 'people' ) . " WHERE id = %d AND deleted_at IS NULL AND application_status = 'requested'", $id ), ARRAY_A );
		return $row ?: null;
	}

	/** @return array|null i dati del genitore scritti nella domanda (nome, cognome, email, telefono, codice fiscale) */
	public static function guardian_data( array $row ): ?array {
		$d = json_decode( (string) ( $row['application_data'] ?? '' ), true );
		return is_array( $d ) && ! empty( $d['guardian'] ) && is_array( $d['guardian'] ) ? $d['guardian'] : null;
	}

	/** Domande in attesa, dalla più vecchia. @return array[] persona + 'guardian', 'fee_cents', 'paid', 'suggested_card' */
	public static function pending(): array {
		$rows = self::db()->get_results( 'SELECT * FROM ' . Db::t( 'people' ) . " WHERE deleted_at IS NULL AND application_status = 'requested' ORDER BY application_at, id", ARRAY_A ) ?: array();
		$people = Plugin::people();
		$n      = (int) $people->next_free_card();
		foreach ( $rows as &$r ) {
			$r['guardian']       = self::guardian_data( $r );
			$r['fee_cents']      = self::fee_cents( (string) $r['type'] );
			$r['paid']           = Plugin::payments()->application_paid( (int) $r['id'] );
			while ( $people->find_by_card( (string) $n ) ) { // tessere con lettere o numeri già presi: si salta al primo libero
				$n++;
			}
			$r['suggested_card'] = (string) $n++;
		}
		unset( $r );
		return $rows;
	}

	// ---------- Nuova domanda ----------

	/**
	 * Registra una domanda. Non dice mai se l'email o la persona esistono già: se c'è un doppione, o se la coda è piena, la domanda non viene
	 * registrata e l'esito per chi scrive è lo stesso.
	 *
	 * @param array $in dati del modulo (vedi {@see ApplicationRules::check()})
	 * @return array{status:string,errors:string[]} status: invalid (dati scritti male) | off | ok
	 */
	public static function submit( array $in ): array {
		if ( ! self::enabled() ) {
			return array( 'status' => 'off', 'errors' => array() );
		}
		$chk = ApplicationRules::check( $in, Db::today(), Regulation::enabled(), array_keys( self::types() ) );
		if ( $chk['errors'] ) {
			return array( 'status' => 'invalid', 'errors' => $chk['errors'] );
		}
		$d      = $chk['data'];
		$people = Plugin::people();
		// Tre controlli, tutti eseguiti sempre (nessuno salta gli altri): già nell'anagrafica o in coda per email o codice fiscale, oppure coda piena.
		// Per chi scrive l'esito è lo stesso, e anche il lavoro fatto lo è (vedi decoy_submit).
		$to         = strtolower( (string) ( $chk['minor'] ? $d['guardian']['email'] : $d['email'] ) );
		self::drop_stale_unconfirmed( $d ); // una domanda mai confermata da oltre un'ora non blocca chi riprova: si riscrive e si manda un link nuovo
		$known_mail = '' !== $d['email'] && (bool) $people->find_by_email( $d['email'] );
		$known_tax  = (int) self::db()->get_var( self::db()->prepare( 'SELECT COUNT(*) FROM ' . Db::t( 'people' ) . ' WHERE deleted_at IS NULL AND tax_code = %s', $d['tax_code'] ) ) > 0;
		$queue_full = self::pending_count() >= Limits::get( 'applications_max' ) || self::unconfirmed_count() >= Limits::get( 'applications_max' );
		$too_soon   = false !== get_transient( self::confirm_limit_key( $to ) ); // una sola email l'ora allo stesso indirizzo
		if ( $known_mail || $known_tax || $queue_full || $too_soon ) {
			self::decoy_submit();
			return array( 'status' => 'ok', 'errors' => array() );
		}
		$now = Db::now();
		$ok  = self::db()->insert(
			Db::t( 'people' ),
			array(
				'type'               => $d['type'],
				'first_name'         => $d['first_name'],
				'last_name'          => $d['last_name'],
				'email'              => '' === $d['email'] ? null : $d['email'],
				'phone'              => '' === $d['phone'] ? null : $d['phone'],
				'tax_code'           => $d['tax_code'],
				'birth_date'         => $d['birth_date'],
				'birth_place'        => '' === $d['birth_place'] ? null : $d['birth_place'],
				'image_consent'      => $d['image_ok'] ? 1 : 0,
				'image_consent_at'   => $now,
				'address'            => '' === $d['address'] ? null : $d['address'],
				'zip'                => '' === $d['zip'] ? null : $d['zip'],
				'city'               => '' === $d['city'] ? null : $d['city'],
				'province'           => '' === $d['province'] ? null : $d['province'],
				'joined_on'          => Db::today(),
				'application_status' => self::UNCONFIRMED,
				'application_at'     => $now,
				'application_data'   => $chk['minor'] ? wp_json_encode( array( 'guardian' => $d['guardian'] ) ) : null,
				'created_at'         => $now,
				'updated_at'         => $now,
			)
		);
		if ( ! $ok ) {
			return array( 'status' => 'ok', 'errors' => array() );
		}
		$id = (int) self::db()->insert_id;
		Privacy::set_consent( $id, 'web' ); // informativa accettata nel modulo (per un minore, dal genitore: lo si registra all'approvazione)
		if ( Regulation::enabled() ) {
			Regulation::accept( $id, 'web' ); // con la versione in vigore
		}
		Audit::log( 'application.received', 'person', $id, array( 'minor' => $chk['minor'] ? 1 : 0 ) );
		set_transient( self::confirm_limit_key( $to ), 1, HOUR_IN_SECONDS );
		self::mail_confirm( $id, $d, $chk['minor'] ); // la segreteria la vede solo dopo il clic sul link (vedi confirm())
		return array( 'status' => 'ok', 'errors' => array() );
	}

	// ---------- Conferma via email ----------

	private static function confirm_limit_key( string $to ): string {
		return 'asem_apc_' . md5( $to );
	}

	public static function unconfirmed_count(): int {
		return (int) self::db()->get_var( 'SELECT COUNT(*) FROM ' . Db::t( 'people' ) . " WHERE deleted_at IS NULL AND application_status = 'unconfirmed'" );
	}

	/** Toglie le domande ancora da confermare, scritte da oltre un'ora, con la stessa email o lo stesso codice fiscale della nuova. */
	private static function drop_stale_unconfirmed( array $d ): void {
		$db = self::db();
		$db->query(
			$db->prepare(
				'DELETE FROM ' . Db::t( 'people' ) . " WHERE application_status = 'unconfirmed' AND application_at < %s AND ( ( %s <> '' AND tax_code = %s ) OR ( %s <> '' AND email = %s ) )",
				gmdate( 'Y-m-d H:i:s', strtotime( Db::now() ) - HOUR_IN_SECONDS ),
				(string) $d['tax_code'],
				(string) $d['tax_code'],
				(string) $d['email'],
				(string) $d['email']
			)
		);
	}

	private static function confirm_secret(): string {
		return wp_salt( 'auth' ) . '|apply-confirm';
	}

	public static function confirm_param( int $person_id ): string {
		return ActivationToken::param( $person_id, time() + self::CONFIRM_HOURS * HOUR_IN_SECONDS, self::confirm_secret(), 'applyconfirm' );
	}

	public static function confirm_url( int $person_id ): string {
		return add_query_arg( 'asem_apply_confirm', self::confirm_param( $person_id ), home_url( '/' ) );
	}

	/** @return array{status:string,person:?array} status: ok | invalid | expired | closed (già confermata o non più presente) */
	public static function resolve_confirm( string $param ): array {
		$state = ActivationToken::check( $param, self::confirm_secret(), time(), 'applyconfirm' );
		if ( 'ok' !== $state ) {
			return array( 'status' => $state, 'person' => null );
		}
		$row = self::db()->get_row( self::db()->prepare( 'SELECT * FROM ' . Db::t( 'people' ) . " WHERE id = %d AND deleted_at IS NULL AND application_status = 'unconfirmed'", (int) ActivationToken::parse( $param )[0] ), ARRAY_A );
		return $row ? array( 'status' => 'ok', 'person' => $row ) : array( 'status' => 'closed', 'person' => null );
	}

	/**
	 * Chi ha scritto la domanda conferma dal link ricevuto: da qui la domanda è in segreteria e a chi l'ha scritta va la ricevuta (con il link per pagare la quota).
	 * Il link vale una volta sola e per CONFIRM_HOURS ore. @return bool false se il link non vale (scaduto, già usato, inventato)
	 */
	public static function confirm( string $param ): bool {
		$r = self::resolve_confirm( $param );
		if ( 'ok' !== $r['status'] ) {
			return false;
		}
		$p   = $r['person'];
		$now = Db::now();
		$n   = self::db()->update( Db::t( 'people' ), array( 'application_status' => self::REQUESTED, 'application_at' => $now, 'updated_at' => $now ), array( 'id' => (int) $p['id'], 'application_status' => self::UNCONFIRMED ) );
		if ( 1 !== (int) $n ) {
			return false; // un altro clic, in contemporanea, l'ha già confermata
		}
		$g = self::guardian_data( $p );
		$d = array( 'type' => (string) $p['type'], 'first_name' => (string) $p['first_name'], 'last_name' => (string) $p['last_name'], 'email' => (string) $p['email'], 'guardian' => $g );
		Audit::log( 'application.confirmed', 'person', (int) $p['id'], array() );
		self::mail_secretary( $d, null !== $g );
		self::mail_applicant( (int) $p['id'], $d, null !== $g );
		return true;
	}

	/** Email con il link di conferma: saluto e frasi sono sempre gli stessi (nessun testo scelto da chi compila il modulo). */
	private static function mail_confirm( int $id, array $d, bool $minor ): void {
		$to   = $minor ? $d['guardian']['email'] : $d['email'];
		$text = "Ciao,\n\nè arrivata una domanda di adesione che indica questo indirizzo email. Per mandarla alla segreteria devi confermarla: il link vale " . self::CONFIRM_HOURS . " ore.\n\nConferma la domanda:\n" . self::confirm_url( $id ) . "\n\nSe la domanda non l'hai fatta tu, ignora questo messaggio: non succede nulla.";
		ResponseMail::send( $to, \AssociazioneSemplice\Texts::subject( 'Conferma la domanda di adesione' ), $text );
	}

	/**
	 * Pulizia giornaliera: le domande mai confermate da UNCONFIRMED_DAYS giorni spariscono; le respinte con quota pagata, da REJECTED_DAYS giorni dalla risposta,
	 * perdono ogni dato tranne il nome (resta sui movimenti di prima nota, che si conservano per legge: incasso e rimborso).
	 */
	public static function purge(): void {
		$db  = self::db();
		$t   = Db::t( 'people' );
		$now = Db::now();
		$unconfirmed = 0;
		foreach ( $db->get_col( $db->prepare( "SELECT id FROM $t WHERE application_status = 'unconfirmed' AND application_at < %s", gmdate( 'Y-m-d H:i:s', strtotime( $now ) - self::UNCONFIRMED_DAYS * DAY_IN_SECONDS ) ) ) as $id ) {
			$db->delete( $t, array( 'id' => (int) $id ) );
			$unconfirmed++;
		}
		$rejected = 0;
		foreach ( $db->get_col( $db->prepare( "SELECT id FROM $t WHERE application_status = 'rejected' AND anonymized_at IS NULL AND deleted_at < %s", gmdate( 'Y-m-d H:i:s', strtotime( $now ) - self::REJECTED_DAYS * DAY_IN_SECONDS ) ) ) as $id ) {
			$db->update(
				$t,
				array(
					'email' => null, 'phone' => null, 'tax_code' => null, 'birth_date' => null, 'birth_place' => null, 'address' => null, 'zip' => null, 'city' => null, 'province' => null,
					'application_data' => null, 'image_consent' => 0, 'image_consent_at' => null, 'privacy_consent_at' => null, 'privacy_consent_source' => null, 'rules_accepted_at' => null,
					'rules_accepted_version' => null, 'rules_accepted_source' => null, 'anonymized_at' => $now, 'updated_at' => $now,
				),
				array( 'id' => (int) $id )
			);
			$rejected++;
		}
		if ( $unconfirmed + $rejected > 0 ) {
			Audit::log( 'application.purged', 'person', 0, array( 'unconfirmed' => $unconfirmed, 'rejected' => $rejected ) );
		}
	}

	/**
	 * Per una domanda che non si registra (doppione, coda piena): le stesse scritture di una domanda vera (la riga, il consenso, il registro), senza
	 * che nessuna riga corrisponda. Il tempo di risposta non dipende dall'esito (non è uno sleep) e le email partono comunque dopo la risposta.
	 */
	private static function decoy_submit(): void {
		$db = self::db();
		for ( $i = 0; $i < 8; $i++ ) { // quante ne fa una domanda vera tra riga, consenso, regolamento e registro
			$db->update( Db::t( 'people' ), array( 'updated_at' => Db::now() ), array( 'id' => 0 ) );
		}
	}

	private static function assoc_suffix(): string {
		$assoc = (string) Settings::get( 'association_name' );
		return '' !== $assoc ? ' — ' . $assoc : '';
	}

	private static function mail_secretary( array $d, bool $minor ): void {
		$who  = ApplicationRules::mail_name( $d['first_name'] ) . ' ' . ApplicationRules::mail_name( $d['last_name'] );
		$text = "È arrivata una nuova domanda di adesione.\n\n" . $who . ' (' . ( $minor ? 'minorenne, con un genitore indicato' : MemberType::label( $d['type'] ) ) . ")\n\n"
			. 'Approvala o rifiutala dalla Bacheca: ' . admin_url( 'admin.php?page=asem' );
		ResponseMail::send( self::notify_email(), \AssociazioneSemplice\Texts::subject( 'Nuova domanda di adesione' ), $text );
	}

	/** Conferma a chi ha chiesto di iscriversi (per un minore, al genitore): cosa succede adesso e come pagare la quota. */
	private static function mail_applicant( int $id, array $d, bool $minor ): void {
		$to   = $minor ? $d['guardian']['email'] : $d['email'];
		$name = ApplicationRules::mail_name( $minor ? $d['guardian']['first_name'] : $d['first_name'] );
		$fee  = self::fee_cents( $d['type'] );
		$text = 'Ciao ' . $name . ",\n\nabbiamo ricevuto la domanda di adesione" . ( $minor ? ' di ' . ApplicationRules::mail_name( $d['first_name'] ) : '' ) . ". La segreteria la esamina e ti risponde per email.\n\n";
		if ( $fee > 0 ) {
			if ( self::online_payment() ) {
				$text .= 'La quota associativa è di ' . Money::format( $fee ) . '. Se vuoi puoi pagarla subito online da questo link (vale ' . self::PAY_DAYS . " giorni):\n" . self::pay_url( $id ) . "\n\nSe la domanda non viene accettata, ti restituiamo la quota.\n\n";
			} else {
				$text .= 'La quota associativa è di ' . Money::format( $fee ) . ": si paga in sede, alla segreteria.\n\n";
			}
		}
		$text .= 'Se non hai fatto tu la domanda, ignora questo messaggio.';
		ResponseMail::send( $to, \AssociazioneSemplice\Texts::subject( 'Domanda di adesione ricevuta' ), $text );
	}

	// ---------- Pagamento della quota ----------

	private static function secret(): string {
		return wp_salt( 'auth' ) . '|apply-pay';
	}

	public static function pay_url( int $person_id ): string {
		return add_query_arg( 'asem_apply_pay', ActivationToken::param( $person_id, time() + self::PAY_DAYS * DAY_IN_SECONDS, self::secret(), 'applypay' ), home_url( '/' ) );
	}

	/** @return array{status:string,person:?array} status: ok | invalid | expired | closed (domanda già lavorata) */
	public static function resolve_pay( string $param ): array {
		$state = ActivationToken::check( $param, self::secret(), time(), 'applypay' );
		if ( 'ok' !== $state ) {
			return array( 'status' => $state, 'person' => null );
		}
		$p = self::row( (int) ActivationToken::parse( $param )[0] );
		return $p ? array( 'status' => 'ok', 'person' => $p ) : array( 'status' => 'closed', 'person' => null );
	}

	// ---------- Approvazione e rifiuto ----------

	/**
	 * Approva una domanda: assegna la tessera e manda il link per scegliere la password. L'iscrizione all'anno sociale si registra con l'incasso della
	 * quota: subito se è stata pagata online con la domanda (o non c'è quota), altrimenti quando la segreteria la incassa. Per un minore collega il genitore (registrandolo se non c'è) e scrive a lui.
	 *
	 * @return string messaggio per la segreteria
	 * @throws \InvalidArgumentException
	 */
	public static function approve( int $id, string $card = '' ): string {
		$row = self::row( $id );
		if ( ! $row ) {
			throw new \InvalidArgumentException( 'Domanda non trovata: forse è già stata approvata o rifiutata.' );
		}
		$people = Plugin::people();
		$card   = trim( $card );
		if ( '' === $card ) {
			$card = $people->next_free_card();
		}
		if ( strlen( $card ) > 40 ) {
			throw new \InvalidArgumentException( 'Il numero di tessera è troppo lungo (massimo 40 caratteri).' );
		}
		$holder = $people->find_by_card( $card, $id );
		if ( $holder ) {
			throw new \InvalidArgumentException( 'La tessera ' . $card . ' è già assegnata a ' . $people->full_name( $holder ) . '.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$gd       = self::guardian_data( $row );
		$guardian = null;
		$created  = false;
		$confirm  = false;
		if ( $gd ) {
			$guardian = $people->find_by_email( strtolower( (string) $gd['email'] ), $id );
			if ( $guardian && ! empty( $guardian['application_status'] ) ) {
				throw new \InvalidArgumentException( 'Il genitore ha chiesto a sua volta di iscriversi con la stessa email: approva prima la sua domanda.' );
			}
			if ( $guardian && ! MemberType::can_login( (string) $guardian['type'] ) ) {
				throw new \InvalidArgumentException( 'L\'email del genitore è già usata da un ospite, che non può entrare nell\'area soci: iscrivilo come socio o cambia l\'email, poi riprova.' );
			}
		}
		$year = Settings::membership_year()->label();
		if ( $gd && ! $guardian ) {
			$guardian_id = self::register_guardian( $gd );
			$guardian    = $people->get( $guardian_id );
			$created     = true;
		}
		self::db()->update(
			Db::t( 'people' ),
			array( 'card_number' => $card, 'joined_on' => Db::today(), 'approved_on' => Db::today(), 'application_status' => null, 'application_data' => null, 'updated_at' => Db::now() ),
			array( 'id' => $id )
		);
		MemberBook::ensure_matricola( $id ); // ammesso: entra nel libro soci con la sua matricola
		// L'iscrizione all'anno si registra solo con l'incasso della quota (pagata online con la domanda, oppure in sede o dall'area soci): senza quota da pagare vale subito.
		$due = 0;
		if ( ! Plugin::payments()->application_settle( $id, $year ) ) {
			$due = self::fee_cents( (string) $row['type'] );
			if ( $due <= 0 ) {
				$people->set_membership( $id, $year, true, 'application' );
			}
		}
		if ( $guardian ) {
			// Un genitore già in anagrafica (non creato ora da questa domanda) deve prima confermare: finché non lo fa non gli si attribuiscono i consensi e non si crea il collegamento con il minore (nasce alla conferma).
			if ( ! $created ) {
				$confirm = true;
			} else {
				Guardians::link( $id, (int) $guardian['id'] );
				self::db()->update( Db::t( 'people' ), array( 'image_consent_by' => (int) $guardian['id'] ), array( 'id' => $id ) ); // la liberatoria immagini del minore la risponde il genitore
				// A nome del minore hanno accettato regolamento e privacy il genitore: resta registrato chi.
				self::db()->update( Db::t( 'people' ), array( 'rules_accepted_by' => Regulation::enabled() ? (int) $guardian['id'] : null, 'privacy_consent_by' => (int) $guardian['id'] ), array( 'id' => $id ) );
			}
		}
		Audit::log( 'application.approved', 'person', $id, array( 'guardian' => $guardian ? (int) $guardian['id'] : 0 ) );
		self::mail_approved( $people->get( $id ), $guardian, $due, ! $confirm );
		if ( $confirm ) {
			GuardianConsent::begin( $id, (int) $guardian['id'] ); // all'indirizzo già registrato per il genitore
		}
		$msg = 'Domanda approvata: tessera n. ' . $card . '. ' . ( $guardian ? 'L\'email al genitore è stata inviata.' : 'Il link per scegliere la password è stato inviato al nuovo socio.' );
		if ( $confirm ) {
			$msg .= ' Il genitore è già in anagrafica: gli è stata inviata un\'email per confermare che ha accettato lui, a nome del minore, regolamento, privacy e immagini. Finché non conferma, il collegamento con il minore non si crea e le accettazioni non risultano a suo nome (lo vedi nella scheda del minore).';
		}
		if ( $due > 0 ) {
			$msg .= ' Quota da incassare: ' . Money::format( $due ) . ' (in sede o dall\'area soci); la tessera diventa valida all\'incasso.';
		}
		if ( $created ) {
			$msg .= ' Il genitore è registrato come «genitore o tutore» (non socio): ha solo l\'accesso per seguire il figlio, senza tessera né quota.';
		}
		return $msg;
	}

	/** Registra il genitore indicato nella domanda come persona (senza accesso: lo attiva dal link ricevuto). @return int id */
	private static function register_guardian( array $g ): int {
		$now = Db::now();
		if ( Plugin::people()->find_by_email( strtolower( (string) $g['email'] ) ) ) {
			throw new \InvalidArgumentException( 'L\'email del genitore è già usata da un\'altra persona: modifica la domanda o la scheda di chi la usa, poi riprova.' );
		}
		self::db()->insert(
			Db::t( 'people' ),
			array(
				'type'       => MemberType::GUARDIAN,
				'first_name' => mb_substr( (string) $g['first_name'], 0, 120 ),
				'last_name'  => mb_substr( (string) $g['last_name'], 0, 120 ),
				'email'      => strtolower( (string) $g['email'] ),
				'phone'      => (string) $g['phone'],
				'tax_code'   => '' === (string) ( $g['tax_code'] ?? '' ) ? null : (string) $g['tax_code'],
				'joined_on'  => Db::today(),
				'created_at' => $now,
				'updated_at' => $now,
			)
		);
		$id = (int) self::db()->insert_id;
		if ( $id <= 0 ) {
			throw new \InvalidArgumentException( 'Genitore non registrato: riprova.' );
		}
		Privacy::set_consent( $id, 'web' );
		Audit::log( 'person.created', 'person', $id, array( 'type' => MemberType::GUARDIAN, 'from' => 'application' ) );
		return $id;
	}

	private static function mail_approved( ?array $person, ?array $guardian, int $due = 0, bool $linked = true ): void {
		if ( ! $person ) {
			return;
		}
		$assoc = (string) Settings::get( 'association_name' );
		$of    = '' !== $assoc ? ' a ' . $assoc : '';
		$days  = Frontend\Activation::validity_text();
		$pay   = '';
		if ( $due > 0 ) {
			$pay = "\n\nLa tessera diventa valida appena versi la quota associativa di " . Money::format( $due ) . ': in sede, alla segreteria' . ( Plugin::payments()->enabled() ? ', oppure online dall\'area soci (voce «Pagamenti»)' : '' ) . '.';
		}
		if ( $guardian ) {
			$text = 'Ciao ' . ApplicationRules::mail_name( (string) $guardian['first_name'] ) . ",\n\nla domanda di adesione di " . ApplicationRules::mail_name( (string) $person['first_name'] ) . ' ' . ApplicationRules::mail_name( (string) $person['last_name'] ) . ' è stata approvata: la tessera è la n. ' . $person['card_number'] . ".\n\n";
			if ( ! $linked ) { // genitore già in anagrafica: il collegamento nasce quando conferma dal link dell'altra email
				$text .= 'Per vedere ' . ApplicationRules::mail_name( (string) $person['first_name'] ) . ' nella tua area soci, conferma dal link che ti abbiamo mandato in un\'altra email.' . "\n";
			} elseif ( empty( $guardian['wp_user_id'] ) ) {
				$text .= 'Da genitore o tutore segui ' . $person['first_name'] . ' dalla tua area soci (tessera, prenotazioni, pagamenti). Scegli la tua password da questo link (vale ' . $days . "):\n" . Frontend\Activation::url( (int) $guardian['id'] ) . "\n";
			} else {
				$text .= $person['first_name'] . ' compare ora nella tua area soci: ' . Gatekeeper::area_url() . "\n";
			}
			$text .= $pay;
			$to = (string) $guardian['email'];
		} else {
			$text = 'Ciao ' . ApplicationRules::mail_name( (string) $person['first_name'] ) . ",\n\nla tua domanda di adesione" . $of . ' è stata approvata: la tua tessera è la n. ' . $person['card_number'] . ".\n\nScegli la tua password da questo link (vale " . $days . "):\n" . Frontend\Activation::url( (int) $person['id'] )
				. "\n\nSe il link scade, dal sito vai su «Primo accesso» e ne ricevi uno nuovo." . $pay;
			$to = (string) $person['email'];
		}
		if ( '' !== $to && is_email( $to ) ) {
			Texts::mail( $to, \AssociazioneSemplice\Texts::subject( 'Domanda di adesione approvata' ), $text );
		}
	}

	/**
	 * Rifiuta una domanda. Se la quota era stata pagata online il pagamento resta segnato «da rimborsare»; senza pagamento la domanda sparisce del tutto,
	 * senza lasciare dati personali. A chi l'ha inviata (per un minore, al genitore) arriva un breve messaggio.
	 *
	 * @return string messaggio per la segreteria
	 * @throws \InvalidArgumentException
	 */
	public static function reject( int $id ): string {
		$row = self::row( $id );
		if ( ! $row ) {
			throw new \InvalidArgumentException( 'Domanda non trovata: forse è già stata approvata o rifiutata.' );
		}
		$gd     = self::guardian_data( $row );
		$to     = $gd ? (string) $gd['email'] : (string) $row['email'];
		$name   = ApplicationRules::mail_name( $gd ? (string) $gd['first_name'] : (string) $row['first_name'] );
		$refund = Plugin::payments()->application_refund_due( $id );
		if ( $refund > 0 ) { // il nome serve a riconoscere il pagamento da restituire; il resto si cancella
			self::db()->update(
				Db::t( 'people' ),
				array( 'application_status' => self::REJECTED, 'deleted_at' => Db::now(), 'tax_code' => null, 'phone' => null, 'birth_date' => null, 'application_data' => null, 'updated_at' => Db::now() ),
				array( 'id' => $id )
			);
		} else {
			self::db()->delete( Db::t( 'people' ), array( 'id' => $id ) );
		}
		Audit::log( 'application.rejected', 'person', $id, array( 'refund' => $refund ) );
		if ( '' !== $to && is_email( $to ) ) {
			$text = 'Ciao ' . $name . ",\n\npurtroppo la domanda di adesione" . ( $gd ? ' di ' . ApplicationRules::mail_name( (string) $row['first_name'] ) : '' ) . ' non è stata accettata.'
				. ( $refund > 0 ? "\n\nLa quota che hai pagato online ti sarà restituita." : '' ) . "\n\nPer chiarimenti scrivi alla segreteria: i recapiti sono in fondo a questa email.";
			Texts::mail( $to, \AssociazioneSemplice\Texts::subject( 'Esito della domanda di adesione' ), $text );
		}
		return 'Domanda rifiutata.' . ( $refund > 0 ? ' Il pagamento online risulta «da rimborsare» nei Pagamenti online.' : '' );
	}
}
