<?php
namespace AssociazioneSemplice\Admin;

use AssociazioneSemplice\Edition;
use AssociazioneSemplice\Guide;
use AssociazioneSemplice\Html;

defined( 'ABSPATH' ) || exit;

/** Guida iniziale: cosa fare per cominciare, le funzioni facoltative e le risposte alle domande più comuni. */
final class GuidePage {

	/**
	 * Domande frequenti. Le risposte rimandano solo a schede che esistono nell'edizione in uso: presenze, comunicazioni, rendiconto, cassa per più
	 * persone e testi compaiono come nel menu solo se la funzione c'è; altrimenti la risposta dice cosa si fa nel gratuito.
	 *
	 * @return array<string,string> domanda => risposta
	 */
	public static function faq(): array {
		$pro_cash = Edition::has( 'funds' ) ? ' Per più persone insieme usa «Cassa per più persone».' : '';
		$out      = array(
			'Come iscrivo un nuovo socio?'            => 'Rubrica soci → Soci e ospiti → «Nuovo socio». Con l\'email il socio ha subito l\'accesso all\'area soci; senza email si attiva dopo, con un link da mandargli su WhatsApp. Per molti soci insieme usa «Importa da Excel/CSV».',
			'Come incasso una quota o un contributo?' => 'Cassa → Nuovo incasso (o la cassa rapida in Bacheca). Scegli la persona: il plugin propone la quota associativa, le mensilità dei corsi dovute e gli eventi.' . $pro_cash,
			'Come creo un corso o un evento?'         => 'Corsi ed eventi → «Nuova attività». Le date si scrivono a righe: date uniche o giorni che si ripetono ogni settimana. I corsi si rinnovano ogni mese; gli eventi si prenotano a una data.',
			'Come registro le presenze?'              => Edition::has( 'insurance' )
				? 'Registri → Presenze: scegli il corso, il mese e la lezione, spunta chi era presente e salva. Il riepilogo si scarica in PDF o CSV.'
				: 'Il registro delle presenze fa parte di Associazione Semplice Pro. Nella versione gratuita puoi segnare l\'ingresso agli eventi dalla scheda dell\'evento (Corsi ed eventi → apri l\'evento → «Registra ingresso»).',
			'Come invio un messaggio ai soci?'        => Edition::has( 'broadcasts' )
				? 'Rubrica soci → Comunicazioni: scegli il gruppo (soci in regola, scaduti, iscritti a un corso…), scrivi il messaggio, controlla i destinatari e invia.'
				: 'Dalla scheda di un corso o evento, riquadro «Avvisi agli iscritti». L\'invio a gruppi di soci (in regola, scaduti…) fa parte di Associazione Semplice Pro.',
		);
		if ( Edition::has( 'fiscal' ) ) {
			$out['Dove trovo ricevute e rendiconto?'] = 'Le ricevute si scaricano dalla prima nota e dall\'area soci. Il rendiconto per cassa è in Contabilità → Rendiconto, in PDF con le firme.';
		} else {
			$out['Dove trovo l\'elenco di entrate e uscite?'] = 'In Cassa → Prima nota (la prima nota è l\'elenco di tutte le entrate e uscite). Per il commercialista: Strumenti → Esporta. Ricevute e rendiconto per cassa fanno parte di Associazione Semplice Pro.';
		}
		$out['Come cambio i testi o i termini?'] = ( Edition::has( 'texts' ) ? 'In' : 'Con Associazione Semplice Pro, in' ) . ' Impostazioni → Testi personalizzati: puoi scegliere il tipo di ente («socio»/«socia», «iscritto», «sostenitore»…), cambiare ogni frase e anche passare a un\'altra lingua.';
		$out['Come faccio una copia dei dati?']  = 'Strumenti → Copia di sicurezza: scarichi un file con tutti i dati; da lì puoi anche ripristinarlo.';
		return $out;
	}

	public static function render(): void {
		Ui::header( 'Guida iniziale' );
		$p = Guide::progress();
		echo '<p>Per mettere in funzione Associazione Semplice ci sono pochi passi: ' . (int) $p['done'] . ' su ' . (int) $p['total'] . ' già fatti.</p>';
		echo '<table class="widefat striped"><tbody>';
		foreach ( Guide::steps() as $s ) {
			echo '<tr><td style="width:2em">' . ( $s['done'] ? '✅' : '⬜' ) . '</td><td><strong>' . esc_html( $s['title'] ) . '</strong><br><span class="description">' . esc_html( $s['hint'] ) . '</span></td>'
				. '<td style="text-align:right">' . ( $s['done'] ? '<span class="description">fatto</span>' : '<a class="button" href="' . esc_url( Ui::url( $s['page'] ) ) . '">Vai</a>' ) . '</td></tr>';
		}
		echo '</tbody></table>';

		echo '<h2>Funzioni facoltative</h2><p class="description">Sono spente finché non le attivi: accendi solo quelle che ti servono.</p><table class="widefat striped"><tbody>';
		foreach ( Guide::options() as $o ) {
			echo '<tr><td><strong>' . esc_html( $o['title'] ) . '</strong><br><span class="description">' . esc_html( $o['hint'] ) . '</span></td><td>' . ( $o['on'] ? 'Attiva' : 'Spenta' ) . '</td>'
				. '<td style="text-align:right"><a class="button" href="' . esc_url( Ui::url( $o['page'] ) ) . '">' . ( $o['on'] ? 'Gestisci' : 'Attiva' ) . '</a></td></tr>';
		}
		echo '</tbody></table>';

		echo '<h2>Domande frequenti</h2>';
		foreach ( self::faq() as $q => $a ) {
			echo '<details class="asem-card"><summary><strong>' . esc_html( $q ) . '</strong></summary><p>' . esc_html( $a ) . '</p></details>';
		}

		$uid = get_current_user_id();
		Ui::form_open( 'asem_guide_dismiss', Ui::url( 'asem-guide' ), false, 'asem-inline' );
		if ( Guide::dismissed( $uid ) ) {
			echo wp_kses( Ui::hidden( 'on', '0' ) . '<p><button class="button">Mostra di nuovo l\'avviso in Bacheca</button></p>', Html::allowed() );
		} else {
			echo wp_kses( Ui::hidden( 'on', '1' ) . '<p><button class="button">Nascondi l\'avviso in Bacheca</button></p>', Html::allowed() );
		}
		Ui::form_close();
		Ui::footer();
	}
}
