<?php
namespace AssociazioneSemplice\Admin;

use AssociazioneSemplice\Money;
use AssociazioneSemplice\PaymentCalc;
use AssociazioneSemplice\Html;

defined( 'ABSPATH' ) || exit;

/** Piccoli helper per scrivere le pagine di amministrazione. */
final class Ui {

	const MONTHS = array( 1 => 'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre' );

	public static function url( string $page, array $args = array() ): string {
		return add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) );
	}

	public static function get_int( string $key, int $default = 0 ): int {
		return isset( $_GET[ $key ] ) ? (int) $_GET[ $key ] : $default; // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function get_str( string $key, string $default = '' ): string {
		return isset( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) : $default; // phpcs:ignore WordPress.Security.NonceVerification
	}

	/** Link per scrivere a una persona: email (mailto) e WhatsApp (se ha il cellulare). */
	public static function contact_links( array $p ): string {
		$out = array();
		if ( ! empty( $p['email'] ) ) {
			$out[] = '<a href="' . esc_url( 'mailto:' . $p['email'] ) . '" title="' . esc_attr( (string) $p['email'] ) . '">✉ Email</a>';
		}
		$wa = ! empty( $p['phone'] ) ? \AssociazioneSemplice\Phone::whatsapp( (string) $p['phone'] ) : '';
		if ( '' !== $wa ) {
			$out[] = '<a href="' . esc_url( 'https://wa.me/' . $wa ) . '" target="_blank" rel="noopener" title="' . esc_attr( (string) $p['phone'] ) . '">💬 WhatsApp</a>';
		}
		return implode( ' · ', $out );
	}

	public static function header( string $title, string $actions_html = '' ): void {
		\AssociazioneSemplice\Texts::start_admin_buffer(); // testi personalizzati anche in amministrazione
		echo wp_kses( '<div class="wrap asem asem-ui"><h1 class="wp-heading-inline">' . esc_html( $title ) . '</h1> ' . $actions_html . '<hr class="wp-header-end">', Html::allowed() );
		echo wp_kses( Admin::tabs( isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '' ), Html::allowed() ); // phpcs:ignore WordPress.Security.NonceVerification
		self::notices();
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'asem-wizard' !== $page ) { // promemoria fisso dei contatti della segreteria, in tutte le pagine del plugin (nei dati dell'ente senza pulsante)
			echo wp_kses( \AssociazioneSemplice\MissingBand::html( $page ), Html::allowed() );
		}
	}

	/** Piccolo script di una pagina, accodato con le funzioni di WordPress (parte nel piè di pagina, a pagina costruita). */
	public static function inline_js( string $js ): void {
		static $n = 0;
		$handle = 'asem-inline-' . ( ++$n );
		wp_register_script( $handle, false, array(), ASEM_VERSION, true );
		wp_enqueue_script( $handle );
		wp_add_inline_script( $handle, $js );
	}


	/** Icona in linea decorativa (vedi {@see \AssociazioneSemplice\Icons}). */
	public static function icon( string $name ): string {
		return \AssociazioneSemplice\Icons::svg( $name );
	}

	/**
	 * Etichetta di stato: fondo chiaro, testo scuro e sempre una parola (il colore da solo non basta).
	 *
	 * @param string $kind ok | warn | danger | info | neutral
	 */
	public static function badge( string $kind, string $label ): string {
		$kind = in_array( $kind, array( 'ok', 'warn', 'danger', 'info', 'neutral' ), true ) ? $kind : 'neutral';
		return '<span class="asem-badge asem-badge-' . $kind . '">' . esc_html( $label ) . '</span>';
	}

	/** Cerchio con le iniziali; il colore (uno dei tre del marchio) è sempre lo stesso per lo stesso nome. */
	public static function avatar( string $name ): string {
		$words = preg_split( '/\s+/u', trim( $name ), -1, PREG_SPLIT_NO_EMPTY );
		$ini   = '';
		foreach ( array_slice( (array) $words, 0, 2 ) as $w ) {
			$ini .= mb_strtoupper( mb_substr( $w, 0, 1 ) );
		}
		return '<span class="asem-avatar asem-av-' . ( abs( crc32( mb_strtolower( $name ) ) ) % 3 ) . '" aria-hidden="true">' . esc_html( '' !== $ini ? $ini : '?' ) . '</span>';
	}

	/**
	 * Stato di una riga: etichetta con fondo chiaro. Il testo è già escapato da chi chiama o è solo testo.
	 *
	 * @param string $kind ok | warn | danger | neutral
	 */
	public static function state( string $kind, string $label ): string {
		return self::badge( $kind, $label );
	}
	public static function footer(): void {
		echo '</div>';
	}

	public static function notices(): void {
		$msg = \AssociazioneSemplice\Flash::read( 'asem' ); // solo messaggi scritti dal sito (firmati)
		$ok  = $msg['ok'];
		$err = $msg['err'];
		if ( '' !== $ok ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $ok ) . '</p></div>';
		}
		if ( '' !== $err ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $err ) . '</p></div>';
		}
	}

	/** Apre un form che invia a admin-post.php con nonce e URL di ritorno. */
	public static function form_open( string $action, string $back_url, bool $multipart = false, string $class = '' ): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $multipart ? ' enctype="multipart/form-data"' : '' ) . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . '>';
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
		echo '<input type="hidden" name="_back" value="' . esc_url( $back_url ) . '">';
		wp_nonce_field( $action );
		if ( in_array( $action, self::ONCE_ACTIONS, true ) ) {
			echo '<input type="hidden" name="_once" value="' . esc_attr( wp_generate_uuid4() ) . '">'; // gettone monouso: un secondo invio dello stesso modulo non registra due volte
		}
	}

	/** Moduli di prima nota che portano un gettone monouso. */
	const ONCE_ACTIONS = array( 'asem_save_income', 'asem_save_expense', 'asem_save_transfer' );

	/**
	 * Pulsante che invia subito un'azione dopo una sola conferma del browser (per le operazioni che non toccano la prima nota).
	 *
	 * @param array<string,scalar> $fields campi nascosti
	 */
	public static function confirm_button( string $action, string $back_url, array $fields, string $label, string $confirm_text, string $style = '' ): string {
		$html = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">'
			. '<input type="hidden" name="action" value="' . esc_attr( $action ) . '"><input type="hidden" name="_back" value="' . esc_url( $back_url ) . '">'
			. wp_nonce_field( $action, '_wpnonce', true, false );
		foreach ( $fields as $k => $v ) {
			$html .= '<input type="hidden" name="' . esc_attr( (string) $k ) . '" value="' . esc_attr( (string) $v ) . '">';
		}
		return $html . '<button class="button button-small" data-confirm="' . esc_attr( $confirm_text ) . '"' . ( '' !== $style ? ' style="' . esc_attr( $style ) . '"' : '' ) . '>' . esc_html( $label ) . '</button></form>';
	}

	public static function form_close(): void {
		echo '</form>';
	}

	/**
	 * Riga del modulo per l'IVA (solo se l'ente applica l'IVA): aliquota e se l'importo scritto è IVA compresa o esclusa.
	 *
	 * @param ?int   $rate       aliquota attuale (null = fuori campo IVA)
	 * @param string $mode       importo indicato: 'incl' o 'escl'
	 * @param string $what       a cosa si riferisce («Contributo», «Importo»…)
	 */
	public static function vat_row( ?int $rate, string $mode, string $what = 'Gli importi', bool $auto = false ): string {
		return (string) apply_filters( 'asem_vat_row', '', $rate, $mode, $what, $auto ); // senza un'estensione fiscale i moduli non mostrano nulla di fiscale
	}

	/** Il modulo ha lasciato l'aliquota su «Automatica»? */
	public static function vat_is_auto( array $p ): bool {
		return 'auto' === (string) ( $p['vat_rate'] ?? '' );
	}

	/** Aliquota e modo letti da un modulo con {@see Ui::vat_row()}: [aliquota|null, 'incl'|'escl']. */
	public static function vat_input( array $p ): array {
		return (array) apply_filters( 'asem_vat_input', array( null, \AssociazioneSemplice\Fiscal::INCLUDED ), $p );
	}

	public static function hidden( string $name, $value ): string {
		return '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '">';
	}

	/** <option> per un array valore => etichetta. */
	public static function options( array $map, $selected = null, ?string $empty = null ): string {
		$html = '';
		if ( null !== $empty ) {
			$html .= '<option value="">' . esc_html( $empty ) . '</option>';
		}
		static $memo = array(); // la stessa voce non scelta (stesso valore e stessa etichetta) esce sempre uguale: nelle pagine con molti elenchi di persone si prepara una volta sola
		if ( count( $memo ) > 20000 ) {
			$memo = array();
		}
		$sel = (string) $selected;
		foreach ( $map as $v => $label ) {
			$sv = (string) $v;
			if ( $sel === $sv ) {
				$html .= '<option value="' . esc_attr( $sv ) . '"' . selected( $sel, $sv, false ) . '>' . esc_html( (string) $label ) . '</option>';
				continue;
			}
			$k = $sv . "\0" . (string) $label;
			if ( ! isset( $memo[ $k ] ) ) {
				$memo[ $k ] = '<option value="' . esc_attr( $sv ) . '">' . esc_html( (string) $label ) . '</option>';
			}
			$html .= $memo[ $k ];
		}
		return $html;
	}

	public static function money( int $cents ): string {
		$cls = $cents < 0 ? ' class="asem-money asem-neg"' : ' class="asem-money"';
		return '<span' . $cls . '>' . esc_html( Money::format( $cents ) ) . '</span>';
	}

	public static function date( ?string $ymd ): string {
		return $ymd ? esc_html( ( new \DateTimeImmutable( $ymd ) )->format( 'd/m/Y' ) ) : '—';
	}

	public static function month( string $ym ): string {
		return self::MONTHS[ (int) substr( $ym, 5, 2 ) ] . ' ' . substr( $ym, 0, 4 );
	}

	/** @param string[] $months "YYYY-MM" */
	public static function month_options( array $months, ?string $selected ): string {
		$map = array();
		foreach ( $months as $m ) {
			$map[ $m ] = self::month( $m );
		}
		return self::options( $map, $selected );
	}

	public static function person_label( array $p ): string {
		return ( ! empty( $p['card_number'] ) ? 'n.' . $p['card_number'] . ' · ' : '' ) . trim( $p['first_name'] . ' ' . $p['last_name'] );
	}

	public static function pay_status( array $summary ): string {
		$up = ! empty( $summary['upcoming'] ) ? ' <span class="description">· ' . esc_html( self::month( $summary['upcoming']['month'] ) ) . ' dovuto dalla lezione del ' . esc_html( self::date( $summary['upcoming']['date'] ) ) . '</span>' : '';
		if ( $summary['balance'] < 0 ) {
			return '<strong class="asem-neg">Da versare ' . esc_html( Money::format( -$summary['balance'] ) ) . '</strong>' . $up;
		}
		if ( $summary['balance'] > 0 ) {
			return '<strong class="asem-ok">In regola (credito ' . esc_html( Money::format( $summary['balance'] ) ) . ')</strong>' . $up;
		}
		return '<strong class="asem-ok">In regola</strong>' . $up;
	}

	public static function months_table( array $summary ): string {
		if ( ! $summary['months'] ) {
			return '<p class="description">Nessuna mensilità dovuta finora.</p>';
		}
		$labels = array( PaymentCalc::PAID => array( 'pagato', 'asem-ok' ), PaymentCalc::PARTIAL => array( 'parziale', 'asem-warn' ), PaymentCalc::UNPAID => array( 'da pagare', 'asem-neg' ), PaymentCalc::ADVANCE => array( 'pagato in anticipo', '' ) );
		$html   = '<table class="widefat striped asem-months"><thead><tr><th>Mese</th><th>Versato</th><th>Dovuto</th><th>Stato</th></tr></thead><tbody>';
		foreach ( $summary['months'] as $m ) {
			$l     = $labels[ $m['state'] ];
			$html .= '<tr><td>' . esc_html( self::month( $m['month'] ) ) . '</td><td>' . esc_html( Money::format( $m['paid'] ) ) . '</td><td>' . esc_html( Money::format( $m['due'] ) )
				. '</td><td class="' . esc_attr( $l[1] ) . '">' . esc_html( $l[0] ) . '</td></tr>';
		}
		return $html . '</tbody></table>';
	}

	/** Campo di scelta con filtro di testo, per elenchi lunghi di persone. */
	public static function person_select( string $name, array $people, $selected = null, ?string $empty = null, string $id = '' ): string {
		return implode( '', self::person_select_parts( $name, $people, $selected, $empty, $id ) );
	}

	/** Il campo di {@see person_select()} in tre pezzi: l'apertura (campo di filtro e select), le voci e la chiusura. */
	private static function person_select_parts( string $name, array $people, $selected, ?string $empty, string $id ): array {
		if ( ! \AssociazioneSemplice\Employees::can( \AssociazioneSemplice\EmployeeRules::PEOPLE ) ) { // senza «Anagrafica soci» non si porta in pagina l'elenco: ricerca minima (3 lettere, 10 risultati)
			$id    = $id ?: 'asem-sel-' . sanitize_key( $name );
			$cur   = $selected ? \AssociazioneSemplice\Plugin::people()->get( (int) $selected ) : null;
			$opts  = array( '' => (string) $empty );
			if ( $cur ) {
				$opts[ (int) $cur['id'] ] = self::person_label( $cur );
			}
			return array( '<span class="asem-filter-select">' . PersonSearch::input( $id ) . '<select name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '">', self::options( $opts, $cur ? (int) $cur['id'] : null, null ), '</select></span>' );
		}
		$map = array();
		foreach ( $people as $p ) {
			$map[ $p['id'] ] = self::person_label( $p );
		}
		$id = $id ?: 'asem-sel-' . sanitize_key( $name );
		return array(
			'<span class="asem-filter-select"><input type="search" class="asem-filter" data-target="#' . esc_attr( $id ) . '" placeholder="Filtra…" autocomplete="off"> '
			. '<select name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '">',
			self::options( $map, $selected, $empty ),
			'</select></span>',
		);
	}

	/**
	 * Stampa «$before + campo di scelta di persone + $after» come si faceva con wp_kses( $before . person_select(…) . $after, Html::allowed() ), ma passando dal filtro solo
	 * le parti scritte a mano: le voci sono già protette da esc_attr ed esc_html (Ui::options), e in un elenco di migliaia di persone il filtro ripetuto per ogni riga
	 * è ciò che costa di più. Il risultato è lo stesso carattere per carattere (lo verifica la prova di fumo).
	 */
	public static function echo_person_select( string $before, string $name, array $people, $selected, ?string $empty, string $id, string $after = '' ): void {
		$parts = self::person_select_parts( $name, $people, $selected, $empty, $id );
		if ( false !== strpos( $parts[1], ' selected=' ) ) { // con una voce scelta il filtro riscrive l'attributo «selected» (virgolette): resta il percorso intero, identico a prima
			echo wp_kses( $before . implode( '', $parts ) . $after, \AssociazioneSemplice\Html::allowed() );
			return;
		}
		echo wp_kses( $before . $parts[0], \AssociazioneSemplice\Html::allowed() );
		echo $parts[1]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- voci già protette da esc_attr ed esc_html in Ui::options
		echo wp_kses( $parts[2] . $after, \AssociazioneSemplice\Html::allowed() );
	}

	/** Stato del contributo di una prenotazione. */
	public static function booking_state( array $b ): string {
		switch ( $b['state'] ) {
			case 'free':
				return '<span class="asem-ok">gratuito</span>';
			case 'paid':
				return '<span class="asem-ok">pagato</span>';
			case 'partial':
				return '<span class="asem-warn">parziale · resta ' . esc_html( Money::format( (int) $b['remaining'] ) ) . '</span>';
			default:
				return '<span class="asem-neg">da pagare ' . esc_html( Money::format( (int) $b['remaining'] ) ) . '</span>';
		}
	}

	public static function redirect( string $url, string $ok = '', string $err = '' ): void {
		wp_safe_redirect( \AssociazioneSemplice\Flash::url( $url, 'asem', $ok, $err ) );
		exit;
	}
}
