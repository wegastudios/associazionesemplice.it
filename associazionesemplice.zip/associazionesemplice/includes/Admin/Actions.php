<?php
namespace AssociazioneSemplice\Admin;

use AssociazioneSemplice\Attachments;
use AssociazioneSemplice\Audit;
use AssociazioneSemplice\Fiscal;
use AssociazioneSemplice\MemberType;
use AssociazioneSemplice\Money;
use AssociazioneSemplice\PeopleCsv;
use AssociazioneSemplice\Plugin;
use AssociazioneSemplice\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Gestori dei moduli (admin-post.php). Ogni gestore riceve $_POST già "unslashed" e restituisce
 * [url di destinazione, messaggio]. Gli errori di regola (\InvalidArgumentException) tornano alla
 * pagina di partenza con il messaggio, senza perdere nulla.
 */
final class Actions {

	/** Azioni riservate agli amministratori: impostazioni, pagamenti online, tessera e QR, anni solari, privacy, testi, tesoriere e segreteria. */
	const ADMIN_ONLY = array(

		'asem_sports', 'asem_create_year', 'asem_close_year', 'asem_reopen_year', 'asem_snapshot_past_years', 'asem_save_settings', 'asem_save_card', 'asem_regen_qr',
		'asem_save_look', 'asem_save_donate', 'asem_save_campaign', 'asem_delete_campaign', 'asem_create_privacy_page', 'asem_save_ical', 'asem_regen_ical', 'asem_create_pages', 'asem_save_wpai', 'asem_wpai_process', 'asem_wpai_retry', 'asem_wpai_clear', 'asem_privacy_anonymize', 'asem_save_comms',
		
		'asem_delete_activity', 'asem_delete_activities', 'asem_delete_booking', 'asem_purge_enrollments', 'asem_set_treasurer', 'asem_set_secretary', 'asem_release_wp_user', 'asem_set_board_role', 'asem_backup_restore', 
	);

	/** @var array<string,callable> azioni di amministrazione aggiunte da un'estensione */
	private static $extra = array();

	/** @var array<string,bool> di quelle aggiunte, le riservate all'amministratore */
	private static $extra_admin = array();

	/**
	 * Un'estensione aggiunge un'azione di amministrazione (`admin-post`). Il gestore riceve i dati inviati e restituisce [indirizzo, messaggio]
	 * oppure lancia InvalidArgumentException con il messaggio d'errore. Nonce e permessi li controlla Associazione Semplice.
	 */
	public static function add_handler( string $action, callable $handler, bool $admin_only = true ): void {
		self::$extra[ $action ] = $handler;
		if ( $admin_only ) {
			self::$extra_admin[ $action ] = true;
		}
	}

	/** Capability richiesta da un'azione: amministrazione completa o solo operatività (segreteria). */
	public static function required_cap( string $action ): string {
		return in_array( $action, self::ADMIN_ONLY, true ) || isset( self::$extra_admin[ $action ] ) ? Plugin::CAP : Plugin::CAP_OPS;
	}

	public static function register(): void {
		$map = array(
			'asem_save_person'        => 'save_person',
			'asem_delete_person'      => 'delete_person',
			'asem_set_membership'     => 'set_membership',
			'asem_set_treasurer'      => 'set_treasurer',
			'asem_release_wp_user'    => 'release_wp_user',
			'asem_set_staff'          => 'set_staff',
			'asem_delete_activity'    => 'delete_activity',
			'asem_delete_activities'  => 'delete_activities',
			'asem_delete_booking'     => 'delete_booking',
			'asem_purge_enrollments'  => 'purge_enrollments',
			'asem_set_secretary'      => 'set_secretary',
			'asem_privacy_consent'    => 'privacy_consent',
			'asem_rules_record'       => 'rules_record',
			'asem_privacy_anonymize'  => 'privacy_anonymize',
			'asem_save_comms'         => 'save_comms',
			'asem_create_privacy_page' => 'create_privacy_page',
			'asem_reminders_run'      => 'reminders_run',
			'asem_set_board_role'     => 'set_board_role',
			'asem_regen_qr'           => 'regen_qr',
			'asem_save_card'          => 'save_card',
			'asem_save_activity'      => 'save_activity',
			'asem_duplicate_activity' => 'duplicate_activity',
			'asem_lesson_exception'   => 'lesson_exception',
			'asem_sports'             => 'sports',
			'asem_lesson_restore'     => 'lesson_restore',
			'asem_tec_import'         => 'tec_import',
			'asem_enroll'             => 'enroll',
			'asem_enroll_variant'     => 'enroll_variant',
			'asem_cancel_enrollment'  => 'cancel_enrollment',
			'asem_stop_renewal'       => 'stop_renewal',
			'asem_add_session'        => 'add_session',
			'asem_update_session'     => 'update_session',
			'asem_generate_sessions'  => 'generate_sessions',
			'asem_add_dates'          => 'add_dates',
			'asem_cancel_session'     => 'cancel_session',
			'asem_book'               => 'book',
			'asem_create_year'        => 'create_year',
			'asem_close_year'         => 'close_year',
			'asem_reopen_year'        => 'reopen_year',
			'asem_snapshot_past_years' => 'snapshot_past_years',
			'asem_event_staff_add'    => 'event_staff_add',
			'asem_event_staff_remove' => 'event_staff_remove',
			'asem_event_staff_cash'   => 'event_staff_cash',
			'asem_checkin'            => 'checkin',
			'asem_promote_guest'      => 'promote_guest',
			'asem_access_done'        => 'access_done',
			'asem_access_approve'     => 'access_approve',
			'asem_application_approve' => 'application_approve',
			'asem_application_reject' => 'application_reject',
			'asem_event_request_approve' => 'event_request_approve',
			'asem_event_request_reject' => 'event_request_reject',
			'asem_adult_invite'       => 'adult_invite',
			'asem_send_notice'        => 'send_notice',
			'asem_transfer_booking'   => 'transfer_booking',
			'asem_cancel_booking'     => 'cancel_booking',
			'asem_waitlist_remove'    => 'waitlist_remove',
			'asem_backup_restore'     => 'backup_restore',
			'asem_save_income'        => 'save_income',
			'asem_save_expense'       => 'save_expense',
			'asem_add_attachment'     => 'add_attachment',
			'asem_remove_attachment'  => 'remove_attachment',
			'asem_void_tx'            => 'void_tx',
			'asem_detach_email'       => 'detach_email',
			'asem_detach_phone'       => 'detach_phone',
			'asem_suspend_member'     => 'suspend_member',
			'asem_suspend_expired'    => 'suspend_expired',
			'asem_reactivate_member'  => 'reactivate_member',
			'asem_cash_count'         => 'cash_count',
			'asem_save_settings'      => 'save_settings',
			'asem_quick_cash'         => 'quick_cash',
			'asem_save_look'          => 'save_look',
			'asem_save_donate'        => 'save_donate',
			'asem_save_campaign'      => 'save_campaign',
			'asem_delete_campaign'    => 'delete_campaign',
			'asem_save_ical'          => 'save_ical',
			'asem_regen_ical'         => 'regen_ical',
			'asem_quick_enroll'       => 'quick_enroll',
			'asem_create_pages'       => 'create_pages',
			'asem_import_preview'     => 'import_preview',
			'asem_import_apply'       => 'import_apply',
			'asem_import_undo'        => 'import_undo',
			'asem_save_wpai'          => 'save_wpai',
			'asem_wpai_process'       => 'wpai_process',
			'asem_wpai_retry'         => 'wpai_retry',
			'asem_wpai_clear'         => 'wpai_clear',
		);
		$map = array_merge( $map, self::$extra );
		foreach ( \AssociazioneSemplice\Edition::actions() as $feature => $actions ) { // le azioni delle funzioni aggiunte esistono solo se la funzione c'è
			if ( ! \AssociazioneSemplice\Edition::has( $feature ) ) {
				$map = array_diff_key( $map, array_flip( $actions ) );
				foreach ( $actions as $blocked ) {
					\AssociazioneSemplice\Edition::block_action( $blocked );
				}
			}
		}
		add_action( 'admin_post_asem_attachment', array( Attachments::class, 'handle_download' ) );
		foreach ( $map as $action => $method ) {
			add_action(
				'admin_post_' . $action,
				function () use ( $action, $method ) {
					if ( ! current_user_can( self::required_cap( $action ) ) ) {
						wp_die( 'Non autorizzato.', 403 );
					}
					check_admin_referer( $action );
					$post = \AssociazioneSemplice\Plugin::post_data(); // phpcs:ignore WordPress.Security.NonceVerification
					$back = ! empty( $post['_back'] ) ? esc_url_raw( $post['_back'] ) : Ui::url( 'asem' );
					try {
						$res = is_string( $method ) ? self::$method( $post ) : call_user_func( $method, $post );
						Ui::redirect( $res[0], $res[1] );
					} catch ( \InvalidArgumentException $e ) {
						Ui::redirect( $back, '', $e->getMessage() );
					} catch ( \Throwable $e ) {
						Ui::redirect( $back, '', 'Errore imprevisto: ' . $e->getMessage() );
					}
				}
			);
		}
	}

	private static function opt( array $a, string $k ): ?string {
		return isset( $a[ $k ] ) && '' !== trim( (string) $a[ $k ] ) ? trim( (string) $a[ $k ] ) : null;
	}

	// ---------- Soci e ospiti ----------

	private static function save_person( array $p ): array {
		$data = array(
			'type'           => (string) ( $p['type'] ?? '' ),
			'card_number'    => $p['card_number'] ?? '',
			'first_name'     => $p['first_name'] ?? '',
			'last_name'      => $p['last_name'] ?? '',
			'email'          => $p['email'] ?? '',
			'phone'          => $p['phone'] ?? '',
			'tax_code'       => $p['tax_code'] ?? '',
			'address'        => $p['address'] ?? '',
			'zip'            => $p['zip'] ?? '',
			'city'           => $p['city'] ?? '',
			'province'       => $p['province'] ?? '',
			'host_person_id' => $p['host_person_id'] ?? '',
			'joined_on'      => $p['joined_on'] ?? '',
			'notes'          => $p['notes'] ?? '',
			'prior_visits'   => $p['prior_visits'] ?? 0,
		);
		foreach ( array( 'birth_date', 'birth_place', 'approved_on', 'image_consent', 'affiliation_role', 'subject_kind', 'runts_same_section' ) as $k ) {
			if ( array_key_exists( $k, $p ) ) {
				$data[ $k ] = $p[ $k ];
			}
		}
		$id = (int) ( $p['id'] ?? 0 );
		if ( $id ) {
			$before = Plugin::people()->get( $id );
			Plugin::people()->update( $id, $data );
			if ( array_key_exists( 'level_id', $p ) ) {
				Plugin::people()->set_level_and_family( $id, (int) $p['level_id'], (int) ( $p['family_head_id'] ?? 0 ) );
			}
			self::sync_guardians( $id, $p );
			$after = Plugin::people()->get( $id );
			if ( $before && $after && empty( $before['wp_user_id'] ) && ! empty( $after['wp_user_id'] ) && \AssociazioneSemplice\Guardians::has_guardian( $id ) && ! \AssociazioneSemplice\Age::is_minor( $after['birth_date'] ?? null, \AssociazioneSemplice\Db::today() ) ) {
				try { // un ragazzo maggiorenne ancora collegato a un tutore che riceve l'email: gli arriva l'invito a scegliere la password
					\AssociazioneSemplice\Guardians::invite_adult( $id );
					return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Scheda salvata. Essendo maggiorenne, gli è arrivato l\'invito a scegliere la password.' );
				} catch ( \InvalidArgumentException $e ) {
					unset( $e ); // l'invio non è riuscito: resta nell'elenco della Bacheca
				}
			}
			return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Scheda salvata.' );
		}
		$id = Plugin::people()->create( $data );
		if ( array_key_exists( 'level_id', $p ) ) {
			Plugin::people()->set_level_and_family( $id, (int) $p['level_id'], (int) ( $p['family_head_id'] ?? 0 ) );
		}
		self::sync_guardians( $id, $p );
		return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Persona creata.' );
	}

	private static function delete_person( array $p ): array {
		Plugin::people()->delete( (int) $p['id'] );
		return array( Ui::url( 'asem-people' ), 'Persona eliminata. L\'eventuale utente WordPress collegato non viene rimosso.' . \AssociazioneSemplice\Privacy::closed_books_note( (int) $p['id'] ) );
	}

	private static function set_membership( array $p ): array {
		Plugin::people()->set_membership( (int) $p['id'], (string) $p['social_year'], ! empty( $p['enabled'] ) );
		return array( Ui::url( 'asem-person', array( 'id' => (int) $p['id'] ) ), 'Iscrizione aggiornata.' );
	}

	private static function set_board_role( array $p ): array {
		$id   = (int) ( $p['id'] ?? 0 );
		$role = (string) ( $p['board_role'] ?? '' );
		Plugin::people()->set_board_role( $id, '' === $role ? null : $role );
		return array( Ui::url( 'asem-person', array( 'id' => $id ) ), '' === $role ? 'Carica tolta.' : 'Carica assegnata: ' . \AssociazioneSemplice\BoardRole::label( $role ) . '.' );
	}





	private static function privacy_consent( array $p ): array {
		$id   = (int) ( $p['id'] ?? 0 );
		$mode = (string) ( $p['mode'] ?? '' );
		if ( 'clear' === $mode ) {
			\AssociazioneSemplice\Privacy::clear_consent( $id );
			return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Consenso rimosso.' );
		}
		\AssociazioneSemplice\Privacy::set_consent( $id, $mode );
		return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Consenso registrato.' );
	}

	private static function rules_record( array $p ): array {
		$id   = (int) ( $p['id'] ?? 0 );
		$mode = (string) ( $p['mode'] ?? '' );
		if ( 'clear' === $mode ) {
			\AssociazioneSemplice\Regulation::clear( $id );
			return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Accettazione rimossa.' );
		}
		\AssociazioneSemplice\Regulation::accept( $id, $mode );
		return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Accettazione registrata.' );
	}

	private static function privacy_anonymize( array $p ): array {
		$id = (int) ( $p['id'] ?? 0 );
		\AssociazioneSemplice\Privacy::anonymize( $id );
		return array( Ui::url( 'asem-comms' ), 'Persona anonimizzata: i dati personali sono stati rimossi, i movimenti contabili restano registrati.' . \AssociazioneSemplice\Privacy::closed_books_note( $id ) . \AssociazioneSemplice\Privacy::closed_descriptions_note( $id ) );
	}

	private static function save_comms( array $p ): array {
		$txt = function ( string $k ) use ( $p ) {
			return trim( (string) ( $p[ $k ] ?? '' ) );
		};
		Settings::update(
			(array) apply_filters( 'asem_comms_settings', array(
				'reminders_enabled'         => ! empty( $p['reminders_enabled'] ) ? 1 : 0,
				'reminders_membership'      => ! empty( $p['reminders_membership'] ) ? 1 : 0,
				'reminders_membership_days' => (int) ( $p['reminders_membership_days'] ?? 30 ),
				'reminders_dues'            => ! empty( $p['reminders_dues'] ) ? 1 : 0,
				'reminders_events'          => ! empty( $p['reminders_events'] ) ? 1 : 0,
				'reminders_polls'           => ! empty( $p['reminders_polls'] ) ? 1 : 0,
				'reminders_loans'           => ! empty( $p['reminders_loans'] ) ? 1 : 0,
				'privacy_url'               => $txt( 'privacy_url' ),
				'privacy_email'             => $txt( 'privacy_email' ),
				'privacy_retention_years'   => (int) ( $p['privacy_retention_years'] ?? 5 ),
				'privacy_extra_cookies'     => (string) ( $p['privacy_extra_cookies'] ?? '' ),
				'rules_enabled'             => ! empty( $p['rules_enabled'] ) ? 1 : 0,
				'rules_title'               => $txt( 'rules_title' ),
				'rules_text'                => (string) ( $p['rules_text'] ?? '' ),
				'rules_url'                 => $txt( 'rules_url' ),
				'rules_version'             => $txt( 'rules_version' ),
				'rules_block_booking'       => ! empty( $p['rules_block_booking'] ) ? 1 : 0,
			), $p )
		);
		return array( Ui::url( 'asem-comms' ), 'Impostazioni salvate.' );
	}

	private static function reminders_run( array $p ): array {
		if ( ! \AssociazioneSemplice\Reminders::enabled() ) {
			throw new \InvalidArgumentException( 'I promemoria sono disattivati: attivali e salva le impostazioni prima di inviarli.' );
		}
		$r = \AssociazioneSemplice\Reminders::run();
		return array( Ui::url( 'asem-comms' ), 'Promemoria inviati: ' . $r['membership'] . ' per la tessera, ' . $r['dues'] . ' per le mensilità, ' . $r['events'] . ' per gli eventi di domani, ' . $r['polls'] . ' per le votazioni, ' . $r['loans'] . ' per i prestiti scaduti.' );
	}







	/** Dopo aver tolto un potere: se non ne restano, la scheda propone di passare all'accesso con link (decide l'amministratore). */
	private static function release_hint( array $person ): string {
		$uid = (int) ( Plugin::people()->get( (int) $person['id'] )['wp_user_id'] ?? 0 );
		if ( $uid > 0 && \AssociazioneSemplice\MemberSession::enabled() && ! \AssociazioneSemplice\Access::has_powers( $uid ) ) {
			return ' Non ha più poteri: nella sua scheda, in «Accesso all\'area riservata», puoi farlo passare all\'accesso con link.';
		}
		return '';
	}

	/** Un socio senza più poteri torna all'accesso con link: l'utente WordPress si elimina. Solo amministratori, caso per caso. */
	private static function release_wp_user( array $p ): array {
		$id = (int) ( $p['id'] ?? 0 );
		Plugin::people()->release_wp_user( $id );
		return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Fatto: da ora entra con un link o un codice via email e non ha più un utente WordPress.' );
	}

	private static function set_secretary( array $p ): array {
		$person = Plugin::people()->get( (int) ( $p['id'] ?? 0 ) );
		if ( $person && ! empty( $p['enabled'] ) && empty( $person['wp_user_id'] ) && MemberType::is_member( $person['type'] ) && \AssociazioneSemplice\PeopleService::has_access( $person ) ) {
			Plugin::people()->ensure_user( (int) $person['id'] ); // il potere si esercita da WordPress: l'utente nasce ora
			$person = Plugin::people()->get( (int) $person['id'] );
		}
		$user = $person && ! empty( $person['wp_user_id'] ) ? get_userdata( (int) $person['wp_user_id'] ) : null;
		if ( ! $person || ! $user || ! MemberType::is_member( $person['type'] ) ) {
			throw new \InvalidArgumentException( 'Solo un socio con accesso al sito può far parte della segreteria.' );
		}
		if ( $user->has_cap( Plugin::CAP ) ) {
			throw new \InvalidArgumentException( 'È già amministratore del sito.' );
		}
		$on = ! empty( $p['enabled'] );
		if ( $on ) {
			$user->add_role( Plugin::ROLE_SECRETARY );
		} else {
			$user->remove_role( Plugin::ROLE_SECRETARY );
		}
		Audit::log( $on ? 'secretary.granted' : 'secretary.revoked', 'person', (int) $person['id'] );
		return array( Ui::url( 'asem-person', array( 'id' => (int) $person['id'] ) ), $on ? 'Ora fa parte della segreteria.' : 'Non fa più parte della segreteria.' . self::release_hint( $person ) );
	}

	private static function set_treasurer( array $p ): array {
		$person = Plugin::people()->get( (int) ( $p['id'] ?? 0 ) );
		if ( $person && ! empty( $p['enabled'] ) && empty( $person['wp_user_id'] ) && MemberType::is_member( $person['type'] ) && \AssociazioneSemplice\PeopleService::has_access( $person ) ) {
			Plugin::people()->ensure_user( (int) $person['id'] ); // il potere si esercita da WordPress: l'utente nasce ora
			$person = Plugin::people()->get( (int) $person['id'] );
		}
		if ( ! $person || empty( $person['wp_user_id'] ) || ! MemberType::is_member( $person['type'] ) ) {
			throw new \InvalidArgumentException( 'Solo un socio o volontario con accesso al sito può essere tesoriere.' );
		}
		$on = ! empty( $p['enabled'] );
		\AssociazioneSemplice\Access::set_treasurer( (int) $person['wp_user_id'], $on );
		Audit::log( $on ? 'treasurer.granted' : 'treasurer.revoked', 'person', (int) $person['id'] );
		return array( Ui::url( 'asem-person', array( 'id' => (int) $person['id'] ) ), $on ? 'Ora è tesoriere: può incassare, registrare spese, iscrivere soci e vendere gli eventi dall\'area riservata.' : 'Non è più tesoriere.' . self::release_hint( $person ) );
	}

	/** Staff dell'ente: può verificare gli accessi a tutti gli eventi (l'incasso resta una scelta per singolo evento). */
	private static function set_staff( array $p ): array {
		$person = Plugin::people()->get( (int) ( $p['id'] ?? 0 ) );
		if ( $person && ! empty( $p['enabled'] ) && empty( $person['wp_user_id'] ) && MemberType::is_member( $person['type'] ) && \AssociazioneSemplice\PeopleService::has_access( $person ) ) {
			Plugin::people()->ensure_user( (int) $person['id'] ); // il potere si esercita da WordPress: l'utente nasce ora
			$person = Plugin::people()->get( (int) $person['id'] );
		}
		if ( ! $person || empty( $person['wp_user_id'] ) || ! MemberType::is_member( $person['type'] ) ) {
			throw new \InvalidArgumentException( 'Solo un socio o volontario con accesso al sito può far parte dello staff.' );
		}
		$on = ! empty( $p['enabled'] );
		\AssociazioneSemplice\Access::set_entity_staff( (int) $person['wp_user_id'], $on );
		Audit::log( $on ? 'staff.granted' : 'staff.revoked', 'person', (int) $person['id'] );
		return array( Ui::url( 'asem-person', array( 'id' => (int) $person['id'] ) ), $on ? 'Ora fa parte dello staff: verifica gli accessi a tutti gli eventi.' : 'Non fa più parte dello staff dell\'ente.' . self::release_hint( $person ) );
	}

	/** Eliminazione completa di un evento, con la sorte delle somme incassate. Conferma scritta obbligatoria. */
	private static function delete_activity( array $p ): array {
		$id = (int) ( $p['id'] ?? 0 );
		$a  = Plugin::activities()->get( $id );
		if ( ! $a ) {
			throw new \InvalidArgumentException( 'Evento non trovato.' );
		}
		$free = \AssociazioneSemplice\ActivityReset::activity_is_free( $id ); // nessun movimento in prima nota: basta una sola conferma (il pulsante della pagina)
		if ( ! $free ) {
			if ( empty( $p['confirm'] ) ) {
				throw new \InvalidArgumentException( 'Spunta la conferma: l\'eliminazione è definitiva.' );
			}
			if ( mb_strtolower( trim( (string) ( $p['typed'] ?? '' ) ), 'UTF-8' ) !== mb_strtolower( trim( (string) $a['name'] ), 'UTF-8' ) ) {
				throw new \InvalidArgumentException( 'Il nome scritto non corrisponde a quello dell\'evento: l\'evento non è stato eliminato.' );
			}
		} elseif ( empty( $p['mode'] ) ) {
			$p['mode'] = \AssociazioneSemplice\ActivityReset::REFUND;
		}
		$s    = \AssociazioneSemplice\ActivityReset::delete( $id, (string) ( $p['mode'] ?? '' ), array( 'notify' => ! empty( $p['notify'] ), 'void_costs' => ! empty( $p['void_costs'] ) ) );
		$ns   = (int) $s['sessions'];
		$nb   = (int) $s['bookings'];
		$nr   = (int) $s['refunds'];
		$msg  = 'Evento «' . $s['name'] . '» eliminato: ' . ( 1 === $ns ? '1 data' : $ns . ' date' ) . ' e ' . ( 1 === $nb ? '1 prenotazione attiva cancellata' : $nb . ' prenotazioni attive cancellate' ) . '.';
		$msg .= $nr ? ' ' . ( 1 === $nr ? 'Registrata 1 restituzione' : 'Registrate ' . $nr . ' restituzioni' ) . ' in prima nota (' . Money::format( (int) $s['income_cents'] ) . '): il denaro va restituito a chi ha pagato.' : '';
		$msg .= $s['voided'] ? ' Annullati ' . (int) $s['voided'] . ' incassi (' . Money::format( (int) $s['income_cents'] ) . '): non risultano più in prima nota.' : '';
		$msg .= $s['expenses_voided'] ? ' Annullate ' . (int) $s['expenses_voided'] . ' spese.' : '';
		$msg .= $s['kept_count'] ? ' ' . ( 1 === (int) $s['kept_count'] ? 'Un incasso' : (int) $s['kept_count'] . ' incassi' ) . ' (' . Money::format( (int) $s['kept_cents'] ) . ') di date o mesi già svolti ' . ( 1 === (int) $s['kept_count'] ? 'resta' : 'restano' ) . ' in prima nota, senza restituzione.' : '';
		$msg .= $s['notified'] ? ' Avvisate ' . (int) $s['notified'] . ' persone.' : '';
		return array( Ui::url( 'asem-activities' ), $msg );
	}

	/** Eliminazione di più attività insieme (dall'elenco): stessa logica del singolo (ActivityReset::delete), solo per quelle senza movimenti in prima nota. */
	private static function delete_activities( array $p ): array {
		if ( empty( $p['confirm'] ) ) {
			throw new \InvalidArgumentException( 'Spunta la conferma: l\'eliminazione è definitiva.' );
		}
		$ids  = array_map( 'intval', explode( ',', (string) ( $p['ids'] ?? '' ) ) );
		$plan = \AssociazioneSemplice\ActivityReset::bulk_plan( $ids );
		if ( ! $plan['ok'] ) {
			throw new \InvalidArgumentException( 'Nessuna delle attività scelte si può eliminare così.' );
		}
		$done = 0;
		foreach ( $plan['ok'] as $pv ) {
			\AssociazioneSemplice\ActivityReset::delete( (int) $pv['activity']['id'], \AssociazioneSemplice\ActivityReset::REFUND, array( 'notify' => ! empty( $p['notify'] ) ) );
			$done++;
		}
		$msg = $done . ( 1 === $done ? ' eliminato' : ' eliminati' ) . '.';
		if ( $plan['skipped'] ) {
			$names = array_map(
				function ( $x ) {
					return $x['name'];
				},
				$plan['skipped']
			);
			$msg  .= ' Non eliminati perché hanno movimenti in prima nota o un blocco (da fare una per una): ' . implode( ', ', $names ) . '.';
		}
		return array( Ui::url( 'asem-activities' ), $msg );
	}

	/** Toglie dall'elenco di un corso gli iscritti con l'iscrizione già finita e senza incassi (la prima nota non cambia). */
	private static function purge_enrollments( array $p ): array {
		$aid = (int) ( $p['activity_id'] ?? 0 );
		if ( ! Plugin::activities()->get( $aid ) ) {
			throw new \InvalidArgumentException( 'Attività non trovata.' );
		}
		if ( empty( $p['confirm'] ) ) {
			throw new \InvalidArgumentException( 'Spunta la conferma per togliere gli iscritti dall\'elenco.' );
		}
		$r   = \AssociazioneSemplice\ActivityReset::purge_ended_enrollments( $aid );
		$msg = $r['removed'] ? (int) $r['removed'] . ( 1 === $r['removed'] ? ' iscritto tolto' : ' iscritti tolti' ) . ' dall\'elenco: la prima nota non è cambiata.' : 'Nessun iscritto da togliere.';
		if ( $r['kept'] ) {
			$msg .= ' Restano perché hanno incassi registrati (cancellali uno per uno, scegliendo cosa fare delle somme): ' . implode( ', ', $r['kept'] ) . '.';
		}
		return array( Ui::url( 'asem-activity', array( 'id' => $aid ) ), $msg );
	}

	/** Cancellazione di una singola iscrizione, con la sorte delle somme incassate. Conferma scritta obbligatoria. */
	private static function delete_booking( array $p ): array {
		$aid = (int) ( $p['activity'] ?? 0 );
		$pid = (int) ( $p['person'] ?? 0 );
		$sid = (int) ( $p['session'] ?? 0 );
		$pre = \AssociazioneSemplice\ActivityReset::registration_preview( $aid, $pid, $sid );
		if ( ! $pre ) {
			throw new \InvalidArgumentException( 'Iscrizione non trovata.' );
		}
		$free = 0 === (int) $pre['income']['count']; // nessun incasso collegato: la prima nota non cambia, basta una sola conferma
		$who  = Plugin::people()->full_name( $pre['person'] );
		if ( ! $free ) {
			if ( empty( $p['confirm'] ) ) {
				throw new \InvalidArgumentException( 'Spunta la conferma: la cancellazione è definitiva.' );
			}
			if ( mb_strtolower( trim( (string) ( $p['typed'] ?? '' ) ), 'UTF-8' ) !== mb_strtolower( $who, 'UTF-8' ) ) {
				throw new \InvalidArgumentException( 'Il nome scritto non corrisponde: l\'iscrizione non è stata cancellata.' );
			}
		} elseif ( empty( $p['mode'] ) ) {
			$p['mode'] = \AssociazioneSemplice\ActivityReset::REFUND;
		}
		$s    = \AssociazioneSemplice\ActivityReset::delete_registration( $aid, $pid, $sid, (string) ( $p['mode'] ?? '' ), array( 'notify' => ! empty( $p['notify'] ) ) );
		$msg  = 'Iscrizione di ' . $s['name'] . ' cancellata.';
		$msg .= $s['refunds'] ? ' Registrata la restituzione di ' . Money::format( (int) $s['income_cents'] ) . ' in prima nota: il denaro va restituito a chi ha pagato.' : '';
		$msg .= $s['voided'] ? ' Annullati ' . (int) $s['voided'] . ' incassi (' . Money::format( (int) $s['income_cents'] ) . '): non risultano più in prima nota.' : '';
		$msg .= \AssociazioneSemplice\ActivityReset::kept_text( $s );
		return array( Ui::url( 'asem-activity', array( 'id' => $aid ) ), $msg );
	}

	// ---------- Attività ----------

	/** Contributo da un campo di testo: vuoto = non indicato (null), "0" = gratuito. */
	private static function fee_field( array $p, string $key ): ?int {
		$raw = isset( $p[ $key ] ) ? trim( (string) $p[ $key ] ) : '';
		return '' === $raw ? null : ( Money::parse( $raw ) ?? 0 );
	}

	private static function session_fields( array $p ): array {
		return array(
			'session_date' => (string) ( $p['session_date'] ?? '' ),
			'start_time'   => (string) ( $p['start_time'] ?? '' ),
			'end_time'     => (string) ( $p['end_time'] ?? '' ),
			'location'     => (string) ( $p['location'] ?? '' ),
			'capacity'     => (string) ( $p['capacity'] ?? '' ),
		);
	}

	/** Quota per il rimborso: euro (fisso) o percentuale, in centesimi / centesimi di punto percentuale. */
	private static function fund_value( array $p ): int {
		$raw = trim( (string) ( $p['fund_value'] ?? '' ) );
		if ( '' === $raw || '' === (string) ( $p['fund_mode'] ?? '' ) ) {
			return 0;
		}
		if ( 'percent' === $p['fund_mode'] ) {
			return (int) round( (float) str_replace( ',', '.', $raw ) * 100 );
		}
		return Money::parse( $raw ) ?? 0;
	}

	/** Giorni della settimana (1..7) di una riga ricorrente: "ogni <giorno della data>", tutti i giorni oppure dal lunedì al venerdì. */
	private static function repeat_days( array $w ): array {
		$repeat = (string) ( $w['repeat'] ?? 'weekly' );
		if ( 'daily' === $repeat ) {
			return array( 1, 2, 3, 4, 5, 6, 7 );
		}
		if ( 'weekdays' === $repeat ) {
			return array( 1, 2, 3, 4, 5 );
		}
		$ts = strtotime( (string) ( $w['date'] ?? '' ) . ' 12:00:00 UTC' );
		return $ts ? array( (int) gmdate( 'N', $ts ) ) : array();
	}

	/** Righe del modulo "quando": ogni riga ha data e orario e, se "ricorrente", si ripete ogni settimana fino a una data di fine. */
	private static function when_rows( array $p ): array {
		$rows = array();
		foreach ( (array) ( $p['when'] ?? array() ) as $w ) {
			$w = (array) $w;
			if ( isset( $w['type'] ) ) { // formato esplicito (type = single | weekly)
				if ( 'single' === $w['type'] && '' === trim( (string) ( $w['date'] ?? '' ) ) ) {
					continue;
				}
				$rows[] = array(
					'type' => (string) $w['type'], 'date' => (string) ( $w['date'] ?? '' ), 'from' => (string) ( $w['from'] ?? '' ), 'to' => (string) ( $w['to'] ?? '' ),
					'days' => (array) ( $w['days'] ?? array() ), 'start' => (string) ( $w['start'] ?? '' ), 'end' => (string) ( $w['end'] ?? '' ),
				);
				continue;
			}
			if ( '' === trim( (string) ( $w['date'] ?? '' ) ) ) {
				continue; // riga lasciata vuota
			}
			if ( ! empty( $w['recurring'] ) ) {
				$rows[] = array( 'type' => 'weekly', 'days' => self::repeat_days( $w ), 'from' => (string) ( $w['from'] ?? '' ), 'to' => (string) ( $w['to'] ?? '' ), 'start' => (string) $w['date'], 'end' => (string) ( $w['end'] ?? '' ) );
			} else {
				$rows[] = array( 'type' => 'single', 'date' => (string) $w['date'], 'from' => (string) ( $w['from'] ?? '' ), 'to' => (string) ( $w['to'] ?? '' ) );
			}
		}
		return $rows;
	}

	/** Lezioni di un corso dal modulo: le righe ricorrenti diventano lezioni settimanali, le altre date uniche. */
	private static function lesson_slots( array $p ): array {
		$out = array();
		foreach ( self::when_rows( $p ) as $r ) {
			if ( 'single' === $r['type'] ) {
				$out[] = array( 'type' => 'single', 'date' => $r['date'], 'start' => $r['from'], 'end' => $r['to'] );
				continue;
			}
			foreach ( \AssociazioneSemplice\Schedule::days( $r['days'] ) as $day ) {
				$out[] = array( 'type' => 'weekly', 'day' => $day, 'start' => $r['from'], 'end' => $r['to'], 'from' => $r['start'], 'until' => $r['end'] );
			}
		}
		return $out;
	}

	private static function add_dates( array $p ): array {
		$aid = (int) $p['activity_id'];
		$cap = isset( $p['capacity'] ) && '' !== trim( (string) $p['capacity'] ) ? (int) $p['capacity'] : null;
		$n   = Plugin::activities()->add_dates( $aid, self::when_rows( $p ), self::opt( $p, 'location' ), $cap );
		return array( Ui::url( 'asem-activity', array( 'id' => $aid ) ), 0 === $n ? 'Nessuna data nuova: erano già tutte presenti.' : $n . ( 1 === $n ? ' data aggiunta.' : ' date aggiunte.' ) );
	}

	private static function save_activity( array $p ): array {
		$kind   = ! empty( $p['id'] ) ? (string) ( Plugin::activities()->get( (int) $p['id'] )['kind'] ?? '' ) : (string) ( $p['kind'] ?? 'course' );
		$errors = (array) apply_filters( 'asem_activity_errors', array(), $kind, $p ); // le estensioni possono chiedere dati in più prima di salvare
		if ( $errors ) {
			throw new \InvalidArgumentException( implode( ' ', array_map( 'strval', $errors ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		list( $vat_rate, $vat_mode ) = Ui::vat_input( $p ); // gli importi si memorizzano sempre IVA compresa (quanto paga chi partecipa)
		$fee   = self::fee_field( $p, 'fee' );
		$guest = self::fee_field( $p, 'guest_fee' );
		$data  = array(
			'name'                 => $p['name'] ?? '',
			'social_year'          => $p['social_year'] ?? '',
			'kind'                 => $p['kind'] ?? 'course',
			'instructor_person_id' => $p['instructor_person_id'] ?? '',
			'fee_cents'            => null === $fee ? 0 : Fiscal::gross_from_input( $fee, $vat_rate, $vat_mode ),
			'guest_fee_cents'      => null === $guest ? null : Fiscal::gross_from_input( $guest, $vat_rate, $vat_mode ),
			'cancellable'          => ! empty( $p['cancellable'] ) ? 1 : 0,
			'cancel_policy'        => $p['cancel_policy'] ?? '',
			'booking_qr'           => ! empty( $p['booking_qr'] ) ? 1 : 0,
			'lesson_slots'         => isset( $p['when'] ) ? self::lesson_slots( $p ) : null,
			'lesson_weekday'       => (int) ( $p['lesson_weekday'] ?? 0 ),
			'billing'              => (string) ( $p['billing'] ?? 'monthly' ),
			'location'             => (string) ( $p['location'] ?? '' ),
			'starts_on'            => (string) ( $p['starts_on'] ?? '' ),
			'ends_on'              => (string) ( $p['ends_on'] ?? '' ),
			'fund_mode'            => (string) ( $p['fund_mode'] ?? '' ),
			'fund_value'           => self::fund_value( $p ),
			'notes'                => $p['notes'] ?? '',
		);
		if ( array_key_exists( 'sport', $p ) ) { // classificazione sportiva (CONI e disciplina dell'ente), presente solo nei moduli che la chiedono
			$data['sport']      = $p['sport'];
			$data['discipline'] = $p['discipline'] ?? '';
		}
		if ( isset( $p['pl_label'] ) ) { // solo il modulo di modifica ha i listini: senza campi non si toccano
			$lists = array();
			foreach ( (array) $p['pl_label'] as $i => $label ) {
				$price   = self::fee_field( array( 'x' => (string) ( $p['pl_price'][ $i ] ?? '' ) ), 'x' );
				$lists[] = array(
					'label'   => (string) $label,
					'cents'   => null === $price ? 0 : Fiscal::gross_from_input( $price, $vat_rate, $vat_mode ),
					'entries' => (int) ( $p['pl_entries'][ $i ] ?? 1 ),
					'key'     => (string) ( $p['pl_key'][ $i ] ?? '' ),
				);
			}
			$data['price_lists'] = \AssociazioneSemplice\PriceLists::clean( $lists );
		}
		if ( array_key_exists( 'vat_rate', $p ) ) { // senza il campo (ente senza IVA) l'aliquota già memorizzata non si tocca
			$data['vat_rate'] = $vat_rate;
		}
		if ( array_key_exists( 'hold_hours', $p ) ) { // solo gli eventi hanno il campo
			$data['hold_hours'] = max( 0, min( 720, (int) $p['hold_hours'] ) );
		}
		$id = (int) ( $p['id'] ?? 0 );
		if ( $id ) {
			Plugin::activities()->update( $id, $data );
			return array( Ui::url( 'asem-activity', array( 'id' => $id ) ), 'Attività salvata.' . self::link_resource( $id, $p ) );
		}
		$when = self::when_rows( $p );
		if ( 'event' === $data['kind'] ) {
			$data['session'] = self::session_fields( $p );
			if ( $when ) { // programma a regole: l'evento una tantum ha una sola data
				$dates = \AssociazioneSemplice\Schedule::expand( $when );
				if ( count( $dates ) > 1 ) {
					throw new \InvalidArgumentException( 'Un evento una tantum ha una sola data: per più date scegli "Evento ricorrente".' );
				}
				if ( $dates ) {
					$data['session'] = array( 'session_date' => $dates[0]['date'], 'start_time' => (string) $dates[0]['start'], 'end_time' => (string) $dates[0]['end'], 'location' => (string) ( $p['location'] ?? '' ), 'capacity' => (string) ( $p['capacity'] ?? '' ) );
				}
			}
		}
		$id = Plugin::activities()->create( $data );
		if ( 'recurring' === $data['kind'] && $when ) {
			$cap = isset( $p['capacity'] ) && '' !== trim( (string) $p['capacity'] ) ? (int) $p['capacity'] : null;
			$n   = Plugin::activities()->add_dates( $id, $when, self::opt( $p, 'location' ), $cap );
			return array( Ui::url( 'asem-activity', array( 'id' => $id ) ), 'Attività creata con ' . $n . ( 1 === $n ? ' data.' : ' date.' ) . self::link_resource( $id, $p ) );
		}
		return array( Ui::url( 'asem-activity', array( 'id' => $id ) ), 'Attività creata.' . self::link_resource( $id, $p ) );
	}

	/** Se il modulo dell'attività indica una risorsa la collega (o la scollega); restituisce l'avviso sulle prenotazioni già presenti, se ce ne sono. */
	private static function link_resource( int $activity_id, array $p ): string {
		return implode( '', array_map( 'strval', (array) apply_filters( 'asem_activity_saved', array(), $activity_id, $p ) ) ); // le estensioni collegano i loro dati e possono aggiungere un avviso
	}

	/** Riproporre un evento o un corso già fatto in una nuova data o in un nuovo anno sociale. */
	private static function duplicate_activity( array $p ): array {
		$new = \AssociazioneSemplice\ActivityCopy::duplicate(
			(int) ( $p['id'] ?? 0 ),
			array(
				'name'        => $p['name'] ?? '',
				'date'        => $p['date'] ?? '',
				'start_time'  => '' !== trim( (string) ( $p['start_time'] ?? '' ) ) ? trim( (string) $p['start_time'] ) : null,
				'end_time'    => '' !== trim( (string) ( $p['end_time'] ?? '' ) ) ? trim( (string) $p['end_time'] ) : null,
				'location'    => '' !== trim( (string) ( $p['location'] ?? '' ) ) ? trim( (string) $p['location'] ) : null,
				'capacity'    => '' !== trim( (string) ( $p['capacity'] ?? '' ) ) ? (int) $p['capacity'] : null,
				'social_year' => $p['social_year'] ?? '',
				'starts_on'   => $p['starts_on'] ?? '',
				'ends_on'     => $p['ends_on'] ?? '',
			)
		);
		return array( Ui::url( 'asem-activity', array( 'id' => $new ) ), 'Attività riproposta: controlla date e dati e correggi quello che serve.' );
	}

	/** Annulla o sposta una singola lezione di un corso, avvisando gli iscritti se richiesto. */
	private static function lesson_exception( array $p ): array {
		$id   = (int) ( $p['activity_id'] ?? 0 );
		$date = (string) ( $p['date'] ?? '' );
		$note = (string) ( $p['note'] ?? '' );
		$back = Ui::url( 'asem-activity', array( 'id' => $id ) );
		$a    = Plugin::activities()->get( $id );
		if ( 'move' === ( $p['mode'] ?? '' ) ) {
			\AssociazioneSemplice\LessonExceptions::move( $id, $date, (string) ( $p['new_date'] ?? '' ), (string) ( $p['new_start'] ?? '' ), (string) ( $p['new_end'] ?? '' ), $note );
			$msg  = 'Lezione spostata al ' . Ui::date( (string) $p['new_date'] ) . '.';
			$text = 'La lezione di ' . ( $a ? $a['name'] : 'corso' ) . ' del ' . Ui::date( $date ) . ' è spostata al ' . Ui::date( (string) $p['new_date'] ) . ( '' !== trim( (string) ( $p['new_start'] ?? '' ) ) ? ' alle ' . trim( (string) $p['new_start'] ) : '' ) . ( '' !== trim( $note ) ? ' (' . trim( $note ) . ')' : '' ) . '.';
		} elseif ( 'cancel_from' === ( $p['mode'] ?? '' ) ) {
			$n    = \AssociazioneSemplice\LessonExceptions::cancel_from( $id, $date, $note );
			$msg  = $n . ( 1 === $n ? ' lezione annullata' : ' lezioni annullate' ) . ' (questa e le successive; le passate restano).';
			$text = 'Le lezioni di ' . ( $a ? $a['name'] : 'corso' ) . ' dal ' . Ui::date( $date ) . ' in poi sono annullate' . ( '' !== trim( $note ) ? ' (' . trim( $note ) . ')' : '' ) . '.';
		} else {
			\AssociazioneSemplice\LessonExceptions::cancel( $id, $date, $note );
			$msg  = 'Lezione annullata.';
			$text = 'La lezione di ' . ( $a ? $a['name'] : 'corso' ) . ' del ' . Ui::date( $date ) . ' è annullata' . ( '' !== trim( $note ) ? ' (' . trim( $note ) . ')' : '' ) . '.';
		}
		if ( ! empty( $p['notify'] ) && \AssociazioneSemplice\Notices::can_send( $id ) ) { // avviso generato dal programma: parte sempre, anche senza i contatti della segreteria
			try {
				$r    = \AssociazioneSemplice\Notices::send( $id, null, 'Cambio lezione: ' . ( $a ? $a['name'] : '' ), $text );
				$msg .= ' Avviso inviato agli iscritti (' . (int) $r['recipients'] . ').';
			} catch ( \InvalidArgumentException $e ) {
				$msg .= ' L\'avviso agli iscritti non è partito: ' . $e->getMessage();
			}
		}
		return array( $back, $msg );
	}

	private static function lesson_restore( array $p ): array {
		$id = (int) ( $p['activity_id'] ?? 0 );
		\AssociazioneSemplice\LessonExceptions::restore( $id, (string) ( $p['date'] ?? '' ) );
		return array( Ui::url( 'asem-activity', array( 'id' => $id ) ), 'Lezione ripristinata.' );
	}

	/** Importa gli eventi di The Events Calendar. */
	private static function tec_import( array $p ): array {
		$cats     = isset( $p['course_cats'] ) && is_array( $p['course_cats'] ) ? array_map( 'intval', $p['course_cats'] ) : array();
		$r   = \AssociazioneSemplice\TribeImport::run( $cats, ! empty( $p['publish_future'] ) ); // $cats: le categorie scelte dall'utente come «Corso»; tutte le altre sono «Evento»
		$msg = $r['events'] . ( 1 === $r['events'] ? ' evento importato' : ' eventi importati' ) . ( $r['courses'] ? ', ' . $r['courses'] . ( 1 === $r['courses'] ? ' corso importato' : ' corsi importati' ) : '' )
			. ( $r['skipped'] ? ', ' . $r['skipped'] . ' già presenti' : '' ) . ( $r['failed'] ? ', ' . $r['failed'] . ' non importati' : '' ) . '.'
			. ( ! empty( $r['failed_list'] ) ? ' Non importati perché manca la data (da correggere in The Events Calendar): ' . implode( ', ', array_map( function ( $f ) {
				return '«' . $f['title'] . '»';
			}, $r['failed_list'] ) ) . '.' : '' )
			. ( $r['errors'] ? ' Altri non importati: ' . implode( ' ', $r['errors'] ) : '' )
			. ( $r['pages'] ? ' Pagine pubbliche compilate: ' . $r['pages'] . ( $r['published'] ? ', di cui ' . $r['published'] . ' pubblicate' : ', in bozza' ) . ' (le trovi in Eventi sul sito).' : '' );
		if ( ! empty( $r['event_list'] ) ) { // cosa è nato: prima gli eventi, poi i corsi
			$msg .= ' Eventi creati: ' . implode( ', ', array_slice( $r['event_list'], 0, 10 ) ) . ( count( $r['event_list'] ) > 10 ? ' e altri ' . ( count( $r['event_list'] ) - 10 ) : '' ) . '.';
		}
		if ( ! empty( $r['course_list'] ) ) {
			$msg .= ' Corsi creati: ' . implode( ', ', array_slice( $r['course_list'], 0, 10 ) ) . ( count( $r['course_list'] ) > 10 ? ' e altri ' . ( count( $r['course_list'] ) - 10 ) : '' ) . '.';
		}
		if ( ! empty( $r['categories'] ) ) {
			$msg .= ' Categorie assegnate alle pagine: ' . implode( ', ', $r['categories'] ) . ( $r['categories_new'] ? ' (nuove: ' . implode( ', ', $r['categories_new'] ) . ')' : '' ) . '.';
		}
		if ( ! empty( $r['batch_id'] ) ) {
			$msg .= ' Import n. ' . (int) $r['batch_id'] . ': si può annullare da «Import già fatti», in fondo a questa pagina.';
		}
		return array( Ui::url( 'asem-tec' ), $msg );
	}

	private static function add_session( array $p ): array {
		$aid = (int) $p['activity_id'];
		Plugin::activities()->add_session( $aid, self::session_fields( $p ) );
		return array( Ui::url( 'asem-activity', array( 'id' => $aid ) ), 'Data aggiunta.' );
	}

	private static function update_session( array $p ): array {
		Plugin::activities()->update_session( (int) $p['session_id'], self::session_fields( $p ) );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Data aggiornata.' );
	}

	private static function generate_sessions( array $p ): array {
		$aid = (int) $p['activity_id'];
		$cap = isset( $p['capacity'] ) && '' !== trim( (string) $p['capacity'] ) ? (int) $p['capacity'] : null;
		$n   = Plugin::activities()->generate_weekly( $aid, (string) ( $p['from'] ?? '' ), (string) ( $p['to'] ?? '' ), self::opt( $p, 'start_time' ), self::opt( $p, 'location' ), $cap );
		return array( Ui::url( 'asem-activity', array( 'id' => $aid ) ), $n . ( 1 === $n ? ' data creata.' : ' date create.' ) );
	}

	private static function cancel_session( array $p ): array {
		$n = Plugin::activities()->cancel_session( (int) $p['session_id'], 'future' === ( $p['scope'] ?? '' ) );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 1 === $n ? 'Data annullata.' : $n . ' date annullate (questa e le successive; le passate restano).' );
	}

	/** Gli sport del menu: aggiungi (anche più d'uno), togli, ripristina l'elenco del CONI. */
	private static function sports( array $p ): array {
		$back = Ui::url( 'asem-activities' ) . '#asem-sports';
		switch ( (string) ( $p['op'] ?? '' ) ) {
			case 'remove':
				\AssociazioneSemplice\SportCatalog::remove( (string) ( $p['sport'] ?? '' ) );
				return array( $back, 'Sport tolto dal menu: le attività che lo usano lo tengono.' );
			case 'reset':
				\AssociazioneSemplice\SportCatalog::reset();
				return array( $back, 'Elenco del CONI ripristinato.' );
			default:
				$n = \AssociazioneSemplice\SportCatalog::add( (string) ( $p['sport'] ?? '' ) );
				return array( $back, 0 === $n ? 'Nessuno sport nuovo: erano già nell\'elenco (o il testo era vuoto).' : ( 1 === $n ? 'Sport aggiunto.' : $n . ' sport aggiunti.' ) );
		}
	}

	private static function create_year( array $p ): array {
		\AssociazioneSemplice\FiscalYears::create( (int) ( $p['year'] ?? 0 ) );
		return array( Ui::url( 'asem-years' ), 'Anno fiscale creato.' );
	}

	private static function close_year( array $p ): array {
		\AssociazioneSemplice\FiscalYears::close( (int) ( $p['year'] ?? 0 ), ! empty( $p['confirm_gaps'] ) );
		return array( Ui::url( 'asem-years' ), 'Anno fiscale chiuso: non si modifica più. Si può riaprire solo finché è l\'ultimo anno fiscale chiuso, indicando il motivo.' );
	}

	private static function reopen_year( array $p ): array {
		\AssociazioneSemplice\FiscalYears::reopen( (int) ( $p['year'] ?? 0 ), (string) ( $p['reason'] ?? '' ) );
		return array( Ui::url( 'asem-years' ), 'Anno fiscale riaperto: il motivo resta registrato.' );
	}

	/** Fotografia retroattiva del libro soci degli esercizi già chiusi (con i dati di oggi): serve la conferma esplicita. */
	private static function snapshot_past_years( array $p ): array {
		if ( empty( $p['confirm_retro'] ) ) {
			throw new \InvalidArgumentException( 'Spunta la conferma: i dati di allora vengono ricostruiti da quelli di oggi.' );
		}
		$n = \AssociazioneSemplice\FiscalYears::snapshot_past_years();
		return array( Ui::url( 'asem-years' ), 0 === $n ? 'Nessun anno fiscale da emettere.' : ( 1 === $n ? 'Emessi i documenti definitivi di 1 anno fiscale già chiuso' : 'Emessi i documenti definitivi di ' . $n . ' anni fiscali già chiusi' ) . ': libro ricostruito dai dati di oggi, la data è scritta nello storico delle chiusure.' );
	}

	private static function book( array $p ): array {
		$pid = (int) ( $p['person_id'] ?? 0 );
		self::assert_not_suspended( $pid );
		Plugin::activities()->book(
			(int) $p['session_id'],
			$pid,
			array(
				'price_list'  => sanitize_key( (string) ( $p['price_list'] ?? '' ) ),
				'guest_of'    => sanitize_key( (string) ( $p['guest_of'] ?? '' ) ),
				'use_package' => ! empty( $p['use_package'] ),
			)
		);
		return self::after_signup( $pid, Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Prenotazione registrata.', (int) $p['activity_id'], (int) $p['session_id'] );
	}


	private static function send_notice( array $p ): array {
		$aid = (int) ( $p['activity_id'] ?? 0 );
		\AssociazioneSemplice\Contacts::assert_can_write(); // invio manuale: servono i contatti della segreteria
		$r   = \AssociazioneSemplice\Notices::send( $aid, ! empty( $p['session_id'] ) ? (int) $p['session_id'] : null, (string) ( $p['subject'] ?? '' ), (string) ( $p['body'] ?? '' ) );
		return array( Ui::url( 'asem-activity', array( 'id' => $aid ) ), 'Avviso inviato a ' . $r['recipients'] . ' persone (' . $r['emailed'] . ' email inviate).' );
	}

	private static function access_done( array $p ): array {
		\AssociazioneSemplice\AccessRequests::remove( preg_replace( '/[^a-f0-9]/', '', (string) ( $p['id'] ?? '' ) ) );
		return array( Ui::url( 'asem' ), 'Richiesta chiusa.' );
	}

	private static function access_approve( array $p ): array {
		\AssociazioneSemplice\Frontend\FirstAccess::approve_change( preg_replace( '/[^a-f0-9]/', '', (string) ( $p['id'] ?? '' ) ) );
		return array( Ui::url( 'asem' ), 'Email aggiornata: al socio è arrivato il link per scegliere la password.' );
	}

	private static function application_approve( array $p ): array {
		$msg = \AssociazioneSemplice\Applications::approve( (int) ( $p['id'] ?? 0 ), (string) ( $p['card_number'] ?? '' ) );
		return array( Ui::url( 'asem' ), $msg );
	}

	private static function event_request_approve( array $p ): array {
		$msg = \AssociazioneSemplice\EventRequests::approve( (int) ( $p['id'] ?? 0 ) );
		return array( (string) ( $p['_back'] ?? Ui::url( 'asem' ) ), $msg );
	}

	private static function event_request_reject( array $p ): array {
		$msg = \AssociazioneSemplice\EventRequests::reject( (int) ( $p['id'] ?? 0 ) );
		return array( (string) ( $p['_back'] ?? Ui::url( 'asem' ) ), $msg );
	}

	private static function application_reject( array $p ): array {
		$msg = \AssociazioneSemplice\Applications::reject( (int) ( $p['id'] ?? 0 ) );
		return array( Ui::url( 'asem' ), $msg );
	}

	private static function adult_invite( array $p ): array {
		\AssociazioneSemplice\Guardians::invite_adult( (int) ( $p['id'] ?? 0 ) );
		return array( Ui::url( 'asem' ), 'Invito inviato: gli è arrivato il link per scegliere la password.' );
	}

	/** Allinea i tutori di una persona a quelli scelti nella scheda (fino a due, uno solo operativo): toglie quelli tolti, collega quelli nuovi. */
	private static function sync_guardians( int $id, array $p ): void {
		if ( empty( $p['guardians_present'] ) ) {
			return;
		}
		$ids = array_values( (array) ( $p['guardian_ids'] ?? array() ) );
		if ( '' !== trim( (string) ( $p['new_guardian_first_name'] ?? '' ) ) && '' !== trim( (string) ( $p['new_guardian_last_name'] ?? '' ) ) ) { // genitore non ancora in anagrafica: lo si censisce qui, anche senza essere socio
			$new_id = Plugin::people()->create( array(
				'type'       => \AssociazioneSemplice\MemberType::GUARDIAN,
				'first_name' => $p['new_guardian_first_name'],
				'last_name'  => $p['new_guardian_last_name'],
				'tax_code'   => $p['new_guardian_tax_code'] ?? '',
				'email'      => $p['new_guardian_email'] ?? '',
			) );
			$slot = array_search( '', array_map( 'strval', $ids ), true );
			if ( false === $slot ) {
				$ids[] = (string) $new_id;
			} else {
				$ids[ $slot ] = (string) $new_id;
			}
			$p['guardian_ids'] = $ids;
		}
		$want = array();
		foreach ( (array) ( $p['guardian_ids'] ?? array() ) as $g ) {
			if ( (int) $g > 0 ) {
				$want[ (int) $g ] = (int) $g;
			}
		}
		$want = array_slice( $want, 0, \AssociazioneSemplice\Guardians::MAX, true );
		$have = array_map( 'intval', array_column( \AssociazioneSemplice\Guardians::of( $id ), 'id' ) );
		foreach ( array_diff( $have, $want ) as $gone ) {
			\AssociazioneSemplice\Guardians::unlink( $id, (int) $gone );
		}
		foreach ( array_diff( $want, $have ) as $new ) {
			\AssociazioneSemplice\Guardians::link( $id, (int) $new );
		}
		$list = array_values( (array) ( $p['guardian_ids'] ?? array() ) );
		$op   = (int) ( $list[ (int) ( $p['guardian_operative'] ?? 0 ) ] ?? 0 ); // chi opera sul sito: il tutore scelto nella riga indicata
		if ( $op > 0 && in_array( $op, $want, true ) ) {
			\AssociazioneSemplice\Guardians::set_operative( $id, $op );
		}
	}

	private static function promote_guest( array $p ): array {
		$id = (int) ( $p['id'] ?? 0 );
		Plugin::people()->promote_guest( $id, array( 'email' => $p['email'] ?? '', 'type' => $p['type'] ?? '', 'card_number' => $p['card_number'] ?? '', 'membership' => ! empty( $p['membership'] ) ) );
		return array( Ui::url( 'asem-person', array( 'id' => $id ) ), 'Ora è socio: la sua storia (eventi, corsi e pagamenti) è rimasta nella scheda.' );
	}

	private static function event_staff_add( array $p ): array {
		Plugin::activities()->add_staff( (int) $p['activity_id'], (int) ( $p['person_id'] ?? 0 ), ! empty( $p['can_cash'] ) );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Gestore dell\'evento aggiunto: ora vede i prenotati e registra gli ingressi dall\'area riservata.' );
	}

	private static function event_staff_cash( array $p ): array {
		Plugin::activities()->set_staff_cash( (int) $p['activity_id'], (int) ( $p['person_id'] ?? 0 ), ! empty( $p['can_cash'] ) );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Incasso sul posto aggiornato.' );
	}

	private static function event_staff_remove( array $p ): array {
		Plugin::activities()->remove_staff( (int) $p['activity_id'], (int) ( $p['person_id'] ?? 0 ) );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Gestore tolto.' );
	}

	/** Ingresso registrato o annullato da amministrazione (anche in un giorno diverso da quello dell'evento). */
	private static function checkin( array $p ): array {
		$r = Plugin::activities()->check_in( (int) $p['session_id'], (int) $p['person_id'], ! empty( $p['undo'] ), true );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'recorded' === $r['status'] ? 'Ingresso registrato.' : ( 'undone' === $r['status'] ? 'Registrazione annullata.' : 'Ingresso già registrato.' ) );
	}

	private static function backup_restore( array $p ): array {
		// Come per l'azzeramento: spunta, frase scritta e password di chi opera, controllate prima di guardare il file.
		if ( empty( $p['confirm'] ) ) {
			throw new \InvalidArgumentException( 'Spunta la casella di conferma per ripristinare.' );
		}
		$written = trim( (string) ( $p['confirm_text'] ?? '' ) );
		if ( ! in_array( $written, array( \AssociazioneSemplice\Backup::RESTORE_PHRASE, \AssociazioneSemplice\Backup::RESTORE_PHRASE_OTHER ), true ) ) {
			throw new \InvalidArgumentException( \AssociazioneSemplice\Texts::t( 'La frase scritta non corrisponde: non è stato cambiato nulla.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- testo fisso del plugin, mostrato solo dopo esc_html
		}
		$user = wp_get_current_user();
		if ( ! $user || ! $user->exists() || '' === (string) ( $p['password'] ?? '' ) || ! wp_check_password( (string) $p['password'], $user->user_pass, $user->ID ) ) {
			throw new \InvalidArgumentException( \AssociazioneSemplice\Texts::t( 'La password non è corretta: non è stato cambiato nulla.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- testo fisso del plugin, mostrato solo dopo esc_html
		}
		$f = self::uploaded_file( 'backup_file' );
		if ( ! $f || UPLOAD_ERR_OK !== $f['error'] ) {
			throw new \InvalidArgumentException( 'Scegli il file della copia da ripristinare.' );
		}
		$r = \AssociazioneSemplice\Backup::restore( $f['tmp_name'], (string) ( $p['phrase'] ?? '' ), \AssociazioneSemplice\Backup::RESTORE_PHRASE_OTHER === $written );
		$d    = (array) ( $r['documents'] ?? array() );
		$docs = '';
		if ( 'other' === ( $r['origin'] ?? '' ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'La copia era stata fatta su un altro sito: l\'hai ripristinata con la tua conferma e questo resta scritto nel registro delle azioni.' );
		}
		if ( ! empty( $r['skipped'] ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'Attenzione: {n} file della copia non sono citati dai dati e non sono stati rimessi sul sito.', array( 'n' => (int) $r['skipped'] ) );
		}
		if ( ! empty( $r['closed'] ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'Attenzione: {n} documenti riservati sono sul sito ma restano chiusi: si aprono quando riapri la chiave con la frase della copia («Riapri la chiave con la frase», qui in Copia di sicurezza).', array( 'n' => (int) $r['closed'] ) );
		}
		if ( ! empty( $r['keys_failed'] ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'Attenzione: le chiavi dei documenti riservati non si sono potute rimettere sul sito (un\'altra operazione era in corso): rifai il ripristino della stessa copia.' );
		}
		if ( ! empty( $r['members_reset'] ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'Le password dei soci e le notifiche non fanno parte del ripristino: i soci rientrano con il link che ricevono.' );
		}
		if ( ! empty( $r['bad'] ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'Attenzione: {n} file della copia non coincidono con la loro impronta (o non si aprono con la chiave) e non sono stati rimessi sul sito.', array( 'n' => (int) $r['bad'] ) );
		}
		if ( ! empty( $d['restored'] ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'Rimessi sul sito {n} PDF definitivi.', array( 'n' => (int) $d['restored'] ) );
		}
		if ( ! empty( $d['missing'] ) || ! empty( $d['bad'] ) ) {
			$docs .= ' ' . \AssociazioneSemplice\Texts::t( 'Attenzione: {n} PDF definitivi non si sono potuti ritrovare o non coincidono con la loro impronta; controllali da «Verifica delle ricevute».', array( 'n' => (int) ( $d['missing'] ?? 0 ) + (int) ( $d['bad'] ?? 0 ) ) );
		}
		return array( Ui::url( 'asem-backup' ), 'Ripristino completato: ' . $r['rows'] . ' record in ' . $r['tables'] . ' tabelle' . ( $r['files'] ? ', ' . $r['files'] . ' allegati' : '' ) . '.' . $docs . ' Lo stato precedente non è stato conservato sul sito: se ti serve, scarica una copia prima di ripristinare.' );
	}




	private static function waitlist_remove( array $p ): array {
		\AssociazioneSemplice\Waitlist::leave( (int) ( $p['session_id'] ?? 0 ), (int) ( $p['person_id'] ?? 0 ) );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) ( $p['activity_id'] ?? 0 ) ) ), 'Tolto dalla lista d\'attesa.' );
	}

	private static function cancel_booking( array $p ): array {
		Plugin::activities()->cancel_booking( (int) $p['session_id'], (int) $p['person_id'] );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Prenotazione annullata (eventuali pagamenti vanno rimborsati a mano).' );
	}

	private static function enroll( array $p ): array {
		$pid = (int) ( $p['person_id'] ?? 0 );
		self::assert_not_suspended( $pid );
		Plugin::activities()->enroll( (int) $p['activity_id'], $pid, (string) $p['start_month'] );
		if ( isset( $p['price_list'] ) ) { // variante del contributo scelta dalla segreteria
			Plugin::activities()->set_enrollment_price( (int) $p['activity_id'], $pid, (string) $p['price_list'], (string) ( $p['fee_note'] ?? '' ) );
		}
		if ( ! empty( $p['next'] ) ) { // «Salva e prossimo inserimento»: si resta sulla pagina per iscrivere la persona dopo
			return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ) . '#asem-enroll-person', 'Iscrizione registrata: puoi inserire la prossima.' . self::membership_warning( $pid ) );
		}
		return self::after_signup( $pid, Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Iscrizione registrata.', (int) $p['activity_id'] );
	}

	private static function enroll_variant( array $p ): array {
		Plugin::activities()->set_enrollment_price( (int) $p['activity_id'], (int) $p['person_id'], (string) ( $p['price_list'] ?? '' ), (string) ( $p['fee_note'] ?? '' ) );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Contributo dell\'iscritto aggiornato.' );
	}

	private static function stop_renewal( array $p ): array {
		$last = Plugin::activities()->stop_renewal( (int) $p['activity_id'], (int) $p['person_id'] );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Non rinnova: resta iscritto fino a ' . Ui::month( $last ) . ' (periodo già pagato o in corso), poi non deve più nulla. Non si restituisce niente.' );
	}

	private static function cancel_enrollment( array $p ): array {
		Plugin::activities()->cancel( (int) $p['activity_id'], (int) $p['person_id'], (string) $p['last_month'] );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Cancellazione registrata: i mesi successivi non sono più dovuti.' );
	}

	// ---------- Movimenti ----------

	private static function save_income( array $p ): array {
		$lines = array();
		list( $vat_rate, $vat_mode ) = Ui::vat_input( $p );
		$vat_auto = Ui::vat_is_auto( $p );
		foreach ( (array) ( $p['lines'] ?? array() ) as $l ) {
			$lines[] = ( array_key_exists( 'vat_rate', $p ) && ! $vat_auto ? array( 'vat_rate' => $vat_rate ) : array() ) + array( 'vat_mode' => $vat_mode ) + array(
				'category_id'      => (int) ( $l['category_id'] ?? 0 ),
				'amount_cents'     => Money::parse( $l['amount'] ?? '' ) ?? 0,
				'activity_id'      => (int) ( $l['activity_id'] ?? 0 ),
				'session_id'       => (int) ( $l['session_id'] ?? 0 ),
				'competence_month' => self::opt( $l, 'competence_month' ),
				'social_year'      => self::opt( $l, 'social_year' ),
				'description'      => (string) ( $l['description'] ?? '' ),
				'discount_cents'   => Money::parse( $l['discount'] ?? '' ) ?? 0,
				'discount_note'    => (string) ( $l['discount_note'] ?? '' ),
			);
		}
		$n = Plugin::ledger()->record_receipt(
			array(
				'date'         => (string) ( $p['date'] ?? '' ),
				'account_id'   => (int) ( $p['account_id'] ?? 0 ),
				'method'       => (string) ( $p['method'] ?? '' ),
				'person_id'    => (int) ( $p['person_id'] ?? 0 ),
				'document_ref' => $p['document_ref'] ?? '',
				'lines'        => $lines,
			)
		);
		Plugin::ledger()->book_account_fee( (int) ( $p['account_id'] ?? 0 ), (string) ( $p['date'] ?? '' ), (int) array_sum( array_column( $lines, 'amount_cents' ) ), (string) ( $p['method'] ?? '' ), (string) ( $p['document_ref'] ?? '' ) ); // costo del POS o del conto, se impostato
		return array( Ui::url( 'asem-ledger' ), $n > 1 ? "Incasso registrato ($n voci)." : 'Incasso registrato.' );
	}

	private static function add_attachment( array $p ): array {
		$tx  = (int) ( $p['transaction_id'] ?? 0 );
		$ids = Attachments::add( $tx, Attachments::prepare( Attachments::from_request(), $tx ) );
		if ( ! $ids ) {
			throw new \InvalidArgumentException( 'Scegli almeno un file da allegare.' );
		}
		return array( $p['_back'] ?? Ui::url( 'asem-ledger' ), count( $ids ) . ( 1 === count( $ids ) ? ' allegato aggiunto.' : ' allegati aggiunti.' ) );
	}

	private static function remove_attachment( array $p ): array {
		Attachments::remove( (int) ( $p['id'] ?? 0 ) );
		return array( $p['_back'] ?? Ui::url( 'asem-ledger' ), 'Allegato tolto dall\'elenco (resta nel registro azioni).' );
	}


	private static function save_expense( array $p ): array {
		$docs = Attachments::prepare( Attachments::from_request() ); // controllati PRIMA di registrare: se un file non va, non si registra nulla
		$tx   = Plugin::ledger()->record_expense(
			array(
				'date'         => (string) ( $p['date'] ?? '' ),
				'account_id'   => (int) ( $p['account_id'] ?? 0 ),
				'method'       => (string) ( $p['method'] ?? '' ),
				'category_id'  => (int) ( $p['category_id'] ?? 0 ),
				'amount_cents' => Money::parse( $p['amount'] ?? '' ) ?? 0,
				'activity_id'  => (int) ( $p['activity_id'] ?? 0 ),
				'person_id'    => (int) apply_filters( 'asem_expense_person', (int) ( $p['person_id'] ?? 0 ), $p ), // un'estensione può impostare chi ha anticipato la spesa
				'description'  => $p['description'] ?? '',
				'document_ref' => $p['document_ref'] ?? '',
				'fund_choice'  => (string) ( $p['fund_choice'] ?? '' ), // scelta del fondo (funzione aggiuntiva): vuoto = automatico
			) + ( array_key_exists( 'vat_rate', $p ) ? array( 'vat_rate' => Ui::vat_input( $p )[0], 'vat_mode' => Ui::vat_input( $p )[1] ) : array() )
		);
		$ids = Attachments::add( $tx, $docs );
		return array( Ui::url( 'asem-ledger' ), 'Spesa registrata' . ( $ids ? ' con ' . count( $ids ) . ( 1 === count( $ids ) ? ' allegato.' : ' allegati.' ) : '.' ) . (string) apply_filters( 'asem_expense_saved_note', '', $tx ) );
	}


	private static function void_tx( array $p ): array {
		Plugin::ledger()->void( (int) $p['id'], (string) ( $p['reason'] ?? '' ) );
		$res = array( $p['_back'] ?? Ui::url( 'asem-ledger' ), 'Movimento annullato (resta tracciato).' );
		return (array) apply_filters( 'asem_tx_void_result', $res, (int) $p['id'] ); // le estensioni aggiungono una nota o propongono il passo successivo (dove andare, cosa dire)
	}

	// ---------- Conti ----------

	private static function suspend_expired( array $p ): array {
		$n = Plugin::people()->suspend_expired( \AssociazioneSemplice\Limits::get( 'suspend_after_months' ) );
		return array( Ui::url( 'asem-people' ), 0 === $n ? 'Nessun socio da sospendere.' : $n . ( 1 === $n ? ' socio sospeso' : ' soci sospesi' ) . ': sono inattivi finché non li riattivi a mano.' );
	}

	/** Un socio sospeso è inattivo: va riattivato a mano prima di prenotarlo, iscriverlo o incassargli la quota. */
	/**
	 * Dopo un'iscrizione o una prenotazione: se c'è qualcosa da incassare (tessera non valida, mensilità dovuta, contributo non versato)
	 * si apre direttamente l'incasso con quella persona e le voci già compilate; altrimenti si resta dove si era.
	 */
	private static function after_signup( int $pid, string $back, string $msg, int $activity_id = 0, int $session_id = 0 ): array {
		$due = '' !== self::membership_warning( $pid );
		if ( ! $due && $pid ) {
			if ( $session_id ) { // evento: il contributo di questa prenotazione non è ancora stato versato
				foreach ( Plugin::activities()->unpaid_bookings_for_person( $pid ) as $b ) {
					if ( (int) $b['session_id'] === $session_id ) {
						$due = true;
					}
				}
			} elseif ( $activity_id ) { // corso: c'è una mensilità dovuta di questo corso
				foreach ( Plugin::activities()->status_for_person( $pid ) as $st ) {
					if ( (int) $st['enrollment']['activity_id'] === $activity_id && $st['summary']['unpaid_months'] ) {
						$due = true;
					}
				}
			}
		}
		if ( $due ) {
			return array( Ui::url( 'asem-income', array( 'person_id' => $pid, 'due' => 1 ) ), $msg . ' Ecco l\'incasso già compilato con quanto è dovuto.' );
		}
		return array( $back, $msg );
	}

	/** Avviso quando si iscrive o prenota un socio con la tessera non valida: deve rinnovare (la quota compare tra i pagamenti da incassare). */
	private static function membership_warning( int $person_id ): string {
		$person = $person_id ? Plugin::people()->get( $person_id ) : null;
		if ( $person && MemberType::is_member( $person['type'] ) && ! MemberType::is_auto_renewed( $person['type'] ) && ! Plugin::people()->is_active_member( $person_id ) ) {
			return ' Attenzione: la tessera non è valida: rinnova la quota dalla scheda del socio (la trovi anche tra i pagamenti da incassare in Bacheca).';
		}
		return '';
	}

	private static function assert_not_suspended( int $person_id ): void {
		if ( $person_id && Plugin::people()->is_suspended( $person_id ) ) {
			throw new \InvalidArgumentException( 'Il socio è sospeso (inattivo): riattivalo a mano dalla sua scheda prima di continuare.' );
		}
	}

	private static function suspend_member( array $p ): array {
		Plugin::people()->suspend( (int) ( $p['id'] ?? 0 ) );
		return array( $p['_back'] ?? Ui::url( 'asem' ), 'Socio sospeso: è inattivo finché non rinnova la tessera (oppure lo riattivi).' );
	}

	private static function detach_email( array $p ): array {
		$id = (int) ( $p['id'] ?? 0 );
		Plugin::people()->detach_email( $id );
		return array( $p['_back'] ?? Ui::url( 'asem-person', array( 'id' => $id ) ), 'Email scollegata: il socio non ha più l\'accesso; lo storico resta. Per riattivarlo usa il link di attivazione o aggiungi una nuova email.' );
	}

	private static function detach_phone( array $p ): array {
		$id = (int) ( $p['id'] ?? 0 );
		Plugin::people()->detach_phone( $id );
		return array( $p['_back'] ?? Ui::url( 'asem-person', array( 'id' => $id ) ), 'Numero di telefono scollegato; lo storico resta.' );
	}

	private static function reactivate_member( array $p ): array {
		Plugin::people()->reactivate( (int) ( $p['id'] ?? 0 ) );
		return array( $p['_back'] ?? Ui::url( 'asem' ), 'Socio riattivato.' );
	}












	private static function cash_count( array $p ): array {
		$counted = Money::parse( $p['counted'] ?? '' );
		if ( null === $counted ) {
			throw new \InvalidArgumentException( 'Inserisci il saldo reale.' );
		}
		$diff = Plugin::ledger()->record_cash_count( (int) $p['account_id'], (string) $p['date'], $counted, ! empty( $p['adjust'] ), self::opt( $p, 'notes' ) );
		$msg  = 0 === $diff ? 'Verifica registrata: il saldo coincide.' : 'Verifica registrata: differenza ' . Money::format( $diff ) . ( ! empty( $p['adjust'] ) ? ' (rettificata).' : '.' );
		return array( Ui::url( 'asem-accounts' ), $msg );
	}

	// ---------- Impostazioni ----------

	/** Iscrizione rapida dalla Bacheca: corso (dal mese in corso) o data di un evento. */
	private static function quick_enroll( array $p ): array {
		$pid    = (int) ( $p['person_id'] ?? 0 );
		$person = Plugin::people()->get( $pid );
		if ( ! $person ) {
			throw new \InvalidArgumentException( 'Scegli chi si iscrive.' );
		}
		self::assert_not_suspended( $pid );
		$target = (string) ( $p['target'] ?? '' );
		$name   = trim( $person['first_name'] . ' ' . $person['last_name'] );
		if ( 0 === strpos( $target, 'a:' ) ) {
			$a = Plugin::activities()->get( (int) substr( $target, 2 ) );
			if ( ! $a ) {
				throw new \InvalidArgumentException( 'Corso non trovato.' );
			}
			Plugin::activities()->enroll( (int) $a['id'], $pid, Settings::social_year()->clamp( substr( current_time( 'Y-m-d' ), 0, 7 ) ) );
			return self::after_signup( $pid, Ui::url( 'asem' ), $name . ' è iscritto/a a ' . $a['name'] . '.', (int) $a['id'] );
		}
		if ( 0 === strpos( $target, 's:' ) ) {
			Plugin::activities()->book( (int) substr( $target, 2 ), $pid );
			return self::after_signup( $pid, Ui::url( 'asem' ), $name . ' è prenotato/a.', 0, (int) substr( $target, 2 ) );
		}
		throw new \InvalidArgumentException( 'Scegli a cosa iscriverlo.' );
	}

	/** Cassa rapida della Bacheca: un incasso o una spesa semplici. */
	private static function quick_cash( array $p ): array {
		$ledger = Plugin::ledger();
		$cents  = Money::parse( $p['amount'] ?? '' );
		if ( null === $cents || $cents <= 0 ) {
			throw new \InvalidArgumentException( 'Indica un importo maggiore di zero.' );
		}
		$cat = null;
		foreach ( $ledger->categories() as $c ) {
			if ( (int) $c['id'] === (int) ( $p['category_id'] ?? 0 ) ) {
				$cat = $c;
			}
		}
		if ( ! $cat || ! in_array( $cat['kind'], array( 'donation', 'other_income', 'general_cost' ), true ) ) {
			throw new \InvalidArgumentException( 'Scegli cosa registrare.' );
		}
		$date   = current_time( 'Y-m-d' );
		$common = array( 'date' => $date, 'account_id' => (int) ( $p['account_id'] ?? 0 ), 'method' => (string) ( $p['method'] ?? '' ) );
		$desc   = trim( (string) ( $p['description'] ?? '' ) );
		if ( 'general_cost' === $cat['kind'] ) {
			$ledger->record_expense( $common + array( 'category_id' => (int) $cat['id'], 'amount_cents' => $cents, 'description' => $desc ) );
			return array( Ui::url( 'asem' ), 'Spesa registrata: ' . Money::format( $cents ) . '.' );
		}
		$ledger->record_receipt( $common + array( 'lines' => array( array( 'category_id' => (int) $cat['id'], 'amount_cents' => $cents, 'description' => $desc ) ) ) );
		return array( Ui::url( 'asem' ), 'Incasso registrato: ' . Money::format( $cents ) . '.' );
	}

	private static function save_settings( array $p ): array {
		$txt = function ( string $k ) use ( $p ) {
			return sanitize_text_field( $p[ $k ] ?? '' );
		};
		$ente = array(); // denominazione, codice fiscale e anno sociale hanno la loro pagina («Dati e fiscalità»): qui si salvano solo se il modulo li contiene
		foreach ( array( 'association_name', 'tax_code' ) as $k ) {
			if ( array_key_exists( $k, $p ) ) {
				$ente[ $k ] = $txt( $k );
			}
		}
		if ( array_key_exists( 'social_year_start_month', $p ) ) {
			$ente['social_year_start_month'] = (int) $p['social_year_start_month'];
		}
		if ( ! empty( $p['guests_present'] ) ) { // la casella non spuntata non arriva nel modulo
			$ente['guests_enabled'] = ! empty( $p['guests_enabled'] ) ? 1 : 0;
		}
		if ( ! empty( $p['wpusers_present'] ) ) {
			$ente['member_wp_users'] = ! empty( $p['member_wp_users'] ) ? 1 : 0;
		}
		if ( ! empty( $p['apply_present'] ) ) {
			$ente['apply_enabled']    = ! empty( $p['apply_enabled'] ) ? 1 : 0;
			$ente['apply_volunteer']  = ! empty( $p['apply_volunteer'] ) ? 1 : 0;
			$ente['apply_pay_online'] = ! empty( $p['apply_pay_online'] ) ? 1 : 0;
			if ( array_key_exists( 'apply_email', $p ) ) { // il campo si vede solo se ha già un valore (eccezione facoltativa)
				$ente['apply_email'] = $txt( 'apply_email' );
			}
			$ente['whatsapp_button']  = ! empty( $p['whatsapp_button'] ) ? 1 : 0;
		}
		if ( ! empty( $p['uninstall_present'] ) ) {
			$ente['delete_on_uninstall'] = ! empty( $p['delete_on_uninstall'] ) ? 1 : 0;
		}
		Settings::update(
			$ente + array(
				'membership_fee_cents'    => Money::parse( $p['membership_fee'] ?? '' ) ?? 0,
				'family_discount_pct'     => (int) ( $p['family_discount_pct'] ?? 0 ),
				'founder_years'           => (int) ( $p['founder_years'] ?? 99 ),
				'guest_max_events'        => (int) ( $p['guest_max_events'] ?? 2 ),
				'board_councillors'       => (int) ( $p['board_councillors'] ?? 7 ),
				'member_area_page_id'     => (int) ( $p['member_area_page_id'] ?? 0 ),
				'cancel_policy_default'   => $txt( 'cancel_policy_default' ),
				'payment_hint'            => sanitize_textarea_field( $p['payment_hint'] ?? '' ),
				'gate_message'            => $txt( 'gate_message' ),
			)
		);
		if ( ! empty( $p['features_present'] ) ) { // il modulo ha l'elenco delle funzioni: le caselle non spuntate sono spente
			$feat = array();
			foreach ( array_keys( SettingsPage::all_features() ) as $k ) {
				$feat[ $k ] = ! empty( $p[ $k ] ) ? 1 : 0;
			}
			Settings::update( $feat );
		}
		return array( Ui::url( 'asem-settings' ), 'Impostazioni salvate.' );
	}





	private static function transfer_booking( array $p ): array {
		Plugin::activities()->transfer_booking( (int) $p['session_id'], (int) $p['person_id'], (int) ( $p['to_person_id'] ?? 0 ), false );
		return array( Ui::url( 'asem-activity', array( 'id' => (int) $p['activity_id'] ) ), 'Nominativo cambiato: il pagamento già fatto passa alla nuova persona.' );
	}

	/** Crea la pagina del sito con l'informativa privacy (si compila da sola con i dati dell'ente) e la collega alle impostazioni. */
	private static function create_privacy_page( array $p ): array {
		$made = \AssociazioneSemplice\Pages::create( array( 'privacy' ) );
		$id   = (int) ( \AssociazioneSemplice\Pages::existing()['privacy'] ?? 0 );
		if ( $id > 0 && '' === (string) Settings::get( 'privacy_url' ) ) {
			Settings::update( array( 'privacy_url' => (string) get_permalink( $id ) ) );
		}
		return array( Ui::url( 'asem-comms' ), $made ? 'Pagina «Informativa privacy» creata e collegata alle impostazioni.' : 'La pagina «Informativa privacy» esiste già.' );
	}

	/** Crea le pagine standard (area soci, area volontari, attività) se non esistono già. */
	private static function create_pages( array $p ): array {
		$made = \AssociazioneSemplice\Pages::create( array( 'area', 'volontari', 'attivita' ) );
		$have = \AssociazioneSemplice\Pages::existing();
		$menu = ! empty( $have['area'] ) && \AssociazioneSemplice\Pages::add_to_menu( (int) $have['area'] );
		return array( Ui::url( 'asem-settings' ), ( $made ? 'Pagine create: ' . implode( ', ', $made ) . '.' : 'Le pagine standard esistono già.' ) . ( $menu ? ' La voce «Area riservata» è nel menu del sito.' : '' ) );
	}

	// ---------- Import (Excel / CSV) ----------

	private static function import_preview( array $p ): array {
		$f = self::uploaded_file( 'file' );
		if ( ! $f || UPLOAD_ERR_OK !== $f['error'] ) {
			throw new \InvalidArgumentException( 'Scegli un file Excel o CSV da caricare.' );
		}
		if ( $f['size'] > \AssociazioneSemplice\Limits::get( 'import_max_mb' ) * 1048576 ) {
			throw new \InvalidArgumentException( 'Il file supera i ' . \AssociazioneSemplice\Limits::get( 'import_max_mb' ) . ' MB: dividilo in più file.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$prev  = \AssociazioneSemplice\ImportService::preview_file(
			$f['tmp_name'],
			$f['name'],
			array( 'default_type' => (string) ( $p['default_type'] ?? '' ), 'default_account_id' => (int) ( $p['default_account_id'] ?? 0 ) )
		);
		$token = sanitize_key( wp_generate_password( 16, false ) ); // minuscole: stessa forma con cui viene poi riletto
		set_transient( 'asem_import_' . get_current_user_id() . '_' . $token, $prev, HOUR_IN_SECONDS );
		return array( Ui::url( 'asem-import', array( 'token' => $token ) ), 'File letto: controlla l\'anteprima prima di importare.' );
	}

	private static function save_ical( array $p ): array {
		Settings::update( array( 'ical_enabled' => ! empty( $p['ical_enabled'] ) ? 1 : 0 ) );
		return array( Ui::url( 'asem-calendar' ), ! empty( $p['ical_enabled'] ) ? 'Calendario pubblicato: copia l\'indirizzo qui sotto.' : 'Calendario non più pubblicato.' );
	}

	private static function regen_ical( array $p ): array {
		\AssociazioneSemplice\Calendar::regenerate_token();
		return array( Ui::url( 'asem-calendar' ), 'Nuovo indirizzo del calendario: aggiorna il collegamento in Google Calendar.' );
	}

	private static function save_look( array $p ): array {
		$logo = (int) ( $p['logo_id'] ?? 0 );
		if ( $logo > 0 && ! wp_attachment_is_image( $logo ) ) {
			throw new \InvalidArgumentException( 'Il logo deve essere un\'immagine della libreria media.' );
		}
		$color = function ( string $custom, string $field ) use ( $p ): string {
			if ( empty( $p[ $custom ] ) ) {
				return ''; // senza spunta si usa il colore del sito
			}
			$c = \AssociazioneSemplice\Color::normalize( (string) ( $p[ $field ] ?? '' ) );
			if ( '' === $c ) {
				throw new \InvalidArgumentException( 'Scegli un colore valido oppure togli la spunta «Personalizza».' );
			}
			return $c;
		};
		$upd = array(
			'logo_id'         => max( 0, $logo ),
			'accent_color'    => $color( 'primary_custom', 'accent_color' ),
			'secondary_color' => $color( 'secondary_custom', 'secondary_color' ),
		);
		if ( ! empty( $p['card_present'] ) ) { // sezione «Tessera»: standard oppure su un'immagine propria
			$bg = (int) ( $p['card_bg_id'] ?? 0 );
			if ( $bg > 0 && ! wp_attachment_is_image( $bg ) ) {
				throw new \InvalidArgumentException( 'L\'immagine della tessera deve essere un\'immagine della libreria media.' );
			}
			$mode = \AssociazioneSemplice\CardLayout::MODE_IMAGE === (string) ( $p['card_mode'] ?? '' ) ? \AssociazioneSemplice\CardLayout::MODE_IMAGE : \AssociazioneSemplice\CardLayout::MODE_STANDARD;
			$upd['card_w_cm']   = \AssociazioneSemplice\CardLayout::clean_cm( $p['card_w_cm'] ?? '', 8.56 );
			$upd['card_h_cm']   = \AssociazioneSemplice\CardLayout::clean_cm( $p['card_h_cm'] ?? '', 5.4 );
			$upd['card_mode']   = $mode;
			$upd['card_bg_id']  = max( 0, $bg );
			$upd['card_layout'] = \AssociazioneSemplice\CardLayout::clean( $p['layout'] ?? array() );
			$upd['card_text']   = sanitize_text_field( (string) ( $p['card_text'] ?? '' ) );
		}
		Settings::update( $upd );
		return array( Ui::url( 'asem-look' ), 'Aspetto salvato.' );
	}

	private static function save_donate( array $p ): array {
		$account = \AssociazioneSemplice\Donations::clean_account( (string) ( $p['donate_paypal'] ?? '' ) );
		$on      = ! empty( $p['donate_enabled'] );
		if ( $on && '' === $account ) {
			throw new \InvalidArgumentException( 'Per accendere le donazioni scrivi l\'email del conto PayPal oppure il suo ID commerciante.' );
		}
		Settings::update(
			array(
				'donate_enabled' => $on ? 1 : 0,
				'donate_paypal'  => $account,
				'donate_amounts' => (string) ( $p['donate_amounts'] ?? '' ),
				'donate_purpose' => (string) ( $p['donate_purpose'] ?? '' ),
			)
		);
		return array( Ui::url( 'asem-donate' ), $on ? 'Donazioni attive: inserisci [associazionesemplice_donazioni] dove vuoi il modulo.' : 'Impostazioni salvate: le donazioni sono spente.' );
	}

	private static function save_campaign( array $p ): array {
		$id   = \AssociazioneSemplice\Donations::save_campaign(
			(int) ( $p['id'] ?? 0 ),
			array(
				'name'    => $p['name'] ?? '',
				'purpose' => $p['purpose'] ?? '',
				'amounts' => $p['amounts'] ?? '',
				'note'    => $p['note'] ?? '',
				'active'  => ! empty( $p['active'] ),
			)
		);
		$warn = \AssociazioneSemplice\Donations::enabled() ? '' : ' ' . \AssociazioneSemplice\Donations::disclaimer();
		return array( Ui::url( 'asem-donate' ), 'Raccolta salvata. Shortcode: ' . \AssociazioneSemplice\Donations::shortcode( $id ) . '.' . $warn );
	}

	private static function delete_campaign( array $p ): array {
		\AssociazioneSemplice\Donations::delete_campaign( (int) ( $p['id'] ?? 0 ) );
		return array( Ui::url( 'asem-donate' ), 'Raccolta eliminata.' );
	}

	private static function save_card( array $p ): array {
		Settings::update( (array) apply_filters( 'asem_card_settings', array( 'card_qr_enabled' => ! empty( $p['card_qr_enabled'] ) ? 1 : 0, 'ticket_qr_enabled' => ! empty( $p['ticket_qr_enabled'] ) ? 1 : 0 ), $p ) );
		return array( Ui::url( 'asem-card' ), 'Impostazioni salvate.' );
	}

	/** Contenuto di un file caricato (null se non ne è stato scelto uno). */
	public static function uploaded_bytes( string $key ): ?string {
		$f = self::uploaded_file( $key );
		if ( ! $f || UPLOAD_ERR_NO_FILE === $f['error'] ) {
			return null;
		}
		if ( UPLOAD_ERR_OK !== $f['error'] || $f['size'] > 1048576 ) {
			throw new \InvalidArgumentException( 'Caricamento del file non riuscito (massimo 1 MB).' );
		}
		return (string) file_get_contents( $f['tmp_name'] );
	}

	/**
	 * Il file caricato nel campo $key con i valori già controllati: nome ripulito con sanitize_file_name(), file temporaneo
	 * accettato solo se arriva davvero da un caricamento (is_uploaded_file), dimensione ed errore come numeri. Null se il campo manca.
	 *
	 * @return array{name:string,tmp_name:string,size:int,error:int}|null
	 */
	private static function uploaded_file( string $key ): ?array {
		if ( empty( $_FILES[ $key ] ) || ! is_array( $_FILES[ $key ] ) || ! isset( $_FILES[ $key ]['name'] ) || is_array( $_FILES[ $key ]['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- il nonce lo controlla chi gestisce l'azione
			return null;
		}
		$tmp   = isset( $_FILES[ $key ]['tmp_name'] ) ? (string) $_FILES[ $key ]['tmp_name'] : ''; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- percorso del server, validato con is_uploaded_file() qui sotto
		$error = isset( $_FILES[ $key ]['error'] ) ? absint( $_FILES[ $key ]['error'] ) : UPLOAD_ERR_NO_FILE; // phpcs:ignore WordPress.Security.NonceVerification
		if ( UPLOAD_ERR_OK === $error && ( '' === $tmp || ! is_uploaded_file( $tmp ) ) ) {
			$error = UPLOAD_ERR_NO_FILE;
		}
		return array(
			'name'     => sanitize_file_name( wp_unslash( (string) $_FILES[ $key ]['name'] ) ), // phpcs:ignore WordPress.Security.NonceVerification
			'tmp_name' => UPLOAD_ERR_OK === $error ? $tmp : '',
			'size'     => isset( $_FILES[ $key ]['size'] ) ? absint( $_FILES[ $key ]['size'] ) : 0, // phpcs:ignore WordPress.Security.NonceVerification
			'error'    => $error,
		);
	}




	private static function regen_qr( array $p ): array {
		Settings::regenerate_card_salt();
		return array( Ui::url( 'asem-card' ), 'QR rigenerati: i vecchi non funzionano più.' );
	}

	private static function import_undo( array $p ): array {
		$r = \AssociazioneSemplice\ImportService::undo( (int) ( $p['batch_id'] ?? 0 ) );
		if ( ! empty( $r['tribe'] ) ) { // import da The Events Calendar: si torna alla sua pagina
			$msg = 'Import annullato: ' . $r['activities_removed'] . ( 1 === (int) $r['activities_removed'] ? ' evento o corso tolto' : ' tra eventi e corsi tolti' );
			$msg .= $r['pages_removed'] ? ', ' . $r['pages_removed'] . ( 1 === (int) $r['pages_removed'] ? ' pagina pubblica tolta' : ' pagine pubbliche tolte' ) : '';
			$msg .= $r['pages_restored'] ? ', ' . $r['pages_restored'] . ' pagine tornate vuote' : '';
			$msg .= $r['terms_removed'] ? ', ' . $r['terms_removed'] . ' categorie pubbliche tolte' : '';
			$msg .= $r['posts_released'] ? '. Gli eventi di The Events Calendar tolti si possono importare di nuovo' : '';
			$msg .= $r['kept'] ? '. Mantenuti: ' . implode( '; ', array_slice( $r['kept'], 0, 6 ) ) : '';
			return array( Ui::url( 'asem-tec' ), $msg . '.' );
		}
		$msg  = 'Import annullato: ' . $r['voided'] . ' movimenti annullati';
		$msg .= $r['accounts_removed'] ? ', ' . $r['accounts_removed'] . ' conti tolti' : '';
		$msg .= $r['people_removed'] ? ', ' . $r['people_removed'] . ' soci/ospiti rimossi' : '';
		$msg .= $r['people_restored'] ? ', ' . $r['people_restored'] . ' schede ripristinate' : '';
		$msg .= $r['people_kept'] ? '. Restano perché già usati: ' . implode( '; ', array_slice( $r['people_kept'], 0, 6 ) ) : '';
		return array( Ui::url( 'asem-import' ), $msg . '.' );
	}

	private static function save_wpai( array $p ): array {
		Settings::update(
			array(
				'wpai_default_type'       => (string) ( $p['default_type'] ?? '' ),
				'wpai_default_account_id' => (int) ( $p['default_account_id'] ?? 0 ),
				'wpai_keep_balances'      => ! empty( $p['keep_balances'] ) ? 1 : 0,
				'wpai_mark_members'       => ! empty( $p['mark_members'] ) ? 1 : 0,
			)
		);
		return array( Ui::url( 'asem-wpai' ), 'Impostazioni salvate.' );
	}

	private static function wpai_process( array $p ): array {
		$r = \AssociazioneSemplice\WpAllImport::process();
		return array( Ui::url( 'asem-wpai' ), 'Elaborazione conclusa: ' . $r['people'] . ' soci/ospiti, ' . $r['ledger'] . ' movimenti, ' . $r['duplicates'] . ' già presenti, ' . $r['errors'] . ' con errori.' );
	}

	private static function wpai_retry( array $p ): array {
		return array( Ui::url( 'asem-wpai' ), \AssociazioneSemplice\WpAllImport::retry() . ' elementi rimessi in coda: premi "Elabora adesso".' );
	}

	private static function wpai_clear( array $p ): array {
		return array( Ui::url( 'asem-wpai' ), \AssociazioneSemplice\WpAllImport::clear_errors() . ' elementi con errori eliminati.' );
	}

	private static function import_apply( array $p ): array {
		$key  = 'asem_import_' . get_current_user_id() . '_' . sanitize_key( $p['token'] ?? '' );
		$prev = get_transient( $key );
		if ( ! is_array( $prev ) ) {
			throw new \InvalidArgumentException( 'L\'anteprima è scaduta: ricarica il file.' );
		}
		$res = \AssociazioneSemplice\ImportService::apply( $prev, array( 'mark_members' => ! empty( $p['mark_members'] ), 'keep_balances' => ! empty( $p['keep_balances'] ) ) );
		delete_transient( $key );
		$parts = array();
		if ( $res['people'] ) {
			$f       = $res['people']['failed'];
			$parts[] = 'Soci e ospiti: ' . $res['people']['created'] . ' creati, ' . $res['people']['updated'] . ' aggiornati' . ( $f ? ', ' . count( $f ) . ' non riusciti (' . implode( '; ', array_slice( $f, 0, 5 ) ) . ')' : '' );
		}
		if ( $res['ledger'] ) {
			$l       = $res['ledger'];
			$parts[] = 'Prima nota: ' . $l['created'] . ' movimenti' . ( $l['transfers'] ? ', ' . $l['transfers'] . ' giroconti' : '' ) . ( $l['duplicates'] ? ', ' . $l['duplicates'] . ' già presenti saltati' : '' )
				. ( $l['memberships'] ? ', ' . $l['memberships'] . ' iscrizioni registrate' : '' ) . ( $l['shifted'] ? ', saldi attuali invariati' : '' );
		}
		$msg = 'Import completato. ' . implode( '. ', $parts ) . '.' . ( $res['batch_id'] ? ' (Import n. ' . (int) $res['batch_id'] . ': si può annullare in blocco da "Importa".)' : '' );
		return array( $res['people'] && ! $res['ledger'] ? Ui::url( 'asem-people' ) : Ui::url( 'asem-ledger' ), $msg );
	}
}
