<?php
namespace AssociazioneSemplice\Admin;

use AssociazioneSemplice\Labels;
use AssociazioneSemplice\MemberType;
use AssociazioneSemplice\Money;
use AssociazioneSemplice\PeopleCsv;
use AssociazioneSemplice\Plugin;
use AssociazioneSemplice\Settings;
use AssociazioneSemplice\Html;

defined( 'ABSPATH' ) || exit;

/** Import di soci, ospiti e prima nota da Excel (.xlsx) o CSV, con anteprima prima di scrivere. */
final class ImportPage {

	const LEDGER_TEMPLATE = "Data;Tipo;Conto;Modalità;Voce;Importo;Descrizione;Riferimento;N. tessera;Attività;Competenza\r\n15/01/2024;Entrata;Cassa contanti;Contanti;Quota associativa;10,00;Quota 2023/2024;;1;;\r\n20/01/2024;Uscita;Conto corrente;Bonifico;Costo generale;45,50;Affitto sala;FT-12;;;\r\n";
	const GUESTS_TEMPLATE = "Tipo;Nome;Cognome;Cellulare;Ospite di\r\nospite;Gino;Rossi;333 1234567;1\r\n";

	public static function render(): void {
		Ui::header( 'Importa da Excel o CSV', '<a class="page-title-action" href="' . esc_url( Ui::url( 'asem-people' ) ) . '">← Soci</a>' );
		$token = Ui::get_str( 'token' );
		$prev  = '' !== $token ? get_transient( 'asem_import_' . get_current_user_id() . '_' . sanitize_key( $token ) ) : null;
		if ( is_array( $prev ) ) {
			self::preview( $token, $prev );
		} else {
			self::upload();
		}
		Ui::footer();
	}

	private static function data_link( string $csv, string $file, string $label ): string {
		return '<a href="' . esc_attr( 'data:text/csv;charset=utf-8,' . rawurlencode( "\xEF\xBB\xBF" . $csv ) ) . '" download="' . esc_attr( $file ) . '">' . esc_html( $label ) . '</a>';
	}

	private static function upload(): void {
		echo '<p>Carica un file <strong>Excel (.xlsx)</strong> o <strong>CSV</strong> con i <strong>soci</strong>, gli <strong>ospiti</strong> e/o la <strong>prima nota</strong>, anche di anni passati. '
			. 'Se nel file Excel ci sono più fogli (es. "Soci", "Ospiti", "Prima nota") vengono letti tutti: lo scopo di ciascuno si riconosce dalle intestazioni. Prima di registrare qualsiasi dato viene mostrata un\'anteprima.</p>';
		echo '<div class="asem-cols"><div class="asem-col"><div class="asem-card"><h2>Soci e ospiti</h2>'
			. '<p>Colonne riconosciute, in qualunque ordine: <strong>Numero tessera, Tipo, Nome, Cognome, Email, Telefono, Codice fiscale</strong> e, per gli ospiti, <strong>Cellulare</strong> (obbligatorio) e <strong>Ospite di</strong> (tessera, email o nome e cognome del socio). Facoltative: <strong>Data di nascita</strong> (31/12/2010) e <strong>Tutore</strong> (tessera, email o nome e cognome di un genitore già registrato o presente nel file: per indicarlo serve la data di nascita). '
			. 'Per registrare gli <strong>anni di iscrizione effettivi</strong> aggiungi una colonna per ogni anno (intestazione <strong>2023</strong>, <strong>2024</strong>… oppure <strong>ANNO CORRENTE</strong> e <strong>ANNO SCORSO</strong>) con una crocetta, un «sì» o un 1 dove il socio era iscritto; la colonna <strong>Anno iscrizione</strong> dice da quando è socio. '
			. 'Per gli ospiti: <strong>Venute</strong> (quante volte sono già venuti) e <strong>Note</strong> (gli eventi passati); per importare chi non ha il cellulare o il socio ospitante, spegni prima le due regole in Impostazioni → Limiti e soglie. '
			. 'Per i <strong>soci che sono enti</strong> (associazioni, società, enti pubblici) aggiungi la colonna <strong>Tipo soggetto</strong> (<em>persona</em> oppure <em>ente</em>), la <strong>Denominazione</strong> al posto di Nome e Cognome, il <strong>Codice fiscale</strong> dell\'ente (11 cifre, oppure 16 caratteri) e, se serve, <strong>Stessa sezione RUNTS</strong> (sì o no). Per un ente basta uno tra Codice fiscale, Email, Cellulare e Numero tessera. '
			. 'Per le persone Nome e Cognome sono obbligatori; per i soci serve poi <strong>almeno uno tra Email, Cellulare e Numero tessera</strong>. Con l\'email il socio ha subito il suo accesso all\'area riservata; senza, resta registrato e si attiva dopo con un <strong>link da mandare su WhatsApp</strong> (lo trovi nell\'elenco soci). Il Tipo può essere <em>fondatore</em>, <em>ordinario</em>, <em>volontario</em> oppure <em>ospite</em>.</p></div></div>'
			. '<div class="asem-col"><div class="asem-card"><h2>Prima nota</h2>'
			. '<p>Colonne: <strong>Data, Importo</strong> (oppure <strong>Entrata</strong> e <strong>Uscita</strong>), e se vuoi <strong>Tipo, Conto, Modalità, Voce, Descrizione, Riferimento, N. tessera, Persona, Attività, Competenza</strong>. '
			. 'Viene riconosciuto anche il file esportato da questo plugin. Le date possono essere 15/01/2024 o 2024-01-15; gli importi 1.234,56 o 1234.56. I conti che non esistono si creano; le voci non riconosciute finiscono in "Altra entrata" / "Costo generale".</p></div></div></div>';
		Ui::form_open( 'asem_import_preview', Ui::url( 'asem-import' ), true );
		echo '<p><input type="file" name="file" accept=".xlsx,.csv,.txt,text/csv,text/plain,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required></p>';
		$types = array();
		foreach ( MemberType::member_types() as $t ) {
			$types[ $t ] = MemberType::label( $t );
		}
		$accounts = array();
		foreach ( Plugin::ledger()->accounts() as $a ) {
			$accounts[ $a['id'] ] = $a['name'];
		}
		echo wp_kses( '<p>Tipo socio se manca la colonna: <select name="default_type">' . Ui::options( $types, MemberType::ORDINARY ) . '</select> ', Html::allowed() );
		echo wp_kses( ' · Conto della prima nota se manca la colonna: <select name="default_account_id">' . Ui::options( $accounts, null, '— nessuno —' ) . '</select></p>', Html::allowed() );
		submit_button( 'Carica e controlla' );
		Ui::form_close();
		echo wp_kses( '<p>Modelli CSV: ' . self::data_link( PeopleCsv::TEMPLATE, 'modello-soci.csv', 'soci' ) . ' · ' . self::data_link( self::GUESTS_TEMPLATE, 'modello-ospiti.csv', 'ospiti' ) . ' · ' . self::data_link( self::LEDGER_TEMPLATE, 'modello-prima-nota.csv', 'prima nota' ) . ' <span class="description">(si aprono anche con Excel)</span></p>', Html::allowed(), array_merge( wp_allowed_protocols(), array( 'data' ) ) ); // i modelli CSV sono link data:text/csv generati qui
		echo '<p class="description">Usi <strong>WP All Import</strong>? Si può importare anche da lì: vedi <a href="' . esc_url( Ui::url( 'asem-wpai' ) ) . '">Import con WP All Import</a>.</p>';
		self::history();
	}

	/**
	 * Import già fatti, con l'annullamento in blocco.
	 *
	 * @param string $kind 'tribe' = solo gli import da The Events Calendar (nella sua pagina); '' = tutti gli altri (soci e prima nota)
	 */
	public static function history( string $kind = '', string $back = 'asem-import' ): void {
		$batches = array_slice(
			array_values(
				array_filter(
					\AssociazioneSemplice\ImportService::batches( 100 ),
					function ( $b ) use ( $kind ) {
						return ( 'tribe' === (string) ( $b['data']['kind'] ?? '' ) ) === ( 'tribe' === $kind );
					}
				)
			),
			0,
			20
		);
		if ( ! $batches ) {
			return;
		}
		echo '<div class="asem-card"><h2>Import già fatti</h2><table class="widefat striped"><thead><tr><th>N.</th><th>Quando</th><th>Origine</th><th>Cosa è entrato</th><th></th></tr></thead><tbody>';
		foreach ( $batches as $b ) {
			$s     = $b['summary'];
			$parts = array_filter(
				array(
					! empty( $s['people_created'] ) ? $s['people_created'] . ' soci/ospiti nuovi' : '',
					! empty( $s['people_updated'] ) ? $s['people_updated'] . ' schede aggiornate' : '',
					! empty( $s['transactions'] ) ? $s['transactions'] . ' movimenti' : '',
					! empty( $s['transfers'] ) ? $s['transfers'] . ' giroconti' : '',
					! empty( $s['events'] ) ? $s['events'] . ( 1 === (int) $s['events'] ? ' evento' : ' eventi' ) : '',
					! empty( $s['courses'] ) ? $s['courses'] . ( 1 === (int) $s['courses'] ? ' corso' : ' corsi' ) : '',
					! empty( $s['pages'] ) ? $s['pages'] . ( 1 === (int) $s['pages'] ? ' pagina pubblica' : ' pagine pubbliche' ) : '',
				)
			);
			echo '<tr><td>' . (int) $b['id'] . '</td><td>' . esc_html( mysql2date( 'd/m/Y H:i', $b['created_at'] ) ) . '<br><span class="description">' . esc_html( (string) $b['display_name'] ) . '</span></td>'
				. '<td>' . esc_html( $b['source'] ) . '</td><td>' . esc_html( implode( ' · ', $parts ) ) . '</td><td>';
			if ( ! empty( $b['undone_at'] ) ) {
				echo '<span class="description">Annullato il ' . esc_html( mysql2date( 'd/m/Y H:i', $b['undone_at'] ) ) . '</span>';
			} else {
				Ui::form_open( 'asem_import_undo', Ui::url( $back ), false, 'asem-inline' );
				$ask = 'tribe' === $kind
					? 'Annullare TUTTO questo import? Si tolgono gli eventi e i corsi creati (con le loro pagine pubbliche) se nessuno si è prenotato o iscritto; quelli già usati restano. Non si può rifare con un clic.'
					: 'Annullare TUTTO questo import? Si annullano i movimenti, si tolgono i soci creati se non sono ancora stati usati e si rimettono i dati dei soci aggiornati. Non si può rifare con un clic.';
				echo wp_kses( Ui::hidden( 'batch_id', $b['id'] ) . '<button class="button button-small" data-confirm="' . esc_attr( $ask ) . '">Annulla questo import</button>', Html::allowed() );
				Ui::form_close();
			}
			echo '</td></tr>';
		}
		if ( 'tribe' === $kind ) {
			echo '</tbody></table><p class="description">L\'annullamento toglie gli eventi e i corsi nati con l\'import, con le date, le lezioni e la pagina pubblica, solo se non hanno prenotazioni, iscritti o movimenti (quelli usati restano e vengono elencati). Le pagine di attività già esistenti che l\'import ha compilato tornano vuote, se non le hai modificate; le categorie pubbliche create dall\'import si tolgono se restano vuote. Gli eventi di The Events Calendar tolti si possono importare di nuovo.</p></div>';
			return;
		}
		echo '</tbody></table><p class="description">L\'annullamento in blocco annulla i movimenti (restano nel registro come annullati), rimette i saldi iniziali dei conti, toglie i conti nuovi rimasti vuoti, ripristina i dati dei soci aggiornati e rimuove i soci e gli ospiti creati che non sono stati ancora usati (iscritti ad attività, prenotati, con movimenti o pagamenti): quelli già usati restano e vengono elencati.</p></div>';
	}

	private static function badge( string $action, bool $warn ): string {
		$map = array(
			'create' => array( 'Nuovo', 'asem-ok' ), 'update' => array( 'Aggiorna', 'asem-warn' ), 'error' => array( 'Errore', 'asem-neg' ),
			'transfer' => array( 'Giroconto', 'asem-ok' ), 'paired' => array( 'Giroconto', '' ), 'duplicate' => array( 'Già presente', 'asem-warn' ), 'skip' => array( 'Saltato', 'asem-warn' ),
		);
		$m = $map[ $action ] ?? array( $action, '' );
		return '<span class="' . esc_attr( $m[1] ) . '">' . esc_html( $m[0] ) . '</span>';
	}

	private static function preview( string $token, array $prev ): void {
		$people = $prev['people'] ?? null;
		$ledger = $prev['ledger'] ?? null;
		$ok     = 0;
		if ( $people ) {
			$c = array( 'create' => 0, 'update' => 0, 'error' => 0 );
			foreach ( $people['plan'] as $p ) {
				$c[ $p['action'] ]++;
			}
			$ok += $c['create'] + $c['update'];
			echo '<div class="asem-card"><h2>Soci e ospiti</h2><p><strong>' . (int) $c['create'] . '</strong> nuovi · <strong>' . (int) $c['update'] . '</strong> da aggiornare · <strong class="asem-neg">' . (int) $c['error'] . '</strong> con errori (saltati).</p>';
			self::people_table( $people['plan'] );
			echo '</div>';
		}
		if ( $ledger ) {
			$s   = $ledger['summary'];
			$ok += $s['counts']['create'] + $s['counts']['transfer'];
			echo '<div class="asem-card"><h2>Prima nota</h2>';
			echo '<p><strong>' . (int) $s['counts']['create'] . '</strong> movimenti da importare'
				. ( $s['counts']['transfer'] ? ' · <strong>' . (int) $s['counts']['transfer'] . '</strong> giroconti' : '' )
				. ( $s['counts']['duplicate'] ? ' · <strong class="asem-warn">' . (int) $s['counts']['duplicate'] . '</strong> già presenti (saltati)' : '' )
				. ( $s['counts']['skip'] ? ' · <strong class="asem-warn">' . (int) $s['counts']['skip'] . '</strong> saltati' : '' )
				. ' · <strong class="asem-neg">' . (int) $s['counts']['error'] . '</strong> con errori (saltati)'
				. ( $s['counts']['warn'] ? ' · ' . (int) $s['counts']['warn'] . ' con avvisi' : '' ) . '.</p>';
			if ( $s['from'] ) {
				echo wp_kses( '<p>Periodo: dal ' . esc_html( Ui::date( $s['from'] ) ) . ' al ' . esc_html( Ui::date( $s['to'] ) ) . ' · Entrate <strong>' . esc_html( Money::format( $s['income'] ) ) . '</strong> · Uscite <strong>' . esc_html( Money::format( $s['expense'] ) ) . '</strong></p>', Html::allowed() );
			}
			if ( $s['per_account'] ) {
				echo '<p>Effetto sui conti: ';
				$parts = array();
				foreach ( $s['per_account'] as $name => $delta ) {
					$parts[] = esc_html( $name ) . ' <strong>' . esc_html( ( $delta >= 0 ? '+' : '−' ) . ' ' . Money::format( abs( $delta ) ) ) . '</strong>' . ( in_array( $name, $s['new_accounts'], true ) ? ' (conto nuovo)' : '' );
				}
				echo wp_kses( implode( ' · ', $parts ) . '</p>', Html::allowed() );
			}
			self::ledger_table( $ledger['plan'] );
			echo '</div>';
		}
		if ( ! empty( $prev['ignored'] ) ) {
			echo '<p class="description">Fogli non riconosciuti (ignorati): ' . esc_html( implode( ', ', $prev['ignored'] ) ) . '</p>';
		}
		if ( $ok > 0 ) {
			Ui::form_open( 'asem_import_apply', Ui::url( 'asem-import', array( 'token' => $token ) ) );
			echo wp_kses( Ui::hidden( 'token', $token ), Html::allowed() );
			if ( $people ) {
				echo '<p><label><input type="checkbox" name="mark_members" value="1"> Segna la quota del ' . esc_html( Settings::membership_year()->label() ) . ' come pagata (non vale per i fondatori, sempre in regola)</label></p>';
			}
			if ( $ledger ) {
				echo '<p><label><input type="checkbox" name="keep_balances" value="1" checked> <strong>Non cambiare i saldi attuali dei conti</strong> (consigliato per le annualità passate): si aggiusta il saldo iniziale dei conti già esistenti, così il saldo di oggi resta com\'è e la storia si completa. Toglila se il file contiene TUTTA la storia e vuoi che i saldi derivino dai movimenti.</label></p>';
			}
			submit_button( 'Importa' );
			Ui::form_close();
		}
		echo '<p><a href="' . esc_url( Ui::url( 'asem-import' ) ) . '">← Scegli un altro file</a></p>';
	}

	private static function people_table( array $plan ): void {
		echo '<table class="widefat striped"><thead><tr><th>Riga</th><th>Tessera</th><th>Nome</th><th>Email</th><th>Tipo</th><th>Esito</th></tr></thead><tbody>';
		$shown = 0;
		foreach ( $plan as $p ) {
			if ( ++$shown > 300 && 'error' !== $p['action'] ) {
				continue;
			}
			$r = $p['row'];
			echo '<tr><td>' . esc_html( ( $r['sheet'] ? $r['sheet'] . ' · ' : '' ) . $r['line'] ) . '</td><td>' . esc_html( (string) $r['card'] ) . '</td><td>' . esc_html( $r['first'] . ' ' . $r['last'] ) . '</td><td>' . esc_html( (string) $r['email'] ) . '</td>';
			echo wp_kses( '<td>' . esc_html( $p['type'] ? MemberType::label( $p['type'] ) : '—' ) . '</td><td>' . self::badge( $p['action'], false ) . esc_html( $p['message'] ? ' — ' . $p['message'] : '' )
				. ( ! empty( $p['host_text'] ) ? esc_html( ' · ospite di ' . $p['host_text'] ) : '' ) . '</td></tr>', Html::allowed() );
		}
		echo '</tbody></table>';
		if ( count( $plan ) > 300 ) {
			echo '<p class="description">Sono mostrate le prime 300 righe e tutte quelle con errori.</p>';
		}
	}

	private static function ledger_table( array $plan ): void {
		echo '<table class="widefat striped"><thead><tr><th>Riga</th><th>Data</th><th>Conto</th><th>Voce</th><th>Importo</th><th>Esito</th></tr></thead><tbody>';
		$cats  = array();
		$shown = 0;
		foreach ( Plugin::ledger()->categories() as $c ) {
			$cats[ (int) $c['id'] ] = $c['name'];
		}
		foreach ( $plan as $p ) {
			$notable = 'create' !== $p['action'] || ! empty( $p['warnings'] );
			if ( ! $notable && ++$shown > 200 ) {
				continue;
			}
			$r = $p['row'];
			$d = $p['data'];
			$title = $d && isset( $d['category_id'] ) ? ( $cats[ $d['category_id'] ] ?? '' ) : ( $d ? 'Giroconto' : '' );
			$sign  = ( $r['type'] ?? '' ) === 'expense' || ( $r['type'] ?? '' ) === 'transfer_out' ? '−' : '+';
			echo wp_kses( '<tr><td>' . esc_html( ( $r['sheet'] ? $r['sheet'] . ' · ' : '' ) . $r['line'] ) . '</td><td>' . esc_html( $r['date'] ? Ui::date( $r['date'] ) : '' ) . '</td><td>' . esc_html( (string) $r['account'] ) . '</td>'
				. '<td>' . esc_html( $title ?: (string) $r['category'] ) . '<br><span class="description">' . esc_html( (string) $r['desc'] ) . '</span></td>'
				. '<td>' . esc_html( $r['cents'] ? $sign . ' ' . Money::format( (int) $r['cents'] ) : '' ) . '</td>'
				. '<td>' . self::badge( $p['action'], ! empty( $p['warnings'] ) ) . esc_html( $p['message'] ? ' — ' . $p['message'] : '' )
				. ( $p['warnings'] ? '<br><span class="description asem-warn">' . esc_html( implode( '; ', $p['warnings'] ) ) . '</span>' : '' ) . '</td></tr>', Html::allowed() );
		}
		echo '</tbody></table>';
		echo '<p class="description">Sono mostrate tutte le righe con errori o avvisi e le prime 200 delle altre. I movimenti importati si possono annullare uno per uno dalla Prima nota.</p>';
	}
}
