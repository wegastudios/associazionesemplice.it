<?php
namespace AssociazioneSemplice\Admin;

use AssociazioneSemplice\MemberType;
use AssociazioneSemplice\Money;
use AssociazioneSemplice\Plugin;
use AssociazioneSemplice\Settings;
use AssociazioneSemplice\Html;
use AssociazioneSemplice\Texts;

defined( 'ABSPATH' ) || exit;

final class PeoplePage {

	const PER_PAGE = 50; // persone per pagina nell'elenco

	public static function render_list(): void {
		$q      = Ui::get_str( 'q' );
		$type   = Ui::get_str( 'type' );
		$status = Ui::get_str( 'status' );
		$by     = Ui::get_str( 'orderby' );
		$dir    = 'desc' === Ui::get_str( 'order' ) ? 'desc' : 'asc';
		$rows   = Plugin::people()->search_light( array( 'q' => $q, 'type' => $type, 'status' => $status ) ); // filtri e ordine su poche colonne: le schede intere si leggono solo per le righe della pagina
		$at_limit = '1' === Ui::get_str( 'at_limit' );
		$gov      = null; // il quadro degli ospiti si calcola solo se serve (filtro «ospiti da invitare» o ospiti nella pagina)
		if ( $at_limit ) {
			$gov  = Plugin::people()->guest_overview();
			$rows = array_values( array_filter( $rows, function ( $x ) use ( $gov ) {
				return MemberType::GUEST === $x['type'] && ! empty( $gov[ (int) $x['id'] ]['flag'] );
			} ) );
		}
		$rows   = self::sort_rows( $rows, $by, $dir );
		$total  = count( $rows ); // il totale è quello vero, non quello della pagina
		$pages  = max( 1, (int) ceil( $total / self::PER_PAGE ) );
		$paged  = max( 1, min( $pages, Ui::get_int( 'paged', 1 ) ) );
		$shown  = Plugin::people()->search_ids( array_column( array_slice( $rows, ( $paged - 1 ) * self::PER_PAGE, self::PER_PAGE ), 'id' ) );
		foreach ( $shown as $s ) {
			if ( null === $gov && MemberType::GUEST === $s['type'] ) {
				$gov = Plugin::people()->guest_overview();
				break;
			}
		}
		$gov    = (array) $gov;
		$keep   = array_filter( array( 'q' => $q, 'type' => $type, 'status' => $status, 'at_limit' => $at_limit ? '1' : '' ), 'strlen' );
		$today  = current_time( 'Y-m-d' );

		$guest_link = \AssociazioneSemplice\Settings::guests_enabled() ? '<a class="button" href="' . esc_url( Ui::url( 'asem-person', array( 'type' => 'guest' ) ) ) . '">Nuovo ospite</a>' : '';
		Ui::header(
			'Soci e ospiti',
			'<a class="page-title-action" href="' . esc_url( Ui::url( 'asem-person', array( 'type' => 'ordinary' ) ) ) . '">Nuovo socio</a> '
				. '<button type="button" class="button asem-more" data-asem-sheet="asem-people-more">' . Ui::icon( 'ellipsis' ) . ' Altro</button>'
		);
		// le azioni meno frequenti stanno in un foglio: dal basso sul telefono, al centro sul computer
		echo wp_kses(
			'<dialog class="asem-sheet" id="asem-people-more" aria-labelledby="asem-people-more-t"><h2 id="asem-people-more-t">Altre azioni</h2><div class="asem-sheet-actions">'
			. $guest_link
			. '<a class="button" href="' . esc_url( Ui::url( 'asem-import' ) ) . '">Importa da Excel/CSV</a>'
			. Exports::link( 'people', array(), 'Scarica per Excel' )
			. '</div><p><button type="button" class="button" data-asem-close>Chiudi</button></p></dialog>',
			Html::allowed()
		);

		$board = Plugin::people()->board();
		if ( $board ) {
			$parts = array();
			foreach ( $board as $b ) {
				$parts[] = '<strong>' . esc_html( \AssociazioneSemplice\BoardRole::label( $b['board_role'] ) ) . '</strong> <a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => (int) $b['id'] ) ) ) . '">' . esc_html( $b['first_name'] . ' ' . $b['last_name'] ) . '</a>' . ( $b['in_regola'] ? '' : ' <span class="asem-neg">(tessera non in regola)</span>' );
			}
			echo wp_kses( '<p class="asem-board">Consiglio direttivo: ' . implode( ' · ', $parts ) . '</p>', Html::allowed() );
		}

		echo '<form method="get" class="asem-filters"><input type="hidden" name="page" value="asem-people">';
		if ( '' !== $by ) { // il filtro non fa perdere l'ordinamento scelto
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $by ) . '"><input type="hidden" name="order" value="' . esc_attr( $dir ) . '">';
		}
		echo '<input type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="Cerca per nome, tessera, email o codice fiscale"> ';
		echo wp_kses( '<select name="type">' . Ui::options( MemberType::labels(), $type, 'Tutti i tipi' ) . '</select> ', Html::allowed() );
		echo wp_kses( '<select name="status">' . Ui::options( array( 'active' => 'Tessera valida', 'expired' => 'Tessera scaduta o assente', 'noaccess' => 'Non è ancora entrato nell\'area soci', 'suspended' => 'Sospesi (inattivi)', 'noconsent' => 'Senza consenso privacy', 'norules' => 'Regolamento non accettato' ), $status, 'Qualsiasi stato' ) . '</select> ', Html::allowed() );
		echo '<label><input type="checkbox" name="at_limit" value="1"' . checked( $at_limit, true, false ) . '> Solo ospiti da invitare a diventare soci</label> ';
		echo '<button class="button">Filtra</button></form>';

		$months = \AssociazioneSemplice\Limits::get( 'suspend_after_months' );
		$stale  = Plugin::people()->expired_for_months( $months );
		if ( $stale ) {
			Ui::form_open( 'asem_suspend_expired', Ui::url( 'asem-people' ), false, 'asem-inline' );
			echo wp_kses( '<button class="button" data-confirm="Sospendere ' . count( $stale ) . ' soci con la tessera scaduta da oltre ' . (int) $months . ' mesi? Diventano inattivi (non compaiono più in Bacheca) finché non li riattivi a mano.">Sospendi i soci con tessera scaduta da oltre ' . (int) $months . ' mesi (' . count( $stale ) . ')</button>', Html::allowed() );
			Ui::form_close();
		}
		echo '<p class="description">' . (int) $total . ' persone.</p>';
		echo wp_kses( '<table class="widefat striped asem-cards asem-more"><thead><tr>' . self::sort_th( 'Tessera', 'card', $by, $dir, $keep ) . self::sort_th( 'Nome', 'name', $by, $dir, $keep ) . self::sort_th( 'Tipo', 'type', $by, $dir, $keep ) . '<th>Contatti</th><th>Stato</th><th></th></tr></thead><tbody>', Html::allowed() );
		if ( ! $shown ) {
			echo '<tr><td colspan="6">Nessuna persona trovata.</td></tr>';
		}
		foreach ( $shown as $p ) {
			if ( MemberType::GUEST === $p['type'] ) {
				$state = 'Ospite di ' . esc_html( (string) $p['host_name'] ) . '<br>' . self::guest_badge( $gov[ (int) $p['id'] ] ?? null );
			} elseif ( ! empty( $p['suspended_at'] ) ) {
				$state = Ui::state( 'warn', 'Sospeso (inattivo)' );
			} elseif ( ! empty( $p['active_until'] ) && $p['active_until'] >= $today ) {
				$state = Ui::state( 'ok', 'Valida fino al ' . Ui::date( $p['active_until'] ) );
			} elseif ( ! empty( $p['active_until'] ) ) {
				$state = Ui::state( 'danger', 'Scaduta il ' . Ui::date( $p['active_until'] ) );
			} else {
				$state = Ui::state( 'danger', 'Senza tessera' );
			}
			if ( MemberType::is_member( $p['type'] ) && ! \AssociazioneSemplice\PeopleService::has_access( $p ) ) {
				$state .= '<br>' . self::invite_link( $p );
			}
			echo '<tr><td data-label="Tessera">' . esc_html( (string) $p['card_number'] ?: '—' ) . '</td>';
			echo wp_kses( '<td class="asem-card-name">' . Ui::avatar( $p['first_name'] . ' ' . $p['last_name'] ) . ' ' . '<a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $p['id'] ) ) ) . '"><strong>' . esc_html( $p['last_name'] . ' ' . $p['first_name'] ) . '</strong></a></td>', Html::allowed() );
			echo '<td data-label="Tipo">' . esc_html( \AssociazioneSemplice\Levels::label( $p ) ) . '</td>'; // data-label: da telefono la riga diventa una scheda e ogni dato porta la sua etichetta
			echo '<td data-label="Contatti">' . wp_kses( ( '' !== (string) $p['email'] ? esc_html( (string) $p['email'] ) . '<br>' : '' ) . Ui::contact_links( $p ), Html::allowed() ) . '</td>';
			echo '<td data-label="Stato">' . wp_kses( $state, Html::allowed() ) . '</td>';
			echo '<td class="asem-card-open"><a class="button button-small" href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $p['id'] ) ) ) . '">Apri</a></td></tr>';
		}
		echo '</tbody></table>';
		if ( $pages > 1 ) { // una pagina di 50 persone alla volta: i filtri e l'ordine scelti restano
			$nav  = array_merge( $keep, '' !== $by ? array( 'orderby' => $by, 'order' => $dir ) : array() );
			echo '<p class="tablenav asem-pager">';
			if ( $paged > 1 ) {
				echo '<a class="button" href="' . esc_url( Ui::url( 'asem-people', array_merge( $nav, array( 'paged' => $paged - 1 ) ) ) ) . '">' . esc_html( Texts::t( '← Precedenti' ) ) . '</a> ';
			}
			echo esc_html( Texts::t( 'Pagina {n} di {tot}', array( 'n' => $paged, 'tot' => $pages ) ) ) . ' ';
			if ( $paged < $pages ) {
				echo '<a class="button" href="' . esc_url( Ui::url( 'asem-people', array_merge( $nav, array( 'paged' => $paged + 1 ) ) ) ) . '">' . esc_html( Texts::t( 'Successive →' ) ) . '</a>';
			}
			echo '</p>';
		}
		Ui::footer();
	}


	/** Titolo di una sezione del modulo (nuovo aspetto): chiude la tabella e ne apre un'altra, i campi restano nello stesso modulo. */
	private static function form_section( string $title ): void {
		echo '</tbody></table><h2 class="asem-form-section">' . esc_html( $title ) . '</h2><table class="form-table asem-form"><tbody>';
	}
	/** Ordina l'elenco per tessera (numerica, vuote in fondo), nome o tipo (come appare, a parità per nome). Senza criterio resta l'ordine per cognome e nome. */
	public static function sort_rows( array $rows, string $by, string $dir = 'asc' ): array {
		if ( ! in_array( $by, array( 'card', 'name', 'type' ), true ) ) {
			return $rows;
		}
		$sign = 'desc' === $dir ? -1 : 1;
		$name = function ( array $p ) {
			return \AssociazioneSemplice\Text::lower( $p['last_name'] . ' ' . $p['first_name'] );
		};
		usort(
			$rows,
			function ( $a, $b ) use ( $by, $sign, $name ) {
				if ( 'card' === $by ) {
					$ca = trim( (string) $a['card_number'] );
					$cb = trim( (string) $b['card_number'] );
					if ( '' === $ca || '' === $cb ) {
						if ( $ca === $cb ) {
							return strcmp( $name( $a ), $name( $b ) );
						}
						return '' === $ca ? 1 : -1; // le persone senza tessera stanno sempre in fondo
					}
					$c = ctype_digit( $ca ) && ctype_digit( $cb ) ? (int) $ca <=> (int) $cb : strnatcasecmp( $ca, $cb );
					return 0 !== $c ? $sign * $c : strcmp( $name( $a ), $name( $b ) );
				}
				if ( 'type' === $by ) {
					$c = strcmp( \AssociazioneSemplice\Text::lower( \AssociazioneSemplice\Levels::label( $a ) ), \AssociazioneSemplice\Text::lower( \AssociazioneSemplice\Levels::label( $b ) ) );
					return 0 !== $c ? $sign * $c : strcmp( $name( $a ), $name( $b ) );
				}
				return $sign * strcmp( $name( $a ), $name( $b ) );
			}
		);
		return $rows;
	}

	/** Intestazione di colonna cliccabile che ordina l'elenco (di nuovo clic: ordine inverso). */
	private static function sort_th( string $label, string $key, string $by, string $dir, array $keep ): string {
		$next = $by === $key && 'asc' === $dir ? 'desc' : 'asc';
		$url  = Ui::url( 'asem-people', array_merge( $keep, array( 'orderby' => $key, 'order' => $next ) ) );
		$mark = $by === $key ? ( 'asc' === $dir ? ' ▲' : ' ▼' ) : '';
		return '<th><a href="' . esc_url( $url ) . '">' . esc_html( $label . $mark ) . '</a></th>';
	}

	public static function render_edit(): void {
		$id     = Ui::get_int( 'id' );
		$people = Plugin::people();
		$p      = $id ? $people->get( $id ) : null;
		if ( $id && ! $p ) {
			wp_die( 'Persona non trovata.' );
		}
		$type = $p ? $p['type'] : ( MemberType::is_valid( Ui::get_str( 'type' ) ) ? Ui::get_str( 'type' ) : MemberType::ORDINARY );
		$val  = function ( string $k ) use ( $p ) {
			return $p ? (string) ( $p[ $k ] ?? '' ) : '';
		};
		$host_id = $p ? (int) $p['host_person_id'] : Ui::get_int( 'host' );
		$sx = $p && \AssociazioneSemplice\Employees::sensitive_hidden(); // senza «Vedere dati riservati ed esportare» codice fiscale e note non si mostrano
		if ( $p && ! $sx ) {
			\AssociazioneSemplice\Employees::log_sensitive_read( 'card', (int) $p['id'] ); // ogni lettura dei dati riservati è nel registro
		}
		$back    = Ui::url( 'asem-person', $id ? array( 'id' => $id ) : array( 'type' => $type ) );
		$hosts   = array_values( array_filter( $people->search_light(), function ( $x ) use ( $id ) {
			return MemberType::is_member( $x['type'] ) && (int) $x['id'] !== $id;
		} ) );

		Ui::header( $p ? $people->full_name( $p ) : ( MemberType::GUEST === $type ? 'Nuovo ospite' : 'Nuovo socio' ), '<a class="page-title-action" href="' . esc_url( Ui::url( 'asem-people' ) ) . '">← Elenco</a>' );

		echo '<div class="asem-cols"><div class="asem-col">';
		Ui::form_open( 'asem_save_person', $back );
		echo wp_kses( Ui::hidden( 'id', $id ), Html::allowed() );
		echo '<h2 class="asem-form-section">Chi è</h2>';
		echo '<table class="form-table asem-form"><tbody>';
		echo wp_kses( '<tr><th>Tipo</th><td><select name="type" id="asem-type">' . Ui::options( MemberType::labels(), $type ) . '</select>', Html::allowed() );
		echo '<p class="description" id="asem-type-hint"></p></td></tr>';
		$lv_opts = '<option value="">Livello predefinito del tipo</option>';
		foreach ( \AssociazioneSemplice\Levels::all() as $lv ) {
			$sel = $p && (int) $p['level_id'] === (int) $lv['id'];
			if ( ! (int) $lv['active'] && ! $sel ) {
				continue;
			}
			$lv_opts .= '<option value="' . (int) $lv['id'] . '" data-base="' . esc_attr( $lv['base_type'] ) . '"' . selected( $sel, true, false ) . '>' . esc_html( $lv['name'] . ( (int) $lv['active'] ? '' : ' (non attivo)' ) . ( null === $lv['fee_cents'] ? '' : ' — ' . \AssociazioneSemplice\Money::format( (int) $lv['fee_cents'] ) ) ) . '</option>';
		}
		echo wp_kses( '<tr class="asem-row-level"><th>Livello</th><td><select name="level_id" id="asem-level">' . $lv_opts . '</select>', Html::allowed() );
		echo '<p class="description">Decide il nome sulla tessera e la quota associativa (si definiscono in Impostazioni).</p></td></tr>';
		$fam_heads = array_values( array_filter( $hosts, function ( $x ) use ( $id ) {
			return empty( $x['family_head_id'] ) && (int) $x['id'] !== $id;
		} ) );
		echo wp_kses( '<tr class="asem-row-level"><th>Nucleo familiare</th><td>' . Ui::person_select( 'family_head_id', $fam_heads, $p ? (int) $p['family_head_id'] : 0, '— nessuno (paga la quota piena) —', 'asem-family' ), Html::allowed() );
		echo '<p class="description">Scegli il capofamiglia se questo socio fa parte del suo nucleo familiare: ' . ( \AssociazioneSemplice\Settings::family_discount() > 0 ? 'la quota è ridotta del ' . (int) \AssociazioneSemplice\Settings::family_discount() . '%.' : 'lo sconto familiare si imposta in Impostazioni (ora è 0%).' ) . '</p>';
		if ( $p ) {
			$fam = $people->family_of( $id );
			if ( $fam ) {
				echo '<p>Familiari: ' . esc_html( implode( ', ', array_map( function ( $f ) {
					return $f['first_name'] . ' ' . $f['last_name'];
				}, $fam ) ) ) . '</p>';
			}
		}
		echo '</td></tr>';
		echo wp_kses( '<tr class="asem-row-host"><th>Socio ospitante *</th><td>' . Ui::person_select( 'host_person_id', $hosts, $host_id, '— scegli il socio —', 'asem-host' ) . '</td></tr>', Html::allowed() );
		echo '<tr class="asem-row-card"><th>N. tessera</th><td><input type="text" name="card_number" id="asem-card" value="' . esc_attr( $val( 'card_number' ) ) . '" class="regular-text"> '
			. '<button type="button" class="button" id="asem-next-card" data-next="' . esc_attr( $people->next_free_card() ) . '">Prossimo libero</button>'
			. '<p class="description">Assegnata a mano, univoca, modificabile.</p></td></tr>';
		echo '<tr class="asem-row-firstname"><th>Nome *</th><td><input type="text" name="first_name" value="' . esc_attr( $val( 'first_name' ) ) . '" class="regular-text"></td></tr>'; // senza «required»: per un socio che è un ente il nome resta vuoto; il controllo è nel programma
		echo '<tr class="asem-row-lastname"><th>Cognome *</th><td><input type="text" name="last_name" value="' . esc_attr( $val( 'last_name' ) ) . '" class="regular-text" required></td></tr>';
		self::form_section( 'Contatti' );
		echo '<tr><th>Email</th><td><input type="email" name="email" id="asem-email" value="' . esc_attr( $val( 'email' ) ) . '" class="regular-text">'
			. '<p class="description asem-email-note">Facoltativa: con l\'email il socio ha subito il suo accesso all\'area soci. Senza email il socio si registra lo stesso (meglio se con cellulare o numero di tessera) e si attiva dopo con un link da mandare su WhatsApp.</p></td></tr>';
		echo '<tr><th>' . ( MemberType::GUEST === $type ? 'Cellulare' : 'Telefono' ) . '</th><td><input type="text" name="phone" value="' . esc_attr( $val( 'phone' ) ) . '" class="regular-text"' . ( MemberType::GUEST === $type ? ' required placeholder="333 1234567"' : '' ) . '>' . ( MemberType::GUEST === $type ? '<p class="description">Obbligatorio per gli ospiti: è il dato che serve a riconoscerli (anche se si registrano da soci diversi) e a contattarli su WhatsApp.</p>' : '' ) . '</td></tr>';
		self::form_section( 'Dati anagrafici' );
		if ( $sx ) {
			echo '<tr><th>Codice fiscale</th><td><span class="description">Visibile solo con il permesso «Vedere dati riservati ed esportare».</span></td></tr>';
		} else {
			echo '<tr><th>Codice fiscale</th><td><input type="text" name="tax_code" value="' . esc_attr( $val( 'tax_code' ) ) . '" class="regular-text"><p class="description">Facoltativo per l\'iscrizione fatta dalla segreteria. Se lo scrivi, chi attiva da solo il proprio accesso dovrà riscriverlo uguale (un controllo in più sull\'identità).</p></td></tr>';
		}
		$birth = $val( 'birth_date' );
		$minor = '' !== $birth && \AssociazioneSemplice\Age::is_minor( $birth, current_time( 'Y-m-d' ) );
		echo '<tr><th>Data di nascita</th><td><input type="date" name="birth_date" value="' . esc_attr( $birth ) . '" max="' . esc_attr( current_time( 'Y-m-d' ) ) . '">'
			. ( $minor ? ' <strong class="asem-warn">minorenne</strong>' : '' )
			. '<p class="description">Facoltativa; serve per i minorenni (che hanno un tutore) e per i controlli sui certificati.</p></td></tr>';
		echo '<tr><th>Luogo di nascita</th><td><input type="text" name="birth_place" value="' . esc_attr( $val( 'birth_place' ) ) . '" class="regular-text" maxlength="120" placeholder="Comune (e provincia)"><p class="description">Facoltativo; il libro dei soci lo riporta.</p></td></tr>';
		if ( MemberType::is_member( $type ) ) {
			$guardians = $id ? \AssociazioneSemplice\Guardians::of( $id ) : array();
			$cands     = array_values( array_filter( $people->search_light(), function ( $x ) use ( $id ) {
				return (int) $x['id'] !== $id && MemberType::GUEST !== $x['type']; // basta che il genitore sia censito: socio o «genitore o tutore»; chi opera sul sito deve avere l'email
			} ) );
			echo '<tr><th>Tutore</th><td><input type="hidden" name="guardians_present" value="1">';
			for ( $i = 0; $i < \AssociazioneSemplice\Guardians::MAX; $i++ ) {
				$is_op = isset( $guardians[ $i ] ) ? ! empty( $guardians[ $i ]['is_operative'] ) : 0 === $i;
				echo wp_kses( Ui::person_select( 'guardian_ids[]', $cands, isset( $guardians[ $i ] ) ? (int) $guardians[ $i ]['id'] : 0, $i ? '— secondo genitore (facoltativo) —' : '— nessun tutore —', 'asem-guardian-' . $i )
					. ' <label><input type="radio" name="guardian_operative" value="' . (int) $i . '"' . checked( $is_op, true, false ) . '> opera sul sito</label><br>', Html::allowed() );
			}
			echo '<p class="description">Per un minorenne indica i due genitori oppure il tutore legale, già registrati con un\'email: compaiono nel libro soci, nelle ricevute e nei consensi. Uno solo «opera sul sito»: risponde anche per l\'altro genitore (liberatorie e consensi compresi), vede tessera, prenotazioni e pagamenti del minore nella propria area soci, paga per lui e riceve le sue email. Il minore può non avere né email né accesso. Il collegamento resta anche dopo i 18 anni, finché non lo togli qui. Serve la data di nascita.</p>';
			echo '<p><strong>Il genitore non è ancora registrato?</strong> Inseriscilo qui (non serve che sia socio): <input type="text" name="new_guardian_first_name" placeholder="Nome" size="14"> <input type="text" name="new_guardian_last_name" placeholder="Cognome" size="16"> <input type="text" name="new_guardian_tax_code" placeholder="Codice fiscale" size="18" maxlength="16"> <input type="email" name="new_guardian_email" placeholder="Email (se opera sul sito)" size="22"></p>';
			if ( $id ) {
				$wards =\AssociazioneSemplice\Guardians::dependents_of( $id );
				if ( $wards ) {
					$ward_links = array();
					foreach ( $wards as $w ) {
						$ward_links[] = '<a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $w['id'] ) ) ) . '">' . esc_html( $w['first_name'] . ' ' . $w['last_name'] ) . '</a>';
					}
					echo '<p>È tutore di: ' . wp_kses_post( implode( ', ', $ward_links ) ) . '</p>';
				}
			}
			echo '</td></tr>';
		}
		self::form_section( 'Indirizzo' );
		echo '<tr><th>Indirizzo</th><td><input type="text" name="address" value="' . esc_attr( $val( 'address' ) ) . '" class="regular-text" maxlength="190" placeholder="Via e numero"> '
			. 'CAP <input type="text" name="zip" value="' . esc_attr( $val( 'zip' ) ) . '" size="7" maxlength="12"> Comune <input type="text" name="city" value="' . esc_attr( $val( 'city' ) ) . '" maxlength="100"> Prov. <input type="text" name="province" value="' . esc_attr( $val( 'province' ) ) . '" size="3" maxlength="5">'
			. '<p class="description">Facoltativo per l\'iscrizione fatta dalla segreteria; chi si attiva dal sito deve inserirlo.</p></td></tr>';
		self::form_section( 'Iscrizione' );
		echo '<tr><th>Data di ingresso</th><td><input type="date" name="joined_on" value="' . esc_attr( $val( 'joined_on' ) ?: current_time( 'Y-m-d' ) ) . '"></td></tr>';
		if ( MemberType::is_member( $type ) ) {
			echo '<tr><th>Data della delibera</th><td><input type="date" name="approved_on" value="' . esc_attr( $val( 'approved_on' ) ) . '"><p class="description">Quando il consiglio direttivo ha accettato la domanda (per un minore vale la stessa data). Se la lasci vuota, il libro dei soci riporta la data di ingresso; con una domanda online si compila da sola all\'approvazione.</p></td></tr>';
		}
		if ( MemberType::is_member( $type ) ) {
			$ic = $val( 'image_consent' );
			echo wp_kses( '<tr><th>Foto e video</th><td><select name="image_consent">' . Ui::options( array( '1' => 'Acconsente alla pubblicazione', '0' => 'Non acconsente' ), '' === (string) $ic ? '' : (string) (int) $ic, 'Non ancora chiesto' ) . '</select>'
				. '<p class="description">Per un minorenne risponde il tutore che opera sul sito, anche verso l\'altro genitore.</p></td></tr>', Html::allowed() );
			echo wp_kses( '<tr><th>Tipo di tesseramento</th><td><select name="affiliation_role">' . Ui::options( \AssociazioneSemplice\MembershipRoles::labels(), (string) $val( 'affiliation_role' ), '— da indicare —' ) . '</select>'
				. '<p class="description">Come va comunicato all\'ente di promozione sportiva (atleta, istruttore, dirigente…).</p></td></tr>', Html::allowed() );
		}
		if ( MemberType::is_member( $type ) ) { // diritto di voto e tipo di soggetto: servono ai «Dati per il RUNTS» e a votazioni e assemblee
			$kind = \AssociazioneSemplice\RuntsRules::kind( $val( 'subject_kind' ) );
			$same = $val( 'runts_same_section' );
			$pro  = \AssociazioneSemplice\Edition::has( 'levels' );
			$why  = $p ? \AssociazioneSemplice\VotingRight::reason( $p, \AssociazioneSemplice\Db::today() ) : 'new';
			$vote = array(
				''        => 'Sì',
				'nobirth' => 'Sì (manca la data di nascita)',
				'minor'   => 'No: è minorenne',
				'level'   => $pro ? 'No: il suo livello di socio non vota' : 'No',
				'new'     => 'Si vede dopo aver salvato',
			);
			echo wp_kses( '<tr><th>Diritto di voto</th><td>' . esc_html( $vote[ $why ] ?? 'Sì' ) . '<p class="description">'
				. ( $pro ? 'Dipende dal <strong>livello</strong> del socio (si decide in Impostazioni → Soci e quote, «Livelli di socio»)' : 'Hanno diritto di voto tutti i soci' )
				. ' e i minorenni non votano mai. Conta nelle votazioni di tutti i soci, nel numero legale delle assemblee e nei «Dati per il RUNTS».</p></td></tr>', Html::allowed() );
			echo wp_kses( '<tr><th>Il socio è</th><td><select name="subject_kind">' . Ui::options( array( \AssociazioneSemplice\RuntsRules::PERSON => 'Una persona', \AssociazioneSemplice\RuntsRules::ENTITY => 'Un ente (associazione, società, ente pubblico…)' ), $kind ) . '</select>'
				. '<p class="description">Se è un ente, scrivi il suo nome nel campo «Cognome», lascia vuoto «Nome» e inserisci il suo codice fiscale (11 cifre).</p></td></tr>', Html::allowed() );
			echo wp_kses( '<tr class="asem-row-entity"><th>È iscritto al RUNTS nella tua stessa sezione?</th><td><select name="runts_same_section">' . Ui::options( array( '1' => 'Sì', '0' => 'No' ), $same, 'Non lo so' ) . '</select>'
				. '<p class="description">Solo per i soci che sono enti. Per esempio: se la tua associazione è una APS, rispondi Sì se anche questo ente è una APS. Serve per il numero minimo di soci.</p></td></tr>', Html::allowed() );
		}
		echo '<tr class="asem-row-host"><th>Partecipazioni precedenti</th><td><input type="number" name="prior_visits" min="0" max="9999" value="' . (int) $val( 'prior_visits' ) . '" class="small-text"><p class="description">Quante volte è già venuto prima di usare il programma: si somma alle partecipazioni registrate qui e conta per la soglia dell\'invito a iscriversi. Gli eventi passati puoi segnarli nelle note.</p></td></tr>';
		self::form_section( 'Note' );
		if ( $sx ) {
			echo '<tr><th>Note</th><td><span class="description">Visibile solo con il permesso «Vedere dati riservati ed esportare».</span></td></tr>';
		} else {
			echo '<tr><th>Note</th><td><textarea name="notes" rows="3" class="large-text">' . esc_textarea( $val( 'notes' ) ) . '</textarea></td></tr>';
		}
		echo '</tbody></table>';
		submit_button( $p ? 'Salva' : 'Crea' );
		Ui::form_close();

		if ( $p ) {
			echo '<hr>';
			Ui::form_open( 'asem_delete_person', $back, false, 'asem-confirm' );
			echo wp_kses( Ui::hidden( 'id', $id ), Html::allowed() );
			echo '<button class="button button-link-delete" data-confirm="Eliminare questa persona? L\'utente WordPress collegato non viene cancellato.">Elimina persona</button>';
			Ui::form_close();
		}
		echo '</div>';

		if ( $p ) {
			echo '<div class="asem-col">';
			self::panel_access( $p );
			self::panel_guest_status( $p );
			self::panel_membership( $p );
				RegistersPage::panel_left( $p );
			self::panel_card_qr( $p );
			if ( current_user_can( \AssociazioneSemplice\Plugin::CAP ) ) { // riservati agli amministratori
				self::panel_board( $p );
			}
			self::panel_rules( $p );
			self::panel_privacy( $p );
			self::panel_receipts( $p );
			if ( current_user_can( \AssociazioneSemplice\Plugin::CAP ) ) {
				self::panel_treasurer( $p );
				self::panel_staff( $p );
				self::panel_secretary( $p );
			}
			self::panel_guests( $p );
			self::panel_activities( $p );
			self::panel_bookings( $p );
			self::panel_payments( $p );
			echo '</div>';
		}
		echo '</div>';
		Ui::footer();
	}

	private static function panel_membership( array $p ): void {
		$people = Plugin::people();
		echo '<div class="asem-card"><h2>Tessera e iscrizione</h2>';
		if ( MemberType::GUARDIAN === $p['type'] ) {
			echo '<p>Genitore o tutore: non è un socio e non ha tessera né quota. Ha l\'accesso all\'area soci per seguire i figli (si collegano dalla loro scheda). Per iscriverlo come socio cambia il tipo qui sopra.</p></div>';
			return;
		}
		if ( MemberType::GUEST === $p['type'] ) {
			echo '<p>Gli ospiti non sono soci: partecipano alle attività tramite un socio.</p>';
			if ( $p['host_person_id'] ) {
				echo '<p>Ospite di <a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $p['host_person_id'] ) ) ) . '">' . esc_html( (string) ( $people->get( (int) $p['host_person_id'] )['last_name'] ?? '' ) ) . '</a></p>';
			}
			echo '</div>';
			return;
		}
		$until  = $people->active_until( (int) $p['id'] );
		$active = $until && $until >= current_time( 'Y-m-d' );
		echo wp_kses( '<p>' . ( $active ? '<strong class="asem-ok">Tessera valida fino al ' . Ui::date( $until ) . '</strong>' : '<strong class="asem-neg">Tessera non valida' . ( $until ? ' (scaduta il ' . Ui::date( $until ) . ')' : '' ) . '</strong>' ) . '</p>', Html::allowed() );
		if ( ! $active && MemberType::is_member( $p['type'] ) && ! MemberType::is_auto_renewed( $p['type'] ) ) { // quota versata a rate
			$m_year    = $people->membership_plan( (int) $p['id'], current_time( 'Y-m-d' ) )['year'];
			$m_missing = $people->membership_missing( $p, $m_year );
			if ( $m_missing > 0 ) {
				$m_fee = \AssociazioneSemplice\Levels::fee_for( $p );
				echo '<p>Quota associativa ' . esc_html( $m_year ) . ': versati <strong>' . esc_html( \AssociazioneSemplice\Money::format( $m_fee - $m_missing ) ) . '</strong> su ' . esc_html( \AssociazioneSemplice\Money::format( $m_fee ) ) . ', mancano <strong>' . esc_html( \AssociazioneSemplice\Money::format( $m_missing ) ) . '</strong>. La tessera si attiva a quota saldata. <a class="button button-small" href="' . esc_url( Ui::url( 'asem-income', array( 'person_id' => $p['id'], 'due' => 1 ) ) ) . '">Incassa il saldo</a></p>';
			}
		}
		if ( MemberType::is_auto_renewed( $p['type'] ) ) {
			echo '<p class="description">Socio fondatore: la tessera è sempre rinnovata (scadenza a ' . (int) Settings::get( 'founder_years' ) . ' anni dall\'ingresso).</p></div>';
			return;
		}
		$cur = Settings::membership_year();
		$dmy  = function ( \DateTimeImmutable $d ): string {
			return $d->format( 'd/m/Y' );
		};
		$opts = array(
			$cur->previous()->label() => $cur->previous()->label() . ' (dal ' . $dmy( $cur->previous()->start() ) . ' al ' . $dmy( $cur->previous()->end() ) . ')',
			$cur->label()             => $cur->label() . ' (corrente, dal ' . $dmy( $cur->start() ) . ' al ' . $dmy( $cur->end() ) . ')',
			$cur->next()->label()     => $cur->next()->label() . ' (dal ' . $dmy( $cur->next()->start() ) . ' al ' . $dmy( $cur->next()->end() ) . ')',
		);
		Ui::form_open( 'asem_set_membership', Ui::url( 'asem-person', array( 'id' => $p['id'] ) ) );
		echo wp_kses( Ui::hidden( 'id', $p['id'] ), Html::allowed() );
		echo wp_kses( '<p>Anno della tessera: <select name="social_year">' . Ui::options( $opts, $cur->label() ) . '</select> ', Html::allowed() );
		echo '<button class="button" name="enabled" value="1">Attiva la tessera</button> <button class="button" name="enabled" value="0">Togli la tessera</button></p>';
		Ui::form_close();
		echo '<p class="description">Incassando la quota associativa la tessera si attiva da sola. Qui la attivi a mano per chi ha già pagato.</p>';
		if ( ! empty( $p['suspended_at'] ) ) {
			Ui::form_open( 'asem_reactivate_member', Ui::url( 'asem-person', array( 'id' => $p['id'] ) ), false, 'asem-inline' );
			echo wp_kses( '<p><strong class="asem-warn">Socio sospeso dal ' . esc_html( mysql2date( 'd/m/Y', $p['suspended_at'] ) ) . ' (inattivo).</strong> ' . Ui::hidden( 'id', $p['id'] ) . '<button class="button">Riattiva il socio</button> <span class="description">Va riattivato a mano prima di poter incassare la quota o prenotare.</span></p>', Html::allowed() );
			Ui::form_close();
		} else {
			Ui::form_open( 'asem_suspend_member', Ui::url( 'asem-person', array( 'id' => $p['id'] ) ), false, 'asem-inline' );
			echo wp_kses( Ui::hidden( 'id', $p['id'] ) . '<p><button class="button" data-confirm="Sospendere questo socio? Diventa inattivo finché non lo riattivi.">Sospendi il socio</button></p>', Html::allowed() );
			Ui::form_close();
		}
		$rows = $people->memberships( (int) $p['id'] );
		if ( $rows ) {
			echo '<table class="widefat striped"><thead><tr><th>Anno della tessera</th><th>Dal</th><th>Al</th><th>Origine</th></tr></thead><tbody>';
			foreach ( $rows as $m ) {
				$note = '';
			if ( ! empty( $m['replaced_by'] ) ) { // sostituita da una tessera più recente dello stesso anno fiscale: si vede solo qui, mai nel libro soci
				$by   = array_values( array_filter( $rows, function ( $x ) use ( $m ) {
					return (int) $x['id'] === (int) $m['replaced_by'];
				} ) );
				$note = '<br><span class="description">Sostituita dalla tessera ' . esc_html( $by ? (string) $by[0]['social_year'] : '' ) . ': resta registrata e i pagamenti non cambiano.</span>';
			}
			echo wp_kses( '<tr><td>' . esc_html( $m['social_year'] ) . $note . '</td><td>' . Ui::date( $m['valid_from'] ) . '</td><td>' . Ui::date( $m['valid_to'] ) . '</td><td>' . esc_html( $m['source'] ) . '</td></tr>', Html::allowed() );
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	/** Per un socio senza accesso: segnalazione e pulsante che apre WhatsApp con il link di attivazione già pronto. */
	private static function invite_link( array $p ): string {
		$wa = \AssociazioneSemplice\Phone::whatsapp( (string) $p['phone'] );
		if ( '' === $wa ) {
			return '<span class="asem-warn">Non è ancora entrato nell\'area soci</span> <span class="description">(senza cellulare: apri la scheda per il link)</span>';
		}
		return '<span class="asem-warn">Non è ancora entrato nell\'area soci</span> <a class="button button-small" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/' . $wa . '?text=' . rawurlencode( \AssociazioneSemplice\Frontend\Activation::invite_text( $p ) ) ) . '">💬 Invia link</a>';
	}

	/** Socio con un utente WordPress ma senza più poteri: l'amministratore può farlo passare all'accesso con link. */
	private static function release_panel( array $p ): void {
		$uid = (int) ( $p['wp_user_id'] ?? 0 );
		if ( $uid <= 0 || ! current_user_can( \AssociazioneSemplice\Plugin::CAP ) || ! \AssociazioneSemplice\MemberSession::enabled() || \AssociazioneSemplice\Access::has_powers( $uid ) ) {
			return;
		}
		echo '<hr><p><strong>Passa all\'accesso con link</strong><br><span class="description">Non ha poteri oltre a quelli di socio. Con questo passaggio l\'utente WordPress viene eliminato e da ora entra solo con un link o un codice che riceve per email (password facoltativa). Non si elimina se ha scritto contenuti o ha ordini nel negozio. I dati della scheda non cambiano.</span></p>';
		Ui::form_open( 'asem_release_wp_user', Ui::url( 'asem-person', array( 'id' => (int) $p['id'] ) ) );
		echo wp_kses( Ui::hidden( 'id', $p['id'] ) . '<button class="button" data-confirm="Eliminare il suo utente WordPress? Da ora entrerà con un link o un codice ricevuto per email.">Passa all\'accesso con link</button>', Html::allowed() );
		Ui::form_close();
	}

	/** Accesso all'area soci di un socio: attivo, oppure link di attivazione da mandare (WhatsApp o copia). */
	private static function panel_access( array $p ): void {
		if ( ! MemberType::is_member( $p['type'] ) ) {
			return;
		}
		echo '<div class="asem-card"><h2>Accesso all\'area soci</h2>';
		if ( \AssociazioneSemplice\PeopleService::has_access( $p ) ) {
			echo '<p><strong class="asem-ok">Accesso attivo</strong> · email ' . esc_html( (string) $p['email'] ) . ( empty( $p['wp_user_id'] ) ? ' · entra con un link o un codice che riceve per email' : '' ) . '</p>';
			self::detach_buttons( $p );
			self::release_panel( $p );
			echo '</div>';
			return;
		}
		$url = \AssociazioneSemplice\Frontend\Activation::url( (int) $p['id'] );
		echo '<p><strong class="asem-warn">Non è ancora entrato nell\'area soci.</strong> Il socio non ha ancora un\'email collegata: con questo link sceglie email e password e attiva il proprio accesso. Il link vale ' . esc_html( \AssociazioneSemplice\Frontend\Activation::validity_text() ) . '; se scade, riapri questa scheda per averne uno nuovo.</p>'
			. '<p><input type="text" readonly class="large-text" value="' . esc_attr( $url ) . '" data-asem-select></p>';
		$wa = \AssociazioneSemplice\Phone::whatsapp( (string) $p['phone'] );
		if ( '' !== $wa ) {
			$msg = \AssociazioneSemplice\Frontend\Activation::invite_text( $p );
			echo '<p><a class="button button-primary" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/' . $wa . '?text=' . rawurlencode( $msg ) ) . '">💬 Invia il link su WhatsApp</a> '
				. '<button type="button" class="button" data-asem-copy="' . esc_attr( $msg ) . '">Copia il messaggio</button> '
				. '<span class="description">Se WhatsApp non si apre, copia il messaggio e incollalo nella chat del socio (numero: +' . esc_html( $wa ) . '). Il link vale ' . esc_html( \AssociazioneSemplice\Frontend\Activation::validity_text() ) . ': dopo, se ne genera un altro da questa scheda.</span></p>';
		} else {
			echo '<p class="description">Senza cellulare: copia il link e mandalo come preferisci. Oppure aggiungi l\'email qui sopra: l\'accesso si crea subito.</p>';
		}
		self::detach_buttons( $p );
		echo '</div>';
	}

	/** «Scollega email» e «Scollega numero di telefono»: si riparte senza il dato ma lo storico resta. Solo segreteria e amministratori (la pagina è già riservata). */
	private static function detach_buttons( array $p ): void {
		$back = Ui::url( 'asem-person', array( 'id' => $p['id'] ) );
		if ( ! empty( $p['email'] ) || ! empty( $p['wp_user_id'] ) ) {
			Ui::form_open( 'asem_detach_email', $back, false, 'asem-inline' );
			echo wp_kses( Ui::hidden( 'id', $p['id'] ) . '<p><button class="button" data-confirm="Scollegare l\'email? Il socio perde l\'accesso all\'area soci finché non lo riattiva con un nuovo link; lo storico resta.">Scollega email</button> <span class="description">Il socio perde l\'accesso e può riattivarlo col link; lo storico resta. L\'utente del sito non viene cancellato: per riattivarsi il socio dovrà usare un\'altra email.</span></p>', Html::allowed() );
			Ui::form_close();
		}
		if ( ! empty( $p['phone'] ) ) {
			Ui::form_open( 'asem_detach_phone', $back, false, 'asem-inline' );
			echo wp_kses( Ui::hidden( 'id', $p['id'] ) . '<p><button class="button" data-confirm="Scollegare il numero di telefono? Lo storico resta.">Scollega numero di telefono</button> <span class="description">Toglie il numero ' . esc_html( (string) $p['phone'] ) . ' dalla scheda; lo storico resta.</span></p>', Html::allowed() );
			Ui::form_close();
		}
	}

	/** Etichetta per un ospite: quante volte è venuto, eventuali registrazioni "gemelle" (stesso nome, email o telefono) e se è da invitare a iscriversi. */
	public static function guest_badge( ?array $ov ): string {
		if ( ! $ov ) {
			return '';
		}
		$txt = $ov['count'] . ( 1 === $ov['count'] ? ' partecipazione' : ' partecipazioni' );
		if ( $ov['twins'] ) {
			$txt .= ' · registrato anche come ' . count( $ov['twins'] ) . ( 1 === count( $ov['twins'] ) ? ' altro ospite' : ' altri ospiti' ) . ': in tutto ' . $ov['total'];
		}
		if ( $ov['flag'] ) {
			return '<strong class="asem-neg">' . esc_html( $txt . ': da invitare a diventare socio' ) . '</strong>';
		}
		return $ov['twins'] ? '<strong class="asem-warn">' . esc_html( $txt ) . '</strong>' : '<span class="description">' . esc_html( $txt ) . '</span>';
	}

	/** Scheda di un ospite: a cosa è già venuto (eventi e corsi), se risulta registrato più volte e l'iscrizione come socio. */
	private static function panel_guest_status( array $p ): void {
		if ( MemberType::GUEST !== $p['type'] ) {
			return;
		}
		$st = Plugin::activities()->guest_status( (int) $p['id'] );
		$ov = Plugin::people()->guest_overview()[ (int) $p['id'] ] ?? null;
		echo wp_kses( '<div class="asem-card"><h2>Partecipazioni come ospite</h2><p>' . self::guest_badge( $ov ) . '</p>', Html::allowed() );
		if ( $ov && $ov['flag'] ) {
			echo '<p class="asem-neg">Ha raggiunto la soglia di partecipazioni per gli ospiti' . ( $ov['twins'] ? ' (sommando le altre registrazioni)' : '' ) . ': conviene invitarlo a iscriversi come socio, anche per l\'assicurazione. Nessun blocco automatico: decidi tu.</p>';
		}
		if ( $ov && $ov['twins'] ) {
			echo '<p><strong>Potrebbe essere la stessa persona registrata più volte:</strong></p><ul>';
			foreach ( $ov['twins'] as $t ) {
				echo '<li><a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $t['id'] ) ) ) . '">' . esc_html( $t['name'] ) . '</a> <span class="description">ospite di ' . esc_html( $t['host'] ) . ' · ' . (int) $t['count'] . ' partecipazioni · ' . esc_html( implode( ', ', array_unique( $t['why'] ) ) ) . '</span></li>';
			}
			echo '</ul>';
		}
		if ( $st['items'] ) {
			echo '<table class="widefat striped"><thead><tr><th>Quando</th><th>A cosa</th><th>Stato</th></tr></thead><tbody>';
			foreach ( $st['items'] as $i ) {
				$when  = 'event' === $i['type'] ? Ui::date( $i['when'] ) . ( $i['time'] ? ' ' . esc_html( $i['time'] ) : '' ) : 'dal ' . esc_html( $i['when'] );
				$state = 'event' === $i['type'] ? ( $i['checked_in'] ? '<span class="asem-ok">✔ è venuto</span>' : ( $i['ended'] ? 'prenotato, ingresso non registrato' : 'prenotato' ) ) : ( $i['ended'] ? 'corso concluso' : 'iscritto al corso' );
				echo wp_kses( '<tr><td>' . $when . '</td><td><a href="' . esc_url( Ui::url( 'asem-activity', array( 'id' => $i['activity_id'] ) ) ) . '">' . esc_html( $i['activity_name'] ) . '</a> <span class="description">' . ( 'event' === $i['type'] ? 'evento' : 'corso' ) . '</span></td><td>' . $state . '</td></tr>', Html::allowed() );
			}
			echo '</tbody></table>';
		} else {
			echo '<p class="description">Non ha ancora partecipato a nulla.</p>';
		}
		$wa = \AssociazioneSemplice\Phone::whatsapp( (string) $p['phone'] );
		if ( '' !== $wa ) {
			$assoc = (string) \AssociazioneSemplice\Settings::get( 'association_name' );
			$msg   = 'Ciao ' . $p['first_name'] . ', grazie di aver partecipato' . ( '' !== $assoc ? ' alle attività di ' . $assoc : '' ) . '. Se ti fa piacere continuare, puoi diventare socio: ti spiego come?';
			echo '<p><a class="button" href="' . esc_url( 'https://wa.me/' . $wa . '?text=' . rawurlencode( $msg ) ) . '" target="_blank" rel="noopener">💬 Scrivi su WhatsApp</a> <span class="description">cellulare ' . esc_html( (string) $p['phone'] ) . '</span></p>';
		}
		Ui::form_open( 'asem_promote_guest', Ui::url( 'asem-person', array( 'id' => (int) $p['id'] ) ), false, 'asem-confirm' );
		echo wp_kses( '<details style="margin-top:10px"' . ( $ov && $ov['flag'] ? ' open' : '' ) . '><summary><strong>Iscrivi come socio</strong></summary>' . Ui::hidden( 'id', $p['id'] )
			. '<p>Email (facoltativa) <input type="email" name="email" value="' . esc_attr( (string) $p['email'] ) . '"> tipo <select name="type">' . Ui::options( array( MemberType::ORDINARY => MemberType::label( MemberType::ORDINARY ), MemberType::VOLUNTEER => MemberType::label( MemberType::VOLUNTEER ) ), MemberType::ORDINARY ) . '</select> '
			. 'n. tessera (facoltativo) <input type="text" name="card_number" class="small-text"></p>'
			. '<p><label><input type="checkbox" name="membership" value="1" checked> Segna la quota del ' . esc_html( \AssociazioneSemplice\Settings::membership_year()->label() ) . ' come pagata</label> <button class="button button-primary">Iscrivi come socio</button></p>'
			. '<p class="description">La scheda resta la stessa: tutte le partecipazioni e i pagamenti già registrati restano collegati. Si crea l\'utente per l\'area soci.</p></details>', Html::allowed() );
		Ui::form_close();
		echo '</div>';
	}

	/** QR di verifica della tessera: si può stampare o girare al socio (è lo stesso che vede nella sua area soci). */
	private static function panel_card_qr( array $p ): void {
		if ( ! MemberType::is_member( $p['type'] ) ) {
			return;
		}
		$html = '<div class="asem-card"><h2>Tessera</h2><p><a class="button" target="_blank" rel="noopener" href="' . esc_url( \AssociazioneSemplice\CardLayout::pdf_url( (int) $p['id'] ) ) . '">Tessera in PDF (da stampare)</a></p>';
		if ( \AssociazioneSemplice\Settings::card_qr_enabled() ) {
			$url   = \AssociazioneSemplice\Settings::card_url( (int) $p['id'] );
			$html .= '<h3>QR della tessera</h3><div style="max-width:170px">' . \AssociazioneSemplice\QrCode::svg( $url, 4, 'QR della tessera' ) . '</div>'
				. '<p class="description"><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">Apri la pagina di verifica</a> · stesso codice che il socio vede nella sua area soci.</p>';
		}
		echo wp_kses( $html . '</div>', Html::allowed() );
	}

	/** Privacy: consenso registrato, scarico dei dati, anonimizzazione. */
	/** « — per conto del minore, da Mario Rossi» se ha accettato un tutore. */
	private static function accepted_by( $by ): string {
		$g = $by ? Plugin::people()->get( (int) $by ) : null;
		return $g ? ' — per conto del minore, da <a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $g['id'] ) ) ) . '">' . esc_html( $g['first_name'] . ' ' . $g['last_name'] ) . '</a>' : '';
	}

	private static function panel_privacy( array $p ): void {
		$id = (int) $p['id'];
		echo '<div class="asem-card"><h2>Privacy</h2>';
		$gc = \AssociazioneSemplice\GuardianConsent::pending( $p );
		if ( $gc ) { // genitore già in anagrafica: i consensi dati a nome del minore non sono ancora attribuiti a lui
			$gp = Plugin::people()->get( (int) $gc['guardian'] );
			echo wp_kses( '<p class="asem-warn"><strong>In attesa della conferma del genitore</strong>' . ( $gp ? ' (<a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $gp['id'] ) ) ) . '">' . esc_html( $gp['first_name'] . ' ' . $gp['last_name'] ) . '</a>)' : '' ) . ': il collegamento si crea quando conferma; fino ad allora regolamento, privacy e immagini non risultano accettati da lui. Email inviata il' . esc_html( mysql2date( 'd/m/Y', $gc['sent'] ) ) . ( $gc['expired'] ? '; il link è scaduto' : '' ) . '.</p>', Html::allowed() );
			Ui::form_open( 'asem_guardian_consent_resend', Ui::url( 'asem-person', array( 'id' => $id ) ), false, 'asem-inline' );
			echo wp_kses( Ui::hidden( 'id', $id ) . '<button class="button">Rimanda l\'email di conferma</button>', Html::allowed() );
			Ui::form_close();
		}
		if ( \AssociazioneSemplice\Privacy::has_consent( $p ) ) {
			echo wp_kses( '<p><strong class="asem-ok">Consenso registrato</strong> il ' . esc_html( mysql2date( 'd/m/Y', $p['privacy_consent_at'] ) ) . ' (' . esc_html( \AssociazioneSemplice\Privacy::SOURCES[ $p['privacy_consent_source'] ] ?? '—' ) . ')' . self::accepted_by( $p['privacy_consent_by'] ?? null ) . '</p>', Html::allowed() );
			Ui::form_open( 'asem_privacy_consent', Ui::url( 'asem-person', array( 'id' => $id ) ), false, 'asem-inline' );
			echo wp_kses( Ui::hidden( 'id', $id ) . Ui::hidden( 'mode', 'clear' ) . '<button class="button-link" data-confirm="Rimuovere il consenso registrato?">rimuovi il consenso</button>', Html::allowed() );
			Ui::form_close();
		} else {
			echo '<p>Consenso non registrato.</p>';
			Ui::form_open( 'asem_privacy_consent', Ui::url( 'asem-person', array( 'id' => $id ) ) );
			echo wp_kses( Ui::hidden( 'id', $id ) . '<select name="mode">' . Ui::options( \AssociazioneSemplice\Privacy::SOURCES, 'paper' ) . '</select> <button class="button">Registra il consenso</button>', Html::allowed() );
			Ui::form_close();
		}
		echo '<p><a class="button" href="' . esc_url( \AssociazioneSemplice\Privacy::export_url( $id ) ) . '">Scarica i dati</a></p>';
		$why = \AssociazioneSemplice\Privacy::blocker( $id );
		if ( ! current_user_can( \AssociazioneSemplice\Plugin::CAP ) ) {
			// la cancellazione dei dati la decide un amministratore
		} elseif ( '' === $why ) {
			Ui::form_open( 'asem_privacy_anonymize', Ui::url( 'asem-comms' ), false, 'asem-inline' );
			echo wp_kses( Ui::hidden( 'id', $id ) . '<button class="button" data-confirm="Anonimizzare questa persona? Nome, contatti, codice fiscale, tessera e note vengono tolti e non si recuperano. I movimenti contabili restano.">Anonimizza (cancellazione dati)</button>', Html::allowed() );
			Ui::form_close();
		} else {
			echo '<p class="description">Anonimizzazione non possibile ora: ' . esc_html( $why ) . '</p>';
		}
		echo '</div>';
	}

	/** Regolamento: accettazione registrata (versione e modalità) e registrazione a mano. */
	private static function panel_rules( array $p ): void {
		if ( ! \AssociazioneSemplice\Regulation::applies_to( $p ) ) {
			return;
		}
		$id = (int) $p['id'];
		echo '<div class="asem-card"><h2>' . esc_html( \AssociazioneSemplice\Regulation::title() ) . '</h2>';
		if ( \AssociazioneSemplice\Regulation::accepted( $p ) ) {
			echo wp_kses( '<p><strong class="asem-ok">Accettato</strong> il ' . esc_html( mysql2date( 'd/m/Y', $p['rules_accepted_at'] ) ) . ' (versione ' . esc_html( (string) $p['rules_accepted_version'] ) . ', ' . esc_html( \AssociazioneSemplice\Regulation::SOURCES[ $p['rules_accepted_source'] ] ?? '—' ) . ')' . self::accepted_by( $p['rules_accepted_by'] ?? null ) . '</p>', Html::allowed() );
			Ui::form_open( 'asem_rules_record', Ui::url( 'asem-person', array( 'id' => $id ) ), false, 'asem-inline' );
			echo wp_kses( Ui::hidden( 'id', $id ) . Ui::hidden( 'mode', 'clear' ) . '<button class="button-link" data-confirm="Rimuovere l\'accettazione registrata?">rimuovi l\'accettazione</button>', Html::allowed() );
			Ui::form_close();
		} else {
			echo '<p>' . ( ! empty( $p['rules_accepted_at'] ) ? 'Ha accettato la versione ' . esc_html( (string) $p['rules_accepted_version'] ) . ': ora è in vigore la ' . esc_html( \AssociazioneSemplice\Regulation::version() ) . '.' : 'Non ancora accettato.' ) . '</p>';
			Ui::form_open( 'asem_rules_record', Ui::url( 'asem-person', array( 'id' => $id ) ) );
			echo wp_kses( Ui::hidden( 'id', $id ) . '<select name="mode">' . Ui::options( \AssociazioneSemplice\Regulation::SOURCES, 'paper' ) . '</select> <button class="button">Registra l\'accettazione</button>', Html::allowed() );
			Ui::form_close();
		}
		echo '</div>';
	}

	/** Ricevute e attestazioni annuali della persona (le aggiunge un'estensione). */
	private static function panel_receipts( array $p ): void {
		do_action( 'asem_person_receipts', $p );
	}

	/** Carica nel consiglio direttivo: presidente, vicepresidente, consigliere. */
	private static function panel_board( array $p ): void {
		if ( ! \AssociazioneSemplice\BoardRole::eligible_type( $p['type'] ) ) {
			return;
		}
		$svc  = Plugin::people();
		echo '<div class="asem-card"><h2>Consiglio direttivo</h2>';
		Ui::form_open( 'asem_set_board_role', Ui::url( 'asem-person', array( 'id' => (int) $p['id'] ) ) );
		echo wp_kses( Ui::hidden( 'id', $p['id'] ) . '<select name="board_role"><option value="">Nessuna carica</option>', Html::allowed() );
		foreach ( \AssociazioneSemplice\BoardRole::labels() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( (string) $p['board_role'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <button class="button">Salva</button>';
		Ui::form_close();
		echo '<p class="description">Presidente e vicepresidente sono uno ciascuno, i consiglieri sono al massimo ' . (int) \AssociazioneSemplice\Settings::councillors() . ' (si cambia in Impostazioni). Serve la tessera in regola.</p>';
		if ( ! $svc->is_active_member( (int) $p['id'] ) && '' !== (string) $p['board_role'] ) {
			echo '<p class="asem-neg">Attenzione: questo socio non è più in regola con la tessera.</p>';
		}
		echo '</div>';
	}

	/** Ruolo Segreteria: lavora su soci, attività e contabilità senza essere amministratore del sito. */
	private static function panel_secretary( array $p ): void {
		if ( \AssociazioneSemplice\MemberType::GUEST === $p['type'] || ! \AssociazioneSemplice\PeopleService::has_access( $p ) ) {
			return;
		}
		$user = ! empty( $p['wp_user_id'] ) ? get_userdata( (int) $p['wp_user_id'] ) : null; // senza utente WordPress (accesso proprio) lo si crea quando si dà il ruolo
		if ( $user && $user->has_cap( \AssociazioneSemplice\Plugin::CAP ) ) {
			return;
		}
		$on = $user && in_array( \AssociazioneSemplice\Plugin::ROLE_SECRETARY, (array) $user->roles, true );
		echo '<div class="asem-card"><h2>Segreteria</h2>';
		echo '<p>' . ( $on ? '<strong class="asem-ok">Fa parte della segreteria</strong>' : 'Non fa parte della segreteria.' ) . '</p>';
		Ui::form_open( 'asem_set_secretary', Ui::url( 'asem-person', array( 'id' => (int) $p['id'] ) ) );
		echo wp_kses( Ui::hidden( 'id', $p['id'] ) . ( $on ? '' : Ui::hidden( 'enabled', 1 ) )
			. '<button class="button">' . ( $on ? 'Togli dalla segreteria' : 'Aggiungi alla segreteria' ) . '</button>', Html::allowed() );
		Ui::form_close();
		echo '<p class="description">La segreteria accede all\'amministrazione per gestire soci, attività, incassi e spese, comunicazioni e ricevute. Non vede Impostazioni, pagamenti online, privacy (anonimizzazione), testi personalizzati e anni fiscali.</p></div>';
	}

	/** Permesso di registrare spese dall'area soci (per chi non usa l'amministrazione del sito). */
	private static function panel_treasurer( array $p ): void {
		if ( MemberType::GUEST === $p['type'] || ! \AssociazioneSemplice\PeopleService::has_access( $p ) ) {
			return;
		}
		$on = \AssociazioneSemplice\Access::is_treasurer( (int) ( $p['wp_user_id'] ?? 0 ) );
		echo '<div class="asem-card"><h2>Tesoriere</h2>';
		echo '<p>' . ( $on ? '<strong class="asem-ok">È tesoriere: dall\'area soci può incassare quote e contributi, registrare spese, iscrivere nuovi soci e incassare gli eventi.</strong>' : 'Non è tesoriere: dall\'area soci non può incassare, registrare spese né iscrivere soci.' ) . '</p>';
		Ui::form_open( 'asem_set_treasurer', Ui::url( 'asem-person', array( 'id' => (int) $p['id'] ) ) );
		echo wp_kses( Ui::hidden( 'id', $p['id'] ) . ( $on ? '' : Ui::hidden( 'enabled', 1 ) )
			. '<button class="button"' . ( $on ? '' : ' data-confirm="' . esc_attr( 'Nominare ' . trim( $p['first_name'] . ' ' . $p['last_name'] ) . ' tesoriere? Potrà incassare denaro, registrare spese e iscrivere nuovi soci dall\'area soci.' ) . '"' ) . '>' . ( $on ? 'Togli l\'incarico di tesoriere' : 'Nomina tesoriere' ) . '</button>', Html::allowed() );
		Ui::form_close();
		echo '<p class="description">Nell\'area soci gli compare la pagina «Area tesoriere», da cui incassa, fotografa lo scontrino e registra la spesa. Vede solo gli incassi e le spese che ha registrato lui, non i saldi dei conti.</p></div>';
	}

	/** Staff dell'ente: verifica gli accessi a tutti gli eventi. Per l'incasso sul posto serve inoltre l'abilitazione sul singolo evento. */
	private static function panel_staff( array $p ): void {
		if ( ! MemberType::is_member( $p['type'] ) || ! \AssociazioneSemplice\PeopleService::has_access( $p ) ) {
			return;
		}
		$on = \AssociazioneSemplice\Access::is_entity_staff( (int) ( $p['wp_user_id'] ?? 0 ) );
		echo '<div class="asem-card"><h2>Staff dell\'ente</h2>';
		echo '<p>' . ( $on ? '<strong class="asem-ok">Registra gli ingressi a tutti gli eventi</strong>' : 'Non fa parte dello staff dell\'ente.' ) . '</p>';
		Ui::form_open( 'asem_set_staff', Ui::url( 'asem-person', array( 'id' => (int) $p['id'] ) ) );
		echo wp_kses( Ui::hidden( 'id', $p['id'] ) . ( $on ? '' : Ui::hidden( 'enabled', 1 ) )
			. '<button class="button">' . ( $on ? 'Togli dallo staff' : 'Aggiungi allo staff' ) . '</button>', Html::allowed() );
		Ui::form_close();
		echo '<p class="description">Lo staff dell\'ente registra gli ingressi a tutti gli eventi; non gestisce soldi né comunicazioni. Si può anche nominare lo staff di un singolo evento, dalla scheda dell\'attività: solo lì si può abilitare l\'incasso del contributo all\'ingresso.</p></div>';
	}

	private static function panel_guests( array $p ): void {
		if ( ! MemberType::is_member( $p['type'] ) ) {
			return;
		}
		$guests = Plugin::people()->guests_of( (int) $p['id'] );
		echo '<div class="asem-card"><h2>Ospiti di questo socio</h2>';
		if ( $guests ) {
			echo '<ul>';
			foreach ( $guests as $g ) {
				echo '<li><a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $g['id'] ) ) ) . '">' . esc_html( $g['first_name'] . ' ' . $g['last_name'] ) . '</a></li>';
			}
			echo '</ul>';
		} else {
			echo '<p class="description">Nessun ospite.</p>';
		}
		echo '<a class="button" href="' . esc_url( Ui::url( 'asem-person', array( 'type' => 'guest', 'host' => $p['id'] ) ) ) . '">Aggiungi ospite</a></div>';
	}

	private static function panel_activities( array $p ): void {
		$statuses = Plugin::activities()->status_for_person( (int) $p['id'] );
		echo '<div class="asem-card"><h2>Attività e pagamenti</h2>';
		if ( ! $statuses ) {
			echo '<p class="description">Non è iscritto a nessuna attività. Si iscrive dalla scheda dell\'attività.</p></div>';
			return;
		}
		foreach ( $statuses as $s ) {
			$e = $s['enrollment'];
			echo wp_kses( '<details class="asem-detail"><summary><strong><a href="' . esc_url( Ui::url( 'asem-activity', array( 'id' => $e['activity_id'] ) ) ) . '">' . esc_html( $s['activity']['name'] ) . '</a></strong> (' . esc_html( $s['activity']['social_year'] ) . ') — ' . Ui::pay_status( $s['summary'] ) . '</summary>', Html::allowed() );
			echo '<p class="description">' . ( null === $e['end_month'] ? 'Iscritto dal ' . esc_html( Ui::month( $e['start_month'] ) ) : 'Disdetto (ultimo mese dovuto: ' . esc_html( Ui::month( $e['end_month'] ) ) . ')' ) . '</p>';
			echo wp_kses( Ui::months_table( $s['summary'] ), Html::allowed() );
			echo '</details>';
		}
		echo '</div>';
	}

	private static function panel_bookings( array $p ): void {
		$rows = Plugin::activities()->bookings_for_person( (int) $p['id'] );
		if ( ! $rows ) {
			return;
		}
		echo '<div class="asem-card"><h2>Eventi e prenotazioni</h2><table class="widefat striped"><thead><tr><th>Data</th><th>Evento</th><th>Contributo</th><th>Stato</th></tr></thead><tbody>';
		foreach ( $rows as $b ) {
			echo wp_kses( '<tr><td>' . Ui::date( $b['session_date'] ) . ( $b['start_time'] ? ' ' . esc_html( $b['start_time'] ) : '' ) . '</td>'
				. '<td><a href="' . esc_url( Ui::url( 'asem-activity', array( 'id' => $b['activity_id'] ) ) ) . '">' . esc_html( $b['activity_name'] ) . '</a></td>'
				. '<td>' . esc_html( Money::format( (int) $b['fee_due_cents'] ) ) . '</td><td>' . ( $b['active'] ? Ui::booking_state( $b ) : '<span class="asem-warn">annullata</span>' ) . '</td></tr>', Html::allowed() );
		}
		echo '</tbody></table></div>';
	}

	private static function panel_payments( array $p ): void {
		$rows = array_slice( Plugin::ledger()->rows_of_person( (int) $p['id'] ), 0, 15 );
		if ( ! $rows ) {
			return;
		}
		echo '<div class="asem-card"><h2>Ultimi movimenti</h2><table class="widefat striped"><tbody>';
		foreach ( $rows as $r ) {
			echo wp_kses( '<tr><td>' . Ui::date( $r['tx_date'] ) . '</td><td>' . esc_html( $r['category_name'] . ( $r['activity_name'] ? ' · ' . $r['activity_name'] : '' ) ) . '</td><td>' . esc_html( Money::format( (int) $r['amount_cents'] ) ) . '</td></tr>', Html::allowed() );
		}
		echo '</tbody></table></div>';
	}
}
