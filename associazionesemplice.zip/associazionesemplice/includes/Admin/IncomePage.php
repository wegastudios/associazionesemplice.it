<?php
namespace AssociazioneSemplice\Admin;

use AssociazioneSemplice\Labels;
use AssociazioneSemplice\MemberType;
use AssociazioneSemplice\Plugin;
use AssociazioneSemplice\Settings;
use AssociazioneSemplice\Html;

defined( 'ABSPATH' ) || exit;

/**
 * Incasso multi-voce (es. quota associativa + mensilità del corso) con calcolo del resto in contanti.
 * La parte dinamica è in assets/admin.js (blocco "asem-income").
 */
final class IncomePage {

	public static function register_ajax(): void {
		add_action( 'wp_ajax_asem_person_context', array( __CLASS__, 'ajax_context' ) );
		add_action( 'wp_ajax_asem_quick_person', array( __CLASS__, 'ajax_new_person' ) );
	}

	/** Nuova persona creata dal modulo di incasso senza lasciare la pagina: nome, cognome e, se servono, email e cellulare. */
	public static function ajax_new_person(): void {
		check_ajax_referer( 'asem_income', 'nonce' );
		if ( ! current_user_can( Plugin::CAP_OPS ) ) {
			wp_send_json_error( 'Non hai il permesso per questa operazione: chiedilo a un amministratore.', 403 );
		}
		$in   = \AssociazioneSemplice\Plugin::post_data(); // phpcs:ignore WordPress.Security.NonceVerification
		$type = 'guest' === (string) ( $in['type'] ?? '' ) ? MemberType::GUEST : MemberType::ORDINARY;
		try {
			$id = Plugin::people()->create(
				array(
					'type'       => $type,
					'first_name' => sanitize_text_field( (string) ( $in['first_name'] ?? '' ) ),
					'last_name'  => sanitize_text_field( (string) ( $in['last_name'] ?? '' ) ),
					'email'      => sanitize_email( (string) ( $in['email'] ?? '' ) ),
					'phone'      => sanitize_text_field( (string) ( $in['phone'] ?? '' ) ),
				)
			);
		} catch ( \InvalidArgumentException $e ) {
			wp_send_json_error( $e->getMessage(), 400 );
		}
		$p = Plugin::people()->get( $id );
		wp_send_json_success( array( 'id' => $id, 'label' => $p ? Ui::person_label( $p ) : '' ) );
	}

	/** Contesto di una persona per l'incasso: tessera, attività a cui è iscritta e primo mese da pagare. */
	public static function ajax_context(): void {
		check_ajax_referer( 'asem_income', 'nonce' );
		if ( ! current_user_can( Plugin::CAP_OPS ) ) {
			wp_send_json_error( 'Non hai il permesso per questa operazione: chiedilo a un amministratore.', 403 );
		}
		$person = Plugin::people()->get( isset( $_POST['person_id'] ) ? absint( $_POST['person_id'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		$date   = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date, $dm ) || ! checkdate( (int) $dm[2], (int) $dm[3], (int) $dm[1] ) ) {
			$date = current_time( 'Y-m-d' ); // data mancante o non valida: oggi
		}
		if ( ! $person ) {
			wp_send_json_success( array( 'person' => null ) );
		}
		$sy    = Settings::social_year( $date )->label();
		$until = ! MemberType::is_member( $person['type'] ) ? null : Plugin::people()->active_until( (int) $person['id'], $date );
		$acts  = array();
		foreach ( Plugin::activities()->active_activity_ids( (int) $person['id'] ) as $aid ) {
			$a = Plugin::activities()->get( $aid );
			if ( $a && $a['social_year'] === $sy ) {
				$next   = Plugin::activities()->first_unpaid_month( $aid, (int) $person['id'] );
				$acts[] = array( 'id' => (int) $a['id'], 'name' => $a['name'], 'fee' => Plugin::activities()->fee_for( $a, $person['type'] ), 'month' => $next ?: substr( $date, 0, 7 ) );
			}
		}
		// Eventi a cui è prenotata e il cui contributo non è ancora stato pagato
		$bookings = array();
		foreach ( Plugin::activities()->unpaid_bookings_for_person( (int) $person['id'] ) as $b ) {
			$bookings[] = array(
				'session_id'  => (int) $b['session_id'],
				'activity_id' => (int) $b['activity_id'],
				'label'       => $b['activity_name'] . ' · ' . ( new \DateTimeImmutable( $b['session_date'] ) )->format( 'd/m/Y' ),
				'amount'      => (int) $b['remaining'],
			);
		}
		// Tutto ciò che la persona deve ancora versare: mensilità dei corsi (con l'importo mancante) e contributi degli eventi
		$dues = array();
		foreach ( Plugin::activities()->status_for_person( (int) $person['id'] ) as $st ) {
			foreach ( $st['summary']['unpaid_months'] as $m ) {
				if ( (int) $m['missing'] > 0 ) {
					$dues[] = array( 'activity_id' => (int) $st['enrollment']['activity_id'], 'name' => $st['activity']['name'], 'month' => $m['month'], 'amount' => (int) $m['missing'] );
				}
			}
		}
		$m_plan    = Plugin::people()->membership_plan( (int) $person['id'], $date );
		$m_missing = Plugin::people()->membership_missing( $person, $m_plan['year'] );
		$m_paid    = $m_missing > 0 ? Plugin::people()->membership_paid( (int) $person['id'], $m_plan['year'] ) : 0;
		wp_send_json_success(
			array(
				'person'           => array( 'id' => (int) $person['id'], 'type' => $person['type'], 'type_label' => \AssociazioneSemplice\Levels::label( $person ) ),
				'is_guest'         => MemberType::GUEST === $person['type'],
				'is_member'        => MemberType::is_member( $person['type'] ),
				'is_founder'       =>MemberType::is_auto_renewed( $person['type'] ),
				'active_until'     => $until,
				'needs_membership' => in_array( $person['type'], array( MemberType::ORDINARY, MemberType::VOLUNTEER ), true ) && ( ! $until || $until < $date ),
				'social_year'      => $sy,
				'activities'       => $acts,
				'bookings'         => $bookings,
				'dues'             => $dues,
				'membership'       => $m_plan,
				'membership_has'   => Plugin::people()->has_membership( (int) $person['id'], $m_plan['year'] ),
				'membership_until' => \AssociazioneSemplice\MembershipRules::from_label( $m_plan['year'], Settings::membership_start_month() )->end()->format( 'd/m/Y' ),
				'suspended'        => Plugin::people()->is_suspended( (int) $person['id'] ),
				'membership_fee'   => $m_missing > 0 ? $m_missing : \AssociazioneSemplice\Levels::fee_for( $person ), // a rate: si precompila il residuo
				'membership_paid'  => $m_paid,
				'membership_missing' => $m_missing,
			)
		);
	}

	public static function render(): void {
		$ledger   = Plugin::ledger();
		$accounts = $ledger->accounts();
		$cats     = array();
		foreach ( $ledger->categories() as $c ) {
			if ( Labels::category_kinds()[ $c['kind'] ][1] && 'adjustment' !== $c['kind'] ) {
				$cats[] = array( 'id' => (int) $c['id'], 'name' => $c['name'], 'kind' => $c['kind'] );
			}
		}
		$today = current_time( 'Y-m-d' );
		$sy    = Settings::social_year( $today );
		$acts  = array();
		foreach ( array_filter( Plugin::activities()->for_year( $sy->label() ), function ( $x ) {
			return 'course' === $x['kind'];
		} ) as $a ) {
			$acts[] = array( 'id' => (int) $a['id'], 'name' => $a['name'], 'fee' => (int) $a['fee_cents'] );
		}
		$default_account = $ledger->default_account_for( 'cash' );
		$account_types = array();
		foreach ( $accounts as $a ) {
			$account_types[ (int) $a['id'] ] = $a['type'];
		}
		$data = array(
			'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'asem_income' ),
			'categories'    => $cats,
			'activities'    => $acts,
			'membershipFee' => (int) Settings::get( 'membership_fee_cents' ),
			'socialYear'    => Settings::membership_year( $today )->label(),
			'nextYear'      => Settings::membership_year( $today )->next()->label(),
			'yearEnd'       => Settings::membership_year( $today )->end()->format( 'Y-m-d' ),
			'yearEndText'   => Settings::membership_year( $today )->end()->format( 'd/m/Y' ),
			'autofill'      => 1 === Ui::get_int( 'due' ),
			'accountTypes'  => $account_types,
			'guests'        => Settings::guests_enabled() ? 1 : 0,
			// frasi con variabili che admin.js compone: tradotte qui (modello con {anno}), perché lo script non passa dalla sostituzione dei testi
			'txt'           => array(
				'dup_year' => \AssociazioneSemplice\Texts::t( '⚠ il socio ha già la tessera {anno}: togli questa voce per salvare l\'incasso' ),
				'dup'      => \AssociazioneSemplice\Texts::t( '⚠ il socio ha già la tessera: togli questa voce per salvare l\'incasso' ),
			),
		);

		Ui::header( 'Nuovo incasso' );
		wp_print_inline_script_tag( (string) wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP ), array( 'type' => 'application/json', 'id' => 'asem-income-data' ) );
		Ui::form_open( 'asem_save_income', Ui::url( 'asem-income' ), false, 'asem-income' );
		echo '<h2 class="asem-form-section">Chi paga e dove</h2>';
		echo '<table class="form-table asem-form"><tbody>';
		echo '<tr><th>Data</th><td><input type="date" name="date" id="asem-date" value="' . esc_attr( $today ) . '" required></td></tr>';
		echo '<tr><th>Conto</th><td>';
		$acc_map = array();
		foreach ( $accounts as $a ) {
			$acc_map[ $a['id'] ] = $a['name'];
		}
		echo wp_kses( '<select name="account_id" id="asem-account">' . Ui::options( $acc_map, $default_account ? $default_account['id'] : null ) . '</select></td></tr>', Html::allowed() );
		echo wp_kses( '<tr><th>Da chi</th><td>' . Ui::person_select( 'person_id', Plugin::people()->search_light(), Ui::get_int( 'person_id' ) ?: null, '— nessuno / anonimo —', 'asem-person-select' )
			. ' <button type="button" class="button" id="asem-new-person">+ nuovo socio</button>'
			. '<div id="asem-person-info" class="asem-info"></div></td></tr>', Html::allowed() );
		echo '</tbody></table>';

		echo '<h2 class="asem-form-section">Voci</h2><div id="asem-lines"></div>';
		echo '<p class="asem-addbar">'
			. '<button type="button" class="button" id="asem-add-membership">+ Quota associativa</button> '
			. '<select id="asem-add-activity-select"><option value="">+ Mensilità corso…</option></select> '
			. '<select id="asem-add-booking-select"><option value="">+ Contributo evento…</option></select> '
			. '<select id="asem-add-other-select"><option value="">+ Altra voce…</option></select></p>';

		echo '<p class="asem-total">Totale: <strong id="asem-total">0,00 €</strong></p>';
		echo '<div id="asem-cash" class="asem-card"><h3>Contanti</h3>'
			. '<p><label>Contanti ricevuti <input type="text" id="asem-tendered" inputmode="decimal" placeholder="importo esatto"> €</label></p>'
			. '<p id="asem-quick"></p><p id="asem-change" class="asem-change"></p></div>';
		$vat = Ui::vat_row( null, \AssociazioneSemplice\Fiscal::default_mode(), 'Gli importi', true );
		if ( '' !== $vat ) {
			echo wp_kses( '<table class="form-table"><tbody>' . $vat . '</tbody></table>', Html::allowed() );
		}
		echo '<p><label>N. ricevuta (facoltativo) <input type="text" name="document_ref" maxlength="80"></label></p>';
		submit_button( 'Registra incasso' );
		Ui::form_close();
		Ui::footer();
	}
}
