<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/** Regole di validazione pure (nessun accesso al database): testabili senza WordPress. */
final class Rules {

	/**
	 * @param array      $d    type, first_name, last_name, email, card_number, host_person_id
	 * @param array|null $host persona ospitante (con almeno 'type'), solo per gli ospiti
	 * @return string[] messaggi di errore (vuoto = valido)
	 */
	public static function validate_person( array $d, ?array $host = null, array $relax = array() ): array {
		$errors = array();
		$type   = (string) ( $d['type'] ?? '' );
		if ( ! MemberType::is_valid( $type ) ) {
			return array( 'Tipo di persona non valido.' );
		}
		if ( RuntsRules::ENTITY === RuntsRules::kind( $d['subject_kind'] ?? '' ) ) { // un socio che è un ente: la denominazione sta nel campo «cognome», il nome non serve
			if ( ! MemberType::is_member( $type ) ) {
				$errors[] = 'Solo un socio può essere un ente.';
			}
			if ( '' === trim( (string) ( $d['last_name'] ?? '' ) ) ) {
				$errors[] = 'La denominazione dell\'ente è obbligatoria.';
			}
			$cf_error = RuntsRules::entity_tax_code_error( (string) ( $d['tax_code'] ?? '' ) );
			if ( '' !== $cf_error ) {
				$errors[] = $cf_error;
			}
		} elseif ( '' === trim( (string) ( $d['first_name'] ?? '' ) ) || '' === trim( (string) ( $d['last_name'] ?? '' ) ) ) {
			$errors[] = 'Nome e cognome sono obbligatori.';
		}

		$email = trim( (string) ( $d['email'] ?? '' ) );
		if ( '' !== $email && ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			$errors[] = 'L\'email non è valida.';
		}
		// L'email non è obbligatoria: un socio senza email (e magari senza cellulare) si registra lo stesso e si attiva dopo con un link.
		if ( '' !== trim( (string) ( $d['phone'] ?? '' ) ) && ! Phone::is_valid( (string) $d['phone'] ) ) {
			$errors[] = 'Il numero di cellulare non è valido.';
		}

		$joined = trim( (string) ( $d['joined_on'] ?? '' ) );
		if ( '' !== $joined ) {
			$dt = \DateTime::createFromFormat( 'Y-m-d', $joined );
			if ( ! $dt || $dt->format( 'Y-m-d' ) !== $joined ) {
				$errors[] = 'La data di ingresso non è valida.';
			}
		}
		$birth = trim( (string) ( $d['birth_date'] ?? '' ) );
		if ( '' !== $birth ) {
			if ( ! Age::is_valid_date( $birth ) ) {
				$errors[] = 'La data di nascita non è valida.';
			} elseif ( $birth > gmdate( 'Y-m-d' ) ) {
				$errors[] = 'La data di nascita è nel futuro.';
			}
		}
		foreach ( array( 'first_name' => array( 'Il nome', 120 ), 'last_name' => array( 'Il cognome', 120 ), 'email' => array( 'L\'email', 190 ), 'phone' => array( 'Il cellulare', 60 ), 'tax_code' => array( 'Il codice fiscale', 32 ), 'address' => array( 'L\'indirizzo', 190 ), 'zip' => array( 'Il CAP', 12 ), 'city' => array( 'Il comune', 100 ), 'province' => array( 'La provincia', 5 ) ) as $field => $lim ) {
			if ( mb_strlen( trim( (string) ( $d[ $field ] ?? '' ) ), 'UTF-8' ) > $lim[1] ) {
				$errors[] = $lim[0] . ' è troppo lungo (al massimo ' . $lim[1] . ' caratteri).';
			}
		}

		$card = trim( (string) ( $d['card_number'] ?? '' ) );
		if ( strlen( $card ) > 40 ) {
			$errors[] = 'Il numero di tessera è troppo lungo (massimo 40 caratteri).';
		}
		if ( MemberType::GUEST === $type && '' !== $card ) {
			$errors[] = 'Gli ospiti non hanno il numero di tessera.';
		}
		if ( MemberType::GUEST === $type && empty( $relax['phone'] ) && ! Phone::is_valid( (string) ( $d['phone'] ?? '' ) ) ) {
			$errors[] = 'Il numero di cellulare è obbligatorio per gli ospiti (serve a riconoscerli ed evitare doppioni, e a contattarli su WhatsApp).';
		}

		if ( MemberType::requires_host( $type ) ) {
			if ( empty( $d['host_person_id'] ) ) {
				if ( empty( $relax['host'] ) ) {
					$errors[] = 'Un ospite deve essere collegato al socio che lo ospita.';
				}
			} elseif ( null === $host || ! MemberType::is_member( (string) ( $host['type'] ?? '' ) ) ) {
				$errors[] = 'Il socio ospitante non è valido (deve essere un socio, non un altro ospite).';
			}
		} elseif ( ! empty( $d['host_person_id'] ) ) {
			$errors[] = 'Solo gli ospiti hanno un socio ospitante.';
		}
		return $errors;
	}

	/**
	 * @param array      $d          name, kind, fee_cents, guest_fee_cents (null = come i soci)
	 * @param array|null $instructor persona referente (con 'type'), se indicata
	 * @return string[]
	 */
	public static function validate_activity( array $d, ?array $instructor = null ): array {
		$errors = array();
		if ( '' === trim( (string) ( $d['name'] ?? '' ) ) ) {
			$errors[] = 'Il nome dell\'attività è obbligatorio.';
		}
		if ( isset( $d['kind'] ) && ! ActivityKind::is_valid( (string) $d['kind'] ) ) {
			$errors[] = 'Tipo di attività non valido.';
		}
		if ( (int) ( $d['fee_cents'] ?? 0 ) < 0 ) {
			$errors[] = 'Il contributo non può essere negativo.';
		}
		if ( isset( $d['guest_fee_cents'] ) && (int) $d['guest_fee_cents'] < 0 ) {
			$errors[] = 'Il contributo per gli ospiti non può essere negativo.';
		}
		if ( ! empty( $d['instructor_person_id'] ) ) {
			if ( null === $instructor || ! MemberType::can_teach( (string) ( $instructor['type'] ?? '' ) ) ) {
				$errors[] = 'Solo soci e volontari possono essere referenti di un\'attività.';
			}
		}
		return $errors;
	}

	/**
	 * Una data (sessione) di un evento.
	 *
	 * @param array $s session_date (Y-m-d), start_time (HH:MM, facoltativa), capacity (>= 1, facoltativa)
	 * @return string[]
	 */
	public static function validate_session( array $s ): array {
		$errors = array();
		$date   = (string) ( $s['session_date'] ?? '' );
		$dt     = \DateTime::createFromFormat( 'Y-m-d', $date );
		if ( ! $dt || $dt->format( 'Y-m-d' ) !== $date ) {
			$errors[] = 'La data dell\'evento non è valida.';
		}
		$time = (string) ( $s['start_time'] ?? '' );
		if ( '' !== $time && ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $time ) ) {
			$errors[] = 'L\'orario non è valido (usa il formato HH:MM).';
		}
		$end = (string) ( $s['end_time'] ?? '' );
		if ( '' !== $end && ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $end ) ) {
			$errors[] = 'L\'orario di fine non è valido (usa il formato HH:MM).';
		} elseif ( '' !== $end && '' !== $time && $end <= $time ) {
			$errors[] = 'L\'orario di fine deve essere dopo quello di inizio.';
		}
		if ( isset( $s['capacity'] ) && '' !== $s['capacity'] && (int) $s['capacity'] < 1 ) {
			$errors[] = 'I posti disponibili devono essere almeno 1 (lascia vuoto per nessun limite).';
		}
		return $errors;
	}
}
