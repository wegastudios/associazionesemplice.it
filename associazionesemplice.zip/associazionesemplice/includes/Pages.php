<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/** Pagine del sito che servono al plugin (area soci, volontari, attività…): si creano con gli shortcode già inseriti. */
final class Pages {

	const OPTION = 'asem_pages';

	/** Area di ogni pagina (vedi Areas). */
	const AREA = array(
		'area' => 'soci', 'calendario' => 'soci', 'volontari' => 'eventi', 'ingressi' => 'eventi', 'attivita' => 'pubblico', 'eventi' => 'pubblico',
		'bonifico' => 'pubblico', 'privacy' => 'pubblico', 'adesione' => 'pubblico', 'segreteria' => 'segreteria', 'tesoriere' => 'tesoriere',
	);

	/** @return array<string,array> area => [chiave pagina => definizione], nell'ordine delle aree */
	public static function by_area(): array {
		$out = array();
		$areas = (array) apply_filters( 'asem_page_areas', self::AREA );
		foreach ( array_keys( Areas::groups() ) as $area ) {
			foreach ( self::defs() as $key => $d ) {
				if ( ( $areas[ $key ] ?? '' ) === $area ) {
					$out[ $area ][ $key ] = $d;
				}
			}
		}
		return $out;
	}

	/** Chiave => titolo, shortcode, accesso riservato (meta della pagina), descrizione, predefinita. */
	public static function defs(): array {
		$defs = array(
			'area'      => array( 'title' => 'Area soci', 'content' => '[associazionesemplice_area_soci]', 'access' => '', 'hint' => 'Tessera, attività, pagamenti, ospiti e profilo dei soci: è la pagina principale.', 'default' => true ),
			'volontari' => array( 'title' => 'Area volontari', 'content' => '[associazionesemplice_area_volontari]', 'access' => 'volunteers', 'hint' => 'Le attività di cui i volontari sono referenti (visibile solo a loro).', 'default' => true ),
			'attivita'  => array( 'title' => 'Attività ed eventi', 'content' => '[associazionesemplice_attivita]', 'access' => '', 'hint' => 'L\'elenco pubblico di corsi ed eventi, con la prenotazione.', 'default' => true ),
			'eventi'    => array( 'title' => 'Eventi', 'content' => '[associazionesemplice_eventi]', 'access' => '', 'hint' => 'Gli eventi pubblicati sul sito, a schede per mese (con la scelta del calendario mensile e delle categorie).', 'default' => false ),
			'calendario' => array( 'title' => 'Calendario', 'content' => '[associazionesemplice_calendario]', 'access' => 'members', 'hint' => 'Il calendario di corsi ed eventi per i soli soci.', 'default' => false ),
			'privacy'   => array( 'title' => 'Informativa privacy', 'content' => '[associazionesemplice_privacy]', 'access' => '', 'hint' => 'L\'informativa sul trattamento dei dati personali, compilata con i dati dell\'ente (si aggiorna da sola).', 'default' => true ),
			'bonifico'  => array( 'title' => 'Dona con bonifico', 'content' => '[associazionesemplice_bonifico]', 'access' => '', 'hint' => 'Le coordinate bancarie per chi vuole sostenere l\'associazione (servono il bonifico attivo e almeno un IBAN).', 'default' => false ),
			'adesione'  => array( 'title' => 'Diventa socio', 'content' => '[associazionesemplice_adesione]', 'access' => '', 'hint' => 'La domanda di adesione online per chi non è ancora socio: la segreteria la approva dalla Bacheca.', 'default' => false ),
			'segreteria' => array( 'title' => 'Area segreteria', 'content' => '[associazionesemplice_segreteria]', 'access' => '', 'hint' => 'Il punto d\'ingresso di chi lavora con la segreteria (anche presidente e vicepresidente): richieste di accesso e link alla gestione.', 'default' => false ),
			'tesoriere' => array( 'title' => 'Area tesoriere', 'content' => '[associazionesemplice_tesoriere]', 'access' => '', 'hint' => 'Per il tesoriere: incassi, spese con foto dello scontrino, nuove iscrizioni e vendita degli eventi.', 'default' => false ),
			'ingressi'  => array( 'title' => 'Ingressi agli eventi', 'content' => '[associazionesemplice_ingressi]', 'access' => '', 'hint' => 'Per responsabili e staff: prenotati, QR e registrazione degli ingressi.', 'default' => false ),
		);
		return (array) apply_filters( 'asem_page_defs', $defs ); // un'estensione aggiunge le sue pagine
	}

	/** @return array<string,int> pagine già create (chiave => id), solo quelle ancora esistenti */
	public static function existing(): array {
		$out = array();
		foreach ( (array) get_option( self::OPTION, array() ) as $k => $id ) {
			if ( (int) $id && get_post_status( (int) $id ) && 'trash' !== get_post_status( (int) $id ) ) {
				$out[ (string) $k ] = (int) $id;
			}
		}
		return $out;
	}

	/** La pagina più vecchia (non nel cestino) il cui contenuto è esattamente lo shortcode indicato, o 0. */
	private static function find_by_content( string $content ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status IN ('publish','draft','pending','private') AND post_content = %s ORDER BY ID ASC LIMIT 1", $content ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Crea le pagine richieste che non esistono già.
	 *
	 * @param string[] $keys chiavi di defs()
	 * @return string[] titoli delle pagine create
	 */
	public static function create( array $keys ): array {
		$defs  = self::defs();
		$saved = (array) get_option( self::OPTION, array() );
		$have  = self::existing();
		$made  = array();
		foreach ( $keys as $key ) {
			if ( ! isset( $defs[ $key ] ) || isset( $have[ $key ] ) ) {
				continue;
			}
			$d      = $defs[ $key ];
			$reused = self::find_by_content( (string) $d['content'] ); // dopo un ripristino di fabbrica le pagine create dalla procedura restano: si riprendono, non si duplicano
			if ( $reused ) {
				$saved[ $key ] = $reused;
				if ( '' !== $d['access'] && '' === (string) get_post_meta( $reused, '_asem_access', true ) ) {
					update_post_meta( $reused, '_asem_access', $d['access'] );
				}
				if ( 'area' === $key ) {
					self::add_to_menu( $reused );
				}
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $d['title'], 'post_content' => $d['content'] ) );
			if ( $id && ! is_wp_error( $id ) ) {
				$saved[ $key ] = (int) $id;
				$made[]        = $d['title'];
				if ( '' !== $d['access'] ) {
					update_post_meta( $id, '_asem_access', $d['access'] );
				}
			}
		}
		update_option( self::OPTION, $saved );
		$have = self::existing();
		if ( ! empty( $have['area'] ) && 0 === (int) Settings::get( 'member_area_page_id' ) ) {
			Settings::update( array( 'member_area_page_id' => (int) $have['area'] ) );
		}
		if ( ! empty( $have['privacy'] ) && '' === (string) Settings::get( 'privacy_url' ) ) {
			Settings::update( array( 'privacy_url' => (string) get_permalink( (int) $have['privacy'] ) ) ); // l'informativa creata diventa quella richiesta a chi attiva l'accesso
		}
		if ( in_array( 'Area soci', $made, true ) ) {
			self::add_to_menu( (int) $have['area'] ); // la voce «Area soci» compare nel menu del sito
		}
		return $made;
	}

	/**
	 * Aggiunge al menu di navigazione del sito la voce «Area soci» che porta all'area soci (con le funzioni nella versione per il sito,
	 * non quella di amministrazione). Sceglie il menu della posizione principale; non duplica la voce.
	 *
	 * @return bool true se la voce c'è (già presente o aggiunta), false se il sito non ha un menu a cui aggiungerla
	 */
	public static function add_to_menu( int $page_id ): bool {
		if ( $page_id <= 0 || ! function_exists( 'wp_update_nav_menu_item' ) ) {
			return false;
		}
		$menu_id = 0;
		$locs    = (array) get_nav_menu_locations();
		foreach ( array( 'primary', 'main', 'menu-1', 'header', 'main-menu' ) as $loc ) {
			if ( ! empty( $locs[ $loc ] ) ) {
				$menu_id = (int) $locs[ $loc ];
				break;
			}
		}
		if ( ! $menu_id && $locs ) {
			$menu_id = (int) reset( $locs );
		}
		if ( ! $menu_id ) {
			$menus   = wp_get_nav_menus();
			$menu_id = $menus ? (int) $menus[0]->term_id : 0;
		}
		if ( ! $menu_id ) {
			return false;
		}
		$menus = wp_get_nav_menus();
		foreach ( (array) $menus as $m ) { // già in un menu qualsiasi (anche quello per il telefono): non si aggiunge una seconda voce
			foreach ( (array) wp_get_nav_menu_items( (int) $m->term_id ) as $item ) {
				if ( (int) $item->object_id === $page_id && 'page' === $item->object ) {
					return true;
				}
			}
		}
		$id = wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'     => 'Area soci',
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $page_id,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			)
		);
		return ! is_wp_error( $id );
	}
}
