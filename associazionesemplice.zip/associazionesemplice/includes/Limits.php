<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/**
 * Limiti, gruppi e comportamenti automatici del plugin.
 *
 * Ogni voce ha un valore predefinito (scelto per essere prudente su un hosting condiviso), un minimo e un massimo di sicurezza e una
 * spiegazione di cosa fa e dei rischi di alzarlo o abbassarlo. I valori si cambiano da Impostazioni → Tecniche → Limiti e soglie.
 */
final class Limits {

	const GROUPS = array(
		'comunicazioni' => 'Comunicazioni, avvisi e notifiche',
		'accesso'       => 'Accessi e sicurezza',
		'pagamenti'     => 'Pagamenti online',
		'dati'          => 'Importazioni, allegati e copie di sicurezza',
		'soci'          => 'Soci e scadenze',
		'bilancio'      => 'Bilancio, avvisi e fondi',
	);

	/** @var array|null */
	private static $defs = null;

	/**
	 * Definizioni: chiave => group, label, unit, default, min, max, what (a cosa serve), raise (rischi se lo alzi), lower (rischi se lo abbassi).
	 * Per le scelte sì/no: unit = 'flag', valori 0 e 1.
	 */
	public static function defs(): array {
		if ( null !== self::$defs ) {
			return self::$defs;
		}
		$d = array();
		$add = function ( string $key, string $group, string $label, string $unit, int $default, int $min, int $max, string $what, string $raise, string $lower ) use ( &$d ) {
			$d[ $key ] = array( 'group' => $group, 'label' => $label, 'unit' => $unit, 'default' => $default, 'min' => $min, 'max' => $max, 'what' => $what, 'raise' => $raise, 'lower' => $lower );
		};

		// ---------- Comunicazioni ----------
		$add(
			'broadcast_per_day', 'comunicazioni', 'Comunicazioni a gruppi nelle 24 ore', 'comunicazioni', 20, 1, 500,
			'Quante comunicazioni email a gruppi di persone si possono creare in 24 ore. Protegge i soci da un uso eccessivo o da un errore ripetuto e il dominio del sito dal rischio di essere segnalato come spam.',
			'Con un servizio di invio dedicato (SMTP professionale, Brevo, Amazon SES e simili) si può alzare senza problemi. Con la posta del normale hosting un valore alto può superare i limiti orari del fornitore: le email vengono rimandate o respinte e, nei casi peggiori, il dominio finisce in una lista nera.',
			'Rende più difficile sbagliare, ma può impedire di mandare comunicazioni urgenti ravvicinate (ad esempio un annullamento e la sua correzione).'
		);
		$add(
			'broadcast_batch', 'comunicazioni', 'Email per ogni gruppo di invio', 'email', 25, 1, 500,
			'Le comunicazioni partono a gruppi: il primo subito, gli altri in background. Questo numero è la grandezza di ogni gruppo.',
			'Gruppi grandi concludono prima, ma ogni passaggio resta in attesa più a lungo: se il server o il servizio di posta sono lenti l\'invio può interrompersi per tempo scaduto. Con un servizio di invio veloce si possono usare 100 o più.',
			'Gruppi piccoli sono molto prudenti con i limiti orari dell\'hosting, ma una comunicazione a molti soci impiega più tempo a completarsi.'
		);
		$add(
			'notice_per_day', 'comunicazioni', 'Avvisi per attività nelle 24 ore', 'avvisi', 5, 1, 100,
			'Quanti avvisi ufficiali può inviare, agli iscritti di una stessa attività, chi ne è referente o la gestisce.',
			'Utile se un corso ha molte comunicazioni operative. Un valore alto espone gli iscritti a messaggi ripetuti e permette a un account compromesso di inviarne molti prima di essere fermato.',
			'Riduce il rumore e l\'impatto di un uso scorretto, ma può impedire di correggere in tempo un avviso sbagliato.'
		);
		$add(
			'notice_board_days', 'comunicazioni', 'Durata degli avvisi nella bacheca', 'giorni', 45, 7, 365,
			'Per quanto tempo un avviso resta visibile nella bacheca dell\'area riservata.',
			'Gli avvisi vecchi restano a lungo e possono confondere (orari cambiati, eventi già passati).',
			'Chi non entra spesso nell\'area riservata potrebbe non vedere gli avvisi.'
		);
		$add(
			'notice_links', 'comunicazioni', 'Link e coordinate bancarie negli avvisi dei volontari', 'flag', 0, 0, 1,
			'Per impostazione predefinita gli avvisi inviati dai volontari non possono contenere indirizzi web né IBAN: è il modo più comune per far arrivare ai soci un falso pagamento usando l\'account di un volontario compromesso. Gli amministratori e la segreteria non hanno questo limite.',
			'Consentendoli, un account compromesso potrebbe indirizzare i pagamenti dei soci su un conto che non è quello dell\'associazione.',
			'Nessun rischio aggiuntivo: i volontari chiederanno alla segreteria di condividere link e coordinate.'
		);
		$add(
			'push_time_budget', 'comunicazioni', 'Tempo massimo per inviare le notifiche push', 'secondi', 8, 2, 60,
			'Le notifiche ai dispositivi partono insieme alle email: se il servizio di notifica è lento, l\'invio si ferma dopo questo tempo e chi resta indietro riceve comunque l\'email.',
			'Più notifiche consegnate in una volta, ma la pagina che invia può impiegare molto di più: con un tempo alto aumenta il rischio di «tempo scaduto» del server.',
			'Il sito resta sempre rapido, ma nelle comunicazioni a molti dispositivi alcune notifiche potrebbero non partire (resta l\'email).'
		);
		$add(
			'push_max_devices', 'comunicazioni', 'Dispositivi con le notifiche per ogni utente', 'dispositivi', 10, 1, 50,
			'Quanti telefoni, tablet o computer di una stessa persona possono ricevere le notifiche.',
			'Un account compromesso o un programma automatico potrebbe registrare moltissimi dispositivi e rallentare gli invii.',
			'Chi usa più dispositivi non riuscirà ad attivarli tutti.'
		);


		$add(
			'donate_max_campaigns', 'comunicazioni', 'Raccolte di donazioni, al massimo', 'raccolte', 20, 1, 100,
			'Quante raccolte di donazioni (ciascuna con il suo shortcode) si possono creare.',
			'Troppe raccolte rendono difficile ritrovare quella giusta e appesantiscono l\'elenco; non c\'è altro rischio.',
			'Se ne hai già più del limite restano tutte, ma non puoi crearne altre finché non ne elimini.'
		);
		// ---------- Accessi e sicurezza ----------
		$add(
			'trust_proxy_headers', 'accesso', 'Leggere l\'indirizzo del visitatore dal proxy (Cloudflare, bilanciatore)', 'flag', 0, 0, 1,
			'Per i limiti «per connessione» (primo accesso, attivazione dell\'accesso) il sito conta i tentativi per indirizzo. Dietro un proxy tutti i visitatori hanno lo stesso indirizzo e uno solo può bloccare gli altri: con questa scelta si legge l\'indirizzo inoltrato dal proxy.',
			'Accendilo solo se il sito è davvero dietro un proxy che aggiunge l\'indirizzo del visitatore: altrimenti chiunque può scrivere un indirizzo finto e aggirare i limiti.',
			'Spento (consigliato se non usi un proxy): il limite conta l\'indirizzo della connessione. Dietro un proxy un solo visitatore può esaurirlo per tutti.'
		);
		$add(
			'access_requests_unknown_max', 'accesso', 'Richieste di accesso da sconosciuti conservate, al massimo', 'richieste', 50, 5, 500,
			'Quante richieste del «Primo accesso» di persone non riconosciute si tengono in coda. Le altre (cambio email, accessi da controllare) hanno posto a parte e non vengono mai spinte fuori da queste.',
			'Chi vuole riempire la coda di richieste false mette in difficoltà la segreteria, ma non può cancellare le richieste dei soci.',
			'Se ricevi molte richieste vere di non soci, le più vecchie vengono scartate prima che tu le veda.'
		);
		$add(
			'first_access_per_ip', 'accesso', 'Richieste di «Primo accesso» per connessione, in un\'ora', 'richieste', 10, 1, 1000,
			'Quante volte la stessa connessione può usare il modulo di primo accesso. Impedisce di provare a scoprire chi è socio e di riempire di email le caselle dei soci.',
			'Se il sito è dietro un servizio di protezione (CDN, proxy) tutti i visitatori possono apparire con lo stesso indirizzo: in quel caso va alzato. Un valore alto facilita tentativi in massa.',
			'Più protezione, ma può bloccare soci che sbagliano più volte o che usano la stessa rete (una sede, un wifi pubblico).'
		);
		$add(
			'first_access_per_email', 'accesso', 'Email di «Primo accesso» verso lo stesso socio, in un\'ora', 'email', 3, 1, 50,
			'Impedisce di inondare di messaggi la casella di un socio chiedendo di continuo il link per la password.',
			'Con un valore alto chiunque può infastidire un socio con decine di email.',
			'Un valore molto basso può obbligare un socio a ripetere la richiesta più tardi se non trova il primo messaggio.'
		);
		$add(
			'activation_per_ip', 'accesso', 'Tentativi di attivazione dell\'accesso per connessione, in un\'ora', 'tentativi', 15, 3, 1000,
			'Quante volte la stessa connessione può provare a usare un link di attivazione. Rende impraticabile indovinare i dati richiesti (come il codice fiscale).',
			'Un valore alto agevola chi prova a indovinare i dati di un socio con un link ricevuto per errore.',
			'Un valore basso può bloccare chi sbaglia a digitare più volte; il blocco passa da solo dopo un\'ora.'
		);
		$add(
			'activation_days', 'accesso', 'Validità del link di attivazione', 'giorni', 1, 1, 180,
			'Per quanti giorni resta valido (1 = 24 ore) il link di attivazione inviato (ad esempio su WhatsApp) ai soci registrati dalla segreteria.',
			'Un link che resta valido a lungo (anche i 30 giorni di prima) può essere usato da altri se viene inoltrato o se il telefono è condiviso. Per attivare l\'accesso serve comunque il codice fiscale.',
			'Più sicuro, ma la segreteria dovrà rimandare il link ai soci che non lo aprono in tempo: con 24 ore, chi non lo apre entro il giorno dopo ne riceve uno nuovo.'
		);
		$add(
			'apply_per_ip', 'accesso', 'Domande di adesione per connessione, in un\'ora', 'domande', 5, 1, 200,
			'Quante domande di adesione online può inviare la stessa connessione. Impedisce di riempire la segreteria di domande false.',
			'Se il sito è dietro un servizio di protezione (CDN, proxy) tutti i visitatori possono apparire con lo stesso indirizzo: in quel caso va alzato. Un valore alto facilita le domande in massa.',
			'Più protezione, ma una sede con un solo wifi pubblico (ad esempio un open day) può esaurire il limite: alzalo per l\'occasione.'
		);
		$add(
			'applications_max', 'accesso', 'Domande di adesione in attesa, al massimo', 'domande', 200, 10, 5000,
			'Quante domande di adesione possono aspettare insieme una risposta della segreteria. Oltre questo numero le nuove domande non vengono registrate finché non ne approvi o rifiuti qualcuna.',
			'Chi vuole intasare la Bacheca con domande false può farlo più a lungo prima di essere fermato.',
			'Se ricevi molte domande vere e non le lavori in tempo, le nuove vengono scartate: chi le ha inviate non lo sa.'
		);
		$add(
			'profile_required', 'accesso', 'Indirizzo e codice fiscale obbligatori per chi attiva l\'accesso dal sito', 'flag', 1, 0, 1,
			'Chi attiva da solo il proprio accesso (dal link ricevuto o dal «Primo accesso») deve completare il profilo con indirizzo e codice fiscale. Se la segreteria aveva già registrato il codice fiscale, deve coincidere: è un secondo controllo che impedisce di attivare l\'accesso di un altro socio con un link ricevuto per errore. L\'iscrizione fatta dalla segreteria resta snella: questi dati non sono obbligatori.',
			'Se lo disattivi i soci possono attivarsi senza dati: ricevute e attestazioni risultano incomplete e viene meno il controllo del codice fiscale sull\'attivazione.',
			'Mantienilo attivo: è il comportamento consigliato.'
		);
		$add(
			'member_sessions', 'accesso', 'Accesso dei soci indipendente da WordPress', 'flag', 1, 0, 1,
			'I soci entrano con un accesso proprio (email e password; recupero e accesso senza password con un link via email) e non hanno bisogno di un utente WordPress. Spento, i soci tornano a entrare con un utente WordPress come prima.',
			'Acceso, il sito usa un cookie tecnico di sessione («asem_s») e scrive ai soci per mandare il link di accesso. Se la posta del sito non funziona i soci non ricevono il link: provala prima.',
			'Spento: i soci hanno un utente WordPress e un\'unica password sul sito, come nelle versioni precedenti.'
		);
		$add(
			'profile_gate', 'accesso', 'Blocca prenotazioni e pagamenti finché il profilo è incompleto', 'flag', 1, 0, 1,
			'Chi si è attivato dal sito senza completare indirizzo e codice fiscale non può prenotare né pagare online finché non li inserisce dal suo profilo.',
			'Se lo disattivi i soci possono continuare a usare l\'area anche con il profilo incompleto: più comodo, ma i dati restano mancanti.',
			'Mantienilo attivo per avere i dati completi; chi trova il blocco vede un messaggio che spiega cosa fare.'
		);
		$add(
			'access_requests_max', 'accesso', 'Richieste di accesso conservate in coda', 'richieste', 200, 20, 2000,
			'Quante richieste di accesso non riconosciute la segreteria vede in coda; le più vecchie vengono scartate.',
			'Una coda lunga è più difficile da controllare e può riempirsi di richieste false.',
			'Una coda breve può far perdere richieste vere se ne arrivano molte insieme.'
		);

		// ---------- Pagamenti online ----------
		$add(
			'pay_min_cents', 'pagamenti', 'Importo minimo per pagare online', 'centesimi di euro', 50, 50, 10000,
			'Sotto questa somma non si avvia un pagamento online. 50 centesimi è il minimo accettato da Stripe.',
			'Un minimo più alto evita le commissioni su importi piccoli, ma impedisce di pagare online le voci più piccole.',
			'Non si può scendere sotto i 50 centesimi: i gateway rifiuterebbero il pagamento.'
		);
		$add(
			'pay_pending_minutes', 'pagamenti', 'Attesa prima di ricontrollare un pagamento in sospeso', 'minuti', 10, 2, 120,
			'Dopo quanti minuti il sito interroga il gateway sui pagamenti non ancora confermati (oltre al webhook e al ritorno del socio).',
			'Le conferme mancate vengono recuperate più tardi: un socio può restare «in attesa» più a lungo.',
			'Più controlli verso il gateway: aumentano le chiamate e si possono ricontrollare pagamenti che il socio sta ancora completando.'
		);
		$add(
			'pay_expire_days', 'pagamenti', 'Giorni dopo i quali un pagamento mai confermato scade', 'giorni', 3, 1, 30,
			'Un pagamento avviato e mai concluso viene chiuso dopo questo periodo. Se il gateway lo conferma comunque più tardi, viene registrato lo stesso.',
			'L\'elenco dei pagamenti in sospeso resta pieno più a lungo.',
			'Un pagamento lento (bonifico istantaneo o carta in verifica) potrebbe risultare scaduto prima della conferma.'
		);
		$add(
			'pay_open_per_hour', 'pagamenti', 'Pagamenti online avviati da uno stesso utente in un\'ora', 'pagamenti', 10, 1, 100,
			'Impedisce a un utente (o a un programma automatico) di creare migliaia di pagamenti pendenti sul gateway.',
			'Un valore alto permette abusi che riempiono l\'elenco dei pagamenti e consumano chiamate al gateway.',
			'Un socio che ricomincia più volte il pagamento potrebbe dover aspettare.'
		);

		$add(
			'bank_email_per_hour', 'pagamenti', 'Invii delle coordinate bancarie per email, per utente, in un\'ora', 'invii', 3, 1, 20,
			'Quante volte un socio può farsi mandare per email le coordinate del bonifico. Le coordinate vanno sempre e solo all\'indirizzo del socio.',
			'Un valore alto permette di generare molte email con un solo account (spam verso la casella del socio o consumo del servizio di posta).',
			'Un valore basso può costringere a riprovare più tardi chi non ha trovato l\'email: le coordinate restano comunque visibili nell\'area riservata.'
		);

		// ---------- Dati ----------
		$add(
			'import_max_rows', 'dati', 'Righe per tipo in un file di importazione', 'righe', 5000, 100, 50000,
			'Quante righe di soci o di prima nota si possono importare con un solo file.',
			'File molto grandi richiedono molta memoria e tempo: il server può interrompere l\'importazione a metà (la si può annullare in blocco, ma resta il disagio).',
			'Obbliga a dividere i file grandi in più parti.'
		);
		$add(
			'import_max_mb', 'dati', 'Dimensione massima di un file di importazione', 'MB', 20, 1, 100,
			'Peso massimo del file Excel o CSV caricato. Vale anche il limite di caricamento del server, se più basso.',
			'File pesanti possono esaurire la memoria del server.',
			'File con molte righe o immagini incorporate potrebbero essere rifiutati.'
		);
		$add(
			'attach_max_per_tx', 'dati', 'Allegati per ogni movimento', 'allegati', 10, 1, 50,
			'Quanti scontrini e fatture si possono allegare a un movimento.',
			'Spazio sul server e lavoro di controllo che crescono senza motivo.',
			'Più movimenti con lo stesso scontrino da dividere.'
		);
		$add(
			'attach_max_mb', 'dati', 'Peso massimo di un allegato', 'MB', 10, 1, 50,
			'Peso massimo di un singolo scontrino o fattura (le foto dal telefono vengono ridotte prima dell\'invio).',
			'Pesa sullo spazio del server e sulle copie di sicurezza con allegati.',
			'Fatture in PDF molto pesanti potrebbero essere rifiutate.'
		);
		$add(
			'audit_keep_months', 'dati', 'Per quanto tempo si conserva il registro azioni', 'mesi', 18, 6, 120,
			'Dopo questo tempo le righe più vecchie del registro azioni (chi ha fatto cosa) vengono cancellate da sole, ogni giorno.',
			'Si può risalire a più indietro per capire chi ha fatto cosa, ma la tabella cresce e occupa più spazio nel database del sito.',
			'Il database resta più leggero, ma non si potrà più controllare chi ha fatto cosa prima di quel limite.'
		);

		$add(
			'backup_keep', 'dati', 'Copie di sicurezza fatte prima dei ripristini', 'copie', 3, 1, 30,
			'Quante copie del sito, fatte in automatico prima di un ripristino, restano sul server.',
			'Ogni copia contiene tutti i dati del sito (e gli allegati): più copie significano più spazio occupato e più dati personali conservati in un posto solo.',
			'Se si fanno più ripristini ravvicinati, le copie più vecchie vengono eliminate e non si potrà tornare a quello stato.'
		);

		$add(
			'backup_hours', 'dati', 'Per quanto tempo restano le copie fatte prima dei ripristini', 'ore', 24, 1, 168,
			'Dopo questo tempo le copie salvate sul server vengono cancellate da sole.',
			'La copia contiene tutti i dati personali dei soci: tenerla a lungo sul sito prolunga il rischio se qualcuno ne ottenesse l\'accesso.',
			'Passato il tempo non si potrà più tornare indietro dal sito: se vuoi un ricordo più duraturo scarica la copia e conservala tu.'
		);
		// ---------- Soci ----------
		$add(
			'price_lists_max', 'soci', 'Prezzi (listini) per evento o corso', 'listini', 30, 4, 100,
			'Quanti prezzi diversi si possono definire su un evento o su un corso (per esempio intero, ridotto, studenti, pacchetti). Nel modulo ne vedi solo quelli che servono e ne aggiungi uno alla volta.',
			'Più prezzi danno più scelta alla segreteria ma rendono più lunga la scelta in prenotazione e più facile sbagliare listino.',
			'Con pochi prezzi il modulo resta semplice, ma un evento con molte tariffe non le contiene tutte.'
		);
		$add(
			'guest_phone_required', 'soci', 'Cellulare obbligatorio per gli ospiti', 'flag', 1, 0, 1,
			'Un ospite non si registra senza cellulare: è il dato che serve a riconoscerlo (anche se viene da soci diversi) e a contattarlo su WhatsApp.',
			'Mantienilo attivo: è il comportamento consigliato.',
			'Gli ospiti senza cellulare si distinguono solo per nome e cognome: più facile creare doppioni, e il contatore delle volte già venuto può dividersi su più schede. Utile per importare uno storico di ospiti di cui non hai il numero.'
		);
		$add(
			'guest_host_required', 'soci', 'Socio ospitante obbligatorio per gli ospiti', 'flag', 1, 0, 1,
			'Un ospite si registra sempre come ospite di un socio (chi lo ha portato).',
			'Mantienilo attivo: è il comportamento consigliato.',
			'Si possono registrare ospiti senza dire chi li ha portati: si perde l\'elenco degli ospiti di ciascun socio. Utile per importare uno storico di ospiti.'
		);
		$add(
			'membership_on_balance', 'soci', 'Tessera valida solo quando la quota è saldata', 'flag', 1, 0, 1,
			'La quota associativa si può versare a rate (ad esempio 20 su 25): il programma mostra quanto manca e dà la tessera solo quando la somma raggiunge la quota.',
			'Attivo: un socio che versa meno della quota non ha la tessera finché non salda. Va bene per chi vuole il saldo completo prima dell\'iscrizione.',
			'Spento: basta un versamento qualsiasi, anche parziale, per avere la tessera (come nelle versioni precedenti) e il residuo non viene seguito.'
		);
		$add(
			'guardian_until_adult', 'soci', 'Il tutore smette di agire per chi compie 18 anni', 'flag', 1, 0, 1,
			'Ai 18 anni il genitore o tutore collegato non vede più i dati del ragazzo, non prenota e non paga per lui e non riceve più le sue email, anche se il ragazzo non ha ancora un accesso suo. Il collegamento resta registrato e il ragazzo si invita a creare il suo accesso.',
			'Acceso: è il comportamento consigliato, perché un maggiorenne decide da sé sui propri dati. Il ragazzo senza accesso proprio non ha nessuno che prenoti o paghi per lui finché non lo crea.',
			'Spento: il tutore continua a gestire il ragazzo anche dopo i 18 anni, finché un amministratore non toglie il collegamento (è il comportamento delle versioni precedenti): il tutore vede e può esportare i dati di una persona adulta senza il suo consenso.'
		);
		$add(
			'suspend_after_months', 'soci', 'Mesi di tessera scaduta prima di proporre la sospensione', 'mesi', 8, 1, 60,
			'Dopo quanti mesi dalla scadenza compare il pulsante per sospendere in blocco i soci che non hanno rinnovato.',
			'I soci che non rinnovano restano «attivi» più a lungo nelle liste e nei conteggi.',
			'Si rischia di sospendere soci che stanno solo ritardando il rinnovo.'
		);
		$add(
			'reminders_expired_days', 'soci', 'Giorni dopo la scadenza in cui si ricorda ancora la tessera', 'giorni', 7, 1, 60,
			'Per quanti giorni dopo la scadenza il promemoria automatico segnala la tessera scaduta.',
			'Messaggi di sollecito più prolungati: utili ma possono dare fastidio.',
			'Chi non legge subito l\'email può perdere il promemoria.'
		);

		$d = function_exists( 'apply_filters' ) ? apply_filters( 'asem_limits_defs', $d ) : $d; // un'estensione può aggiungere i suoi limiti
		self::$defs = $d;
		return $d;
	}

	public static function default_of( string $key ): int {
		return (int) ( self::defs()[ $key ]['default'] ?? 0 );
	}

	/** Valore ammesso: tra il minimo e il massimo (per le scelte sì/no, 0 o 1). */
	public static function clamp( string $key, $value ): int {
		$d = self::defs()[ $key ] ?? null;
		if ( ! $d ) {
			return 0;
		}
		return max( (int) $d['min'], min( (int) $d['max'], (int) $value ) );
	}

	/** Solo le voci note, con valori entro i limiti. @return array<string,int> */
	public static function sanitize( array $values ): array {
		$out = array();
		foreach ( self::defs() as $key => $d ) {
			if ( array_key_exists( $key, $values ) && is_numeric( $values[ $key ] ) ) {
				$out[ $key ] = self::clamp( $key, $values[ $key ] );
			}
		}
		return $out;
	}

	/** Valore in uso: quello scelto dall'amministratore, oppure il predefinito. */
	public static function get( string $key ): int {
		$saved = Settings::get( 'limits' );
		if ( is_array( $saved ) && isset( $saved[ $key ] ) && is_numeric( $saved[ $key ] ) ) {
			return self::clamp( $key, $saved[ $key ] );
		}
		return self::default_of( $key );
	}

	public static function flag( string $key ): bool {
		return 1 === self::get( $key );
	}
}
