<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/**
 * Promemoria automatici per email, una volta al giorno (spenti di default, si accendono dalle impostazioni):
 *  - tessera in scadenza (entro N giorni) e tessera scaduta da poco: una volta per scadenza;
 *  - corsi con rinnovo mensile: dopo l'ultima lezione del mese, a chi non ha ancora pagato il mese dopo (una volta per mese);
 *  - evento il giorno dopo: una volta per prenotazione.
 * Chi non ha email (un ospite) riceve il promemoria tramite il socio che lo ospita. Gli invii sono registrati per non ripeterli.
 */
final class Reminders {

	const HOOK            = 'asem_send_reminders';
	const OPT_LAST        = 'asem_reminders_last';
	const OPT_LOCK        = 'asem_reminders_lock';
	const BUDGET_SECONDS  = 20;  // tempo massimo di un giro: se resta lavoro, il giro dopo parte da solo
	const RETRY_SECONDS   = 120; // attesa prima del giro successivo
	const LOCK_SECONDS    = 600; // un blocco più vecchio di così si considera rimasto da un giro interrotto
	const EXPIRED_WINDOW  = 7; // giorni dopo la scadenza in cui si manda ancora il promemoria "scaduta"

	/** @var float momento oltre il quale il giro in corso si ferma */
	private static $deadline = 0.0;
	/** @var bool l'ultimo giro si è fermato per il tempo e resta lavoro */
	private static $more = false;
	/** @var bool l'ultimo giro non è partito perché un altro era in corso */
	private static $busy = false;

	/** L'ultimo giro si è fermato per il tempo: un altro parte da solo tra poco. */
	public static function more_pending(): bool {
		return self::$more;
	}

	/** L'ultimo giro non è partito: un altro era già in corso. */
	public static function was_busy(): bool {
		return self::$busy;
	}

	/** Il tempo del giro è finito? Si controlla dopo ogni invio, così ogni giro ne fa almeno uno e il lavoro avanza sempre. */
	private static function time_up(): bool {
		if ( microtime( true ) < self::$deadline ) {
			return false;
		}
		self::$more = true;
		return true;
	}

	/** Un solo giro alla volta (cron e «Invia ora» insieme). Un blocco rimasto da un giro interrotto scade dopo dieci minuti. */
	private static function lock(): bool {
		$now = time();
		if ( add_option( self::OPT_LOCK, $now, '', 'no' ) ) {
			return true;
		}
		if ( $now - (int) get_option( self::OPT_LOCK, 0 ) > self::LOCK_SECONDS ) {
			update_option( self::OPT_LOCK, $now, false );
			return true;
		}
		return false;
	}

	public static function enabled(): bool {
		return ! empty( Settings::get( 'reminders_enabled' ) );
	}

	// ---------- Registro degli invii ----------

	public static function sent( int $person_id, string $kind, string $ref ): bool {
		$db = Db::db();
		return (bool) $db->get_var( $db->prepare( 'SELECT COUNT(*) FROM ' . Db::t( 'reminders' ) . ' WHERE person_id = %d AND kind = %s AND ref = %s', $person_id, $kind, $ref ) );
	}

	private static function sent_since( int $person_id, string $kind, string $since ): bool {
		$db = Db::db();
		return (bool) $db->get_var( $db->prepare( 'SELECT COUNT(*) FROM ' . Db::t( 'reminders' ) . ' WHERE person_id = %d AND kind = %s AND sent_at >= %s', $person_id, $kind, $since ) );
	}

	/** Si prenota l'invio prima di spedire: se un'altra esecuzione (cron e "Invia ora" insieme) l'ha già preso, non si manda due volte. @return bool true se l'invio è nostro */
	public static function claim( int $person_id, string $kind, string $ref ): bool {
		$db = Db::db();
		$db->query( $db->prepare( 'INSERT IGNORE INTO ' . Db::t( 'reminders' ) . ' (person_id, kind, ref, sent_at) VALUES (%d, %s, %s, %s)', $person_id, $kind, substr( $ref, 0, 60 ), Db::now() ) );
		return 1 === (int) $db->rows_affected;
	}

	/** L'email non è partita: il promemoria torna in coda per la prossima esecuzione. */
	public static function release( int $person_id, string $kind, string $ref ): void {
		Db::db()->delete( Db::t( 'reminders' ), array( 'person_id' => $person_id, 'kind' => $kind, 'ref' => substr( $ref, 0, 60 ) ) );
	}

	/** Invia il promemoria prenotandolo prima. @return bool true se è partito ora */
	private static function deliver( array $to, int $person_id, string $kind, string $ref, string $subject, string $body ): bool {
		if ( ! self::claim( $person_id, $kind, $ref ) ) {
			return false;
		}
		if ( ! self::send( $to, $subject, $body, in_array( $kind, array( 'membership_soon', 'membership_expired', 'dues' ), true ) ) ) {
			self::release( $person_id, $kind, $ref );
			return false;
		}
		return true;
	}

	/** Manda un avviso a una persona (una sola volta per tipo e riferimento). @return bool true se è partito ora */
	public static function notify( array $p, string $kind, string $ref, string $subject, string $body ): bool {
		$to = self::recipient( $p );
		return $to && ! self::sent( (int) $p['id'], $kind, $ref ) && self::deliver( $to, (int) $p['id'], $kind, $ref, $subject, $body );
	}

	/** L'avviso ci sarebbe da mandare (ha un indirizzo e non è già partito)? */
	public static function pending( array $p, string $kind, string $ref ): bool {
		return null !== self::recipient( $p ) && ! self::sent( (int) $p['id'], $kind, $ref );
	}

	/** Prestiti con il rientro scaduto: un promemoria per prestito a chi ha il bene. @return int promemoria (o da mandare, senza invio) */
	private static function loans( bool $send ): int {
		$n = 0;
		foreach ( Inventory::overdue() as $l ) {
			$p = Plugin::people()->get( (int) $l['person_id'] );
			if ( ! $p ) {
				continue;
			}
			$body = 'la restituzione di «' . $l['item_name'] . '» era prevista per il ' . ( new \DateTimeImmutable( $l['due_on'] ) )->format( 'd/m/Y' ) . '. Quando puoi, riportalo in segreteria, oppure scrivici se ti serve più tempo. Se l\'hai già riportato, ignora questo messaggio.';
			if ( $send ? self::notify( $p, 'loan_late', (string) $l['id'], 'Da restituire: ' . $l['item_name'], $body ) : self::pending( $p, 'loan_late', (string) $l['id'] ) ) {
				$n++;
				if ( $send && self::time_up() ) {
					break; // il resto al giro successivo
				}
			}
		}
		return $n;
	}

	/** Dove mandare il promemoria di una persona: la sua email o, per un ospite senza email, quella del socio che lo ospita. @return array{email:string,name:string,about:string}|null */
	public static function recipient( array $p ): ?array {
		if ( ! empty( $p['anonymized_at'] ) ) {
			return null;
		}
		$name  = trim( $p['first_name'] . ' ' . $p['last_name'] );
		$email = (string) $p['email'];
		foreach ( Guardians::recipients( $p ) as $g ) { // un minore: il promemoria va al tutore
			if ( '' !== $g['about'] ) {
				return $g;
			}
		}
		if ( '' !== $email && is_email( $email ) ) {
			return array( 'email' => $email, 'name' => $p['first_name'], 'about' => '' );
		}
		if ( MemberType::GUEST === $p['type'] && ! empty( $p['host_person_id'] ) ) {
			$h = Plugin::people()->get( (int) $p['host_person_id'] );
			if ( $h && '' !== (string) $h['email'] && is_email( (string) $h['email'] ) ) {
				return array( 'email' => (string) $h['email'], 'name' => $h['first_name'], 'about' => $name );
			}
		}
		return null;
	}

	private static function send( array $to, string $subject, string $body, bool $with_bank = false ): bool {
		$assoc = (string) Settings::get( 'association_name' );
		if ( $with_bank && Bank::enabled() && ! empty( Settings::get( 'bank_in_reminders' ) ) ) {
			$body .= "\n\n" . Bank::text_block(); // le coordinate per il bonifico, se l'associazione le ha attivate
		}
		$text  = 'Ciao ' . $to['name'] . ",\n\n" . $body . "\n\n—\n" . ( '' !== $assoc ? $assoc . "\n" : '' ) . 'Area soci: ' . Gatekeeper::area_url();
		$ok = (bool) \AssociazioneSemplice\Texts::mail( $to['email'], \AssociazioneSemplice\Texts::subject( $subject ), $text );
		do_action( 'asem_notify_email', (string) $to['email'], $subject, $body ); // notifica sul telefono, se un'estensione la gestisce
		return $ok;
	}

	// ---------- Esecuzione ----------

	/**
	 * Cerca i promemoria da mandare oggi e (se $send) li manda. @return array membership, dues, events (conteggi di quelli mandati o, senza invio, da mandare)
	 */
	public static function run( ?string $today = null, bool $send = true ): array {
		$out = array( 'membership' => 0, 'dues' => 0, 'events' => 0, 'polls' => 0, 'loans' => 0 );
		if ( $send && ! self::enabled() ) {
			return $out;
		}
		if ( $send && ! Edition::allows( 'official_notices' ) ) {
			return $out;
		}
		$today = $today ?: current_time( 'Y-m-d' );
		if ( ! $send ) {
			self::$deadline = INF; // l'anteprima non manda nulla: nessun limite di tempo
			return self::collect( $today, false, $out );
		}
		self::$more = false;
		if ( ! self::lock() ) {
			self::$busy = true;
			return $out; // un altro giro è già in corso: i promemoria si prenotano uno per uno, niente va perso né si manda due volte
		}
		self::$busy     = false;
		self::$deadline = microtime( true ) + (float) apply_filters( 'asem_reminders_budget_seconds', self::BUDGET_SECONDS );
		try {
			$out = self::collect( $today, true, $out );
		} finally {
			delete_option( self::OPT_LOCK );
		}
		update_option( self::OPT_LAST, array( 'at' => Db::now(), 'counts' => $out ), false );
		Audit::log( 'reminders.sent', 'settings', 0, $out );
		$next = wp_next_scheduled( self::HOOK ); // il giro quotidiano c'è sempre: conta solo se è vicino
		if ( self::$more && ( false === $next || $next - time() > self::RETRY_SECONDS ) ) {
			wp_schedule_single_event( time() + self::RETRY_SECONDS, self::HOOK ); // il resto parte da solo tra poco; quelli già mandati sono registrati e non si ripetono
		}
		return $out;
	}

	/** Le cinque famiglie di promemoria, una dopo l'altra; con il tempo finito ci si ferma e il resto tocca al giro successivo. */
	private static function collect( string $today, bool $send, array $out ): array {
		if ( ! empty( Settings::get( 'reminders_membership' ) ) ) {
			$out['membership'] = self::membership( $today, $send );
		}
		if ( ! empty( Settings::get( 'reminders_dues' ) ) && ! ( $send && self::$more ) ) {
			$out['dues'] = self::dues( $today, $send );
		}
		if ( ! empty( Settings::get( 'reminders_events' ) ) && ! ( $send && self::$more ) ) {
			$out['events'] = self::events( $today, $send );
		}
		if ( ! empty( Settings::get( 'reminders_polls' ) ) && ! ( $send && self::$more ) ) {
			$out['polls'] = Polls::remind( $send );
		}
		if ( ! empty( Settings::get( 'reminders_loans' ) ) && ! ( $send && self::$more ) ) {
			$out['loans'] = self::loans( $send );
		}
		return $out;
	}

	public static function last_run(): ?array {
		$v = get_option( self::OPT_LAST, null );
		return is_array( $v ) ? $v : null;
	}

	private static function membership( string $today, bool $send ): int {
		$days  = (int) Settings::get( 'reminders_membership_days' );
		$soon  = gmdate( 'Y-m-d', strtotime( $today . ' +' . $days . ' days' ) );
		$ago   = gmdate( 'Y-m-d', strtotime( $today . ' -' . Limits::get( 'reminders_expired_days' ) . ' days' ) );
		$n     = 0;
		foreach ( Plugin::people()->search() as $p ) {
			if ( ! MemberType::is_member( $p['type'] ) || MemberType::is_auto_renewed( $p['type'] ) || ! empty( $p['suspended_at'] ) || empty( $p['active_until'] ) ) {
				continue;
			}
			$until = (string) $p['active_until'];
			if ( $until >= $today && $until <= $soon ) {
				$kind = 'membership_soon';
				$subj = 'La tua tessera sta per scadere';
				$body = 'la tua tessera associativa scade il ' . ( new \DateTimeImmutable( $until ) )->format( 'd/m/Y' ) . '. Puoi rinnovarla in segreteria o, dove previsto, online dall\'area soci.';
			} elseif ( $until < $today && $until >= $ago ) {
				$kind = 'membership_expired';
				$subj = 'La tua tessera è scaduta';
				$body = 'la tua tessera associativa è scaduta il ' . ( new \DateTimeImmutable( $until ) )->format( 'd/m/Y' ) . '. Per prenotare eventi e corsi devi rinnovarla: scrivi alla segreteria.';
			} else {
				continue;
			}
			$to = self::recipient( $p );
			if ( ! $to || self::sent( (int) $p['id'], $kind, $until ) ) {
				continue;
			}
			if ( $send && ! self::deliver( $to, (int) $p['id'], $kind, $until, $subj, $body ) ) {
				continue;
			}
			$n++;
			if ( $send && self::time_up() ) {
				break; // il resto al giro successivo
			}
		}
		return $n;
	}

	/**
	 * Corsi con rinnovo mensile: dopo l'ULTIMA lezione del mese si ricorda a chi non ha ancora pagato il mese dopo (si rinnovano a inizio mese).
	 * Un solo promemoria per persona, corso e mese; non si manda per un corso "una tantum", né oltre la fine dell'anno sociale o del corso.
	 */
	private static function dues( string $today, bool $send ): int {
		$acts   = Plugin::activities();
		$people = Plugin::people();
		$cur    = substr( $today, 0, 7 );
		$target = gmdate( 'Y-m', strtotime( $cur . '-01 +1 month' ) );
		$mstart = $cur . '-01';
		$mend   = gmdate( 'Y-m-t', strtotime( $mstart ) );
		$last   = array(); // attività => data dell'ultima lezione del mese
		$any    = array(); // attività che hanno lezioni in calendario questo mese
		foreach ( Calendar::occurrences( $mstart, $mend ) as $o ) {
			if ( 'course' === $o['kind'] ) {
				$any[ (int) $o['activity_id'] ] = true;
				$last[ (int) $o['activity_id'] ] = max( $last[ (int) $o['activity_id'] ] ?? '', $o['date'] );
			}
		}
		$n = 0;
		foreach ( $acts->for_year( Settings::social_year( $today )->label() ) as $a ) {
			$aid = (int) $a['id'];
			if ( ActivityKind::COURSE !== $a['kind'] || in_array( $a['billing'] ?? 'monthly', array( 'once', 'quarterly' ), true ) ) {
				continue;
			}
			if ( ! in_array( $target, SocialYear::from_label( $a['social_year'], Settings::start_month() )->months(), true ) ) {
				continue; // il mese dopo è nell'anno sociale successivo
			}
			if ( ! empty( $a['ends_on'] ) && substr( (string) $a['ends_on'], 0, 7 ) < $target ) {
				continue; // il corso finisce prima
			}
			$last_lesson = isset( $any[ $aid ] ) ? $last[ $aid ] : ( ! empty( ActivityService::slot_days( $a ) ) ? '' : $cur . '-24' ); // senza orari di lezione: dal 25 del mese
			if ( '' === $last_lesson || $today <= $last_lesson ) {
				continue; // l'ultima lezione del mese non c'è ancora stata (o non ci sono lezioni questo mese)
			}
			foreach ( $acts->status_for_activity( $aid ) as $s ) {
				$e = $s['enrollment'];
				if ( null !== $e['end_month'] || $e['start_month'] > $target ) {
					continue;
				}
				$p = $people->get( (int) $e['person_id'] );
				if ( ! $p || ! empty( $p['suspended_at'] ) ) {
					continue;
				}
				$fee  = $acts->fee_for( $a, $p['type'] );
				$paid = 0;
				foreach ( $s['summary']['months'] as $m ) {
					if ( $m['month'] === $target ) {
						$paid = (int) $m['paid'];
					}
				}
				if ( $fee <= 0 || $paid >= $fee ) {
					continue;
				}
				$to  = self::recipient( $p );
				$ref = $aid . ':' . $target;
				if ( ! $to || self::sent( (int) $p['id'], 'dues', $ref ) ) {
					continue;
				}
				$who  = '' !== $to['about'] ? 'per ' . $to['about'] . ' ' : '';
				$body = 'il corso «' . $a['name'] . '» si rinnova all\'inizio di ' . self::month_name( $target ) . ': ' . $who . ( $paid > 0 ? 'restano da pagare ' . Money::format( $fee - $paid ) . ' della mensilità' : 'la mensilità è di ' . Money::format( $fee - $paid ) )
					. ". Puoi pagare in segreteria o, dove previsto, online dall'area soci.\nSe non vuoi più frequentare, avvisa la segreteria prima dell'inizio del mese. Se hai già pagato, ignora questo messaggio.";
				if ( $send && ! self::deliver( $to, (int) $p['id'], 'dues', $ref, 'Rinnovo del corso ' . $a['name'], $body ) ) {
					continue;
				}
				$n++;
				if ( $send && self::time_up() ) {
					return $n; // il resto al giro successivo
				}
			}
		}
		return $n;
	}

	private static function month_name( string $ym ): string {
		return ( Frontend\Views::MONTHS[ (int) substr( $ym, 5, 2 ) ] ?? $ym ) . ' ' . substr( $ym, 0, 4 );
	}

	private static function events( string $today, bool $send ): int {
		$tomorrow = gmdate( 'Y-m-d', strtotime( $today . ' +1 day' ) );
		$db       = Db::db();
		$rows     = $db->get_results(
			$db->prepare(
				'SELECT b.id AS booking_id, b.person_id, s.id AS session_id, s.session_date, s.start_time, s.location, a.name AS activity_name FROM ' . Db::t( 'bookings' ) . ' b '
				. 'JOIN ' . Db::t( 'sessions' ) . ' s ON s.id = b.session_id AND s.cancelled_at IS NULL JOIN ' . Db::t( 'activities' ) . " a ON a.id = s.activity_id AND a.deleted_at IS NULL WHERE b.status = 'booked' AND s.session_date = %s",
				$tomorrow
			),
			ARRAY_A
		) ?: array();
		$n = 0;
		foreach ( $rows as $r ) {
			$p = Plugin::people()->get( (int) $r['person_id'] );
			if ( ! $p ) {
				continue;
			}
			$to = self::recipient( $p );
			if ( ! $to || self::sent( (int) $p['id'], 'event', (string) $r['session_id'] ) ) {
				continue;
			}
			$who  = '' !== $to['about'] ? 'di ' . $to['about'] . ' ' : '';
			$body = 'ti ricordiamo la prenotazione ' . $who . 'per «' . $r['activity_name'] . '» di domani, ' . ( new \DateTimeImmutable( $r['session_date'] ) )->format( 'd/m/Y' )
				. ( $r['start_time'] ? ' alle ' . $r['start_time'] : '' ) . ( $r['location'] ? ', ' . $r['location'] : '' ) . '. Se non puoi venire, annulla dall\'area soci, se l\'evento lo permette.';
			if ( $send && ! self::deliver( $to, (int) $p['id'], 'event', (string) $r['session_id'], 'Domani: ' . $r['activity_name'], $body ) ) {
				continue;
			}
			$n++;
			if ( $send && self::time_up() ) {
				break; // il resto al giro successivo
			}
		}
		return $n;
	}
}
