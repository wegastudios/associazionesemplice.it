<?php
namespace AssociazioneSemplice\Frontend;

use AssociazioneSemplice\Access;
use AssociazioneSemplice\Attachments;
use AssociazioneSemplice\Bank;
use AssociazioneSemplice\CardToken;
use AssociazioneSemplice\MemberType;
use AssociazioneSemplice\Money;
use AssociazioneSemplice\Plugin;
use AssociazioneSemplice\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Azioni dei soci dal sito (prenota, annulla, aggiungi un ospite, aggiorna il profilo).
 * La logica sta nei metodi `do_*` (lanciano \InvalidArgumentException con un messaggio leggibile);
 * il resto è solo il collegamento con admin-post.php, nonce e ritorno alla pagina di partenza.
 * Ogni azione controlla i permessi con le capability meta di {@see Access}: quindi vale anche la licenza.
 */
final class Actions {

	const MAP = array(
		'asem_front_book'           => 'do_book',
		'asem_front_request'        => 'do_request',
		'asem_front_course_request' => 'do_course_request',
		'asem_front_accept_rules'   => 'do_accept_rules',
		'asem_front_accept_for'     => 'do_accept_for',
		'asem_front_waitlist_join'  => 'do_waitlist_join',
		'asem_front_waitlist_leave' => 'do_waitlist_leave',
		'asem_front_cancel_booking' => 'do_cancel_booking',
		'asem_front_transfer_booking' => 'do_transfer_booking',
		'asem_front_add_guest'      => 'do_add_guest',
		'asem_front_profile'        => 'do_profile',
		'asem_front_expense'        => 'do_expense',
		'asem_front_expense_docs'   => 'do_expense_docs',
		'asem_front_checkin'        => 'do_checkin',
		'asem_front_checkin_scan'   => 'do_checkin_scan',
		'asem_front_collect'        => 'do_collect',
		'asem_front_new_member'     => 'do_new_member',
		'asem_front_notice'         => 'do_notice',
		'asem_front_vote'           => 'do_vote',
		'asem_front_bank_email'     => 'do_bank_email',
	);

	/** @var array<string,array{0:callable,1:bool}> azioni aggiunte da un'estensione: [gestore, restituisce un indirizzo] */
	private static $extra = array();

	/**
	 * Un'estensione aggiunge un'azione dei moduli del sito. Il gestore riceve i dati inviati e restituisce un messaggio
	 * (oppure, con `$returns_url`, l'indirizzo a cui mandare la persona) o lancia InvalidArgumentException con il motivo del rifiuto.
	 */
	public static function add_handler( string $action, callable $handler, bool $returns_url = false ): void {
		self::$extra[ $action ] = array( $handler, $returns_url );
	}

	private static function bind_extra( string $action, callable $handler, bool $url ): void {
		$run = function () use ( $action, $handler, $url ) {
				\AssociazioneSemplice\Csrf::check( $action );
				$post = \AssociazioneSemplice\Plugin::post_data(); // phpcs:ignore WordPress.Security.NonceVerification
				$back = self::back_url( $post );
				try {
					$res = call_user_func( $handler, $post );
					if ( $url ) {
						wp_redirect( (string) $res ); // phpcs:ignore WordPress.Security.SafeRedirect -- indirizzo restituito dall'estensione (ad esempio il gateway)
						exit;
					}
					self::redirect( $back, (string) $res );
				} catch ( \InvalidArgumentException $e ) {
					self::redirect( $back, '', $e->getMessage() );
				} catch ( \Throwable $e ) {
					self::redirect( $back, '', 'Qualcosa non ha funzionato. Riprova tra poco; se succede ancora, scrivi alla segreteria.' );
				}
			};
		add_action( 'admin_post_' . $action, $run );
		add_action( 'admin_post_nopriv_' . $action, \AssociazioneSemplice\Csrf::nopriv( $run, array( __CLASS__, 'to_login' ) ) );
	}

	/** Chi non ha fatto l'accesso viene mandato al login e poi riportato alla pagina. */
	public static function to_login(): void {
		wp_safe_redirect( wp_login_url( self::back_url( \AssociazioneSemplice\Plugin::post_data() ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		exit;
	}

	public static function register(): void {
		// Azioni di un'estensione: la risposta è un messaggio oppure un indirizzo esterno (ad esempio la pagina del gateway di pagamento).
		foreach ( self::$extra as $action => $h ) {
			self::bind_extra( $action, $h[0], $h[1] );
		}
		foreach ( self::MAP as $action => $method ) {
			$run = function () use ( $action, $method ) {
				// Il profilo si salva solo con l'invio di un modulo: con un GET i campi arriverebbero vuoti e verrebbero cancellati.
				if ( 'asem_front_profile' === $action && 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
					wp_die( esc_html( 'Questa pagina si apre solo salvando il profilo: torna all\'area soci.' ), '', array( 'response' => 405 ) );
				}
				\AssociazioneSemplice\Csrf::check( $action );
				$post = \AssociazioneSemplice\Plugin::post_data(); // phpcs:ignore WordPress.Security.NonceVerification
				$back = self::back_url( $post );
				try {
					self::redirect( $back, self::$method( $post ) );
				} catch ( \InvalidArgumentException $e ) {
					self::redirect( $back, '', $e->getMessage() );
				} catch ( \Throwable $e ) {
					self::redirect( $back, '', 'Qualcosa non ha funzionato. Riprova tra poco; se succede ancora, scrivi alla segreteria.' );
				}
			};
			add_action( 'admin_post_' . $action, $run );
			// Chi non ha fatto l'accesso viene mandato al login e poi riportato alla pagina (chi ha l'accesso proprio prosegue).
			add_action( 'admin_post_nopriv_' . $action, \AssociazioneSemplice\Csrf::nopriv( $run, array( __CLASS__, 'to_login' ) ) );
		}
	}

	public static function back_url( array $post ): string {
		$url = ! empty( $post['_back'] ) ? esc_url_raw( $post['_back'] ) : home_url( '/' );
		return wp_validate_redirect( $url, home_url( '/' ) );
	}

	private static function redirect( string $url, string $ok = '', string $err = '' ): void {
		wp_safe_redirect( \AssociazioneSemplice\Flash::url( $url, 'asemf', $ok, $err ) );
		exit;
	}

	/** La persona collegata all'utente, solo se è un socio (non un ospite). */
	public static function actor(): array {
		$p = Access::current_person();
		if ( ! $p || ! MemberType::can_login( $p['type'] ) ) {
			throw new \InvalidArgumentException( 'Per farlo devi entrare come socio.' );
		}
		return $p;
	}

	/** Le azioni delle funzioni avanzate si rifiutano se la funzione non c'è in questa edizione. */
	private static function require_feature( string $feature ): void {
		if ( ! \AssociazioneSemplice\Edition::has( $feature ) ) {
			throw new \InvalidArgumentException( \AssociazioneSemplice\Edition::missing_message() ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
	}

	/** Con la tessera di chi si prenota: della persona stessa (o del suo ospitante, che prenota con la propria) oppure, per un minore, del minore. */
	private static function booking_subject( array $actor, int $person_id ): array {
		$ward = \AssociazioneSemplice\Guardians::is_guardian_of( (int) $actor['id'], $person_id ) ? Plugin::people()->get( $person_id ) : null;
		return $ward ?: $actor;
	}

	public static function require_cap( string $ability, int $object_id ): void {
		if ( ! current_user_can( $ability, $object_id ) ) {
			throw new \InvalidArgumentException( 'Non hai il permesso di fare questa operazione.' );
		}
	}

	/**
	 * Messaggio per chi ha la tessera non valida: dice cosa fare e dove (la stessa frase ovunque).
	 *
	 * @param array  $who   la persona la cui tessera non è valida
	 * @param array  $actor chi sta usando l'area soci
	 * @param string $for   cosa voleva fare, all'infinito («prenotare»)
	 */
	public static function card_invalid( array $who, array $actor, string $for ): string {
		$own   = (int) ( $who['id'] ?? 0 ) === (int) ( $actor['id'] ?? -1 );
		$where = self::renew_where();
		return ( $own ? 'La tua tessera non è valida: non puoi ' . $for . '. ' : 'La tessera di ' . trim( (string) ( $who['first_name'] ?? '' ) ) . ' non è valida: per questa persona non puoi ' . $for . '. ' ) . $where;
	}

	/** Il pezzo di frase che diventa un link all'area soci quando il messaggio si mostra (vedi Views::flash). */
	const RENEW_LINK = 'Rinnova online dalla tua area soci';

	/**
	 * Dove e come si rinnova la quota (regola unica, per il socio): con i pagamenti online attivi si rinnova dalla propria area soci
	 * (sezione «Pagamenti»), altrimenti in segreteria, con il numero se l'associazione lo ha indicato.
	 */
	public static function renew_where(): string {
		if ( Plugin::payments()->enabled() ) {
			return self::RENEW_LINK . ' (sezione «Pagamenti»), oppure rivolgiti alla segreteria.';
		}
		$phone = trim( (string) \AssociazioneSemplice\Settings::get( 'secretary_phone' ) );
		return 'Rinnova la quota in segreteria' . ( '' !== $phone ? ' (telefono o WhatsApp ' . $phone . ')' : '' ) . '.';
	}

	/** Messaggio per lo staff che prenota o incassa per un socio con la tessera non valida: la quota si rinnova dalla sua scheda. */
	public static function card_invalid_staff( string $name ): string {
		return 'La tessera di ' . $name . ' non è valida: rinnova la quota dalla scheda del socio, poi riprova a prenotare.';
	}

	/** Chiede di partecipare a un evento con approvazione della segreteria (per sé o per un proprio ospite o minore). @return string messaggio */
	public static function do_request( array $post ): string {
		$actor     = self::actor();
		$person_id = (int) ( $post['person_id'] ?? $actor['id'] );
		self::assert_profile( $actor );
		self::require_cap( 'asem_book_for', $person_id );
		$subject = self::booking_subject( $actor, $person_id );
		$block   = \AssociazioneSemplice\Regulation::booking_block( $subject );
		if ( '' !== $block ) {
			throw new \InvalidArgumentException( $block ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		if ( ! Plugin::people()->is_active_member( (int) $subject['id'] ) ) {
			throw new \InvalidArgumentException( self::card_invalid( $subject, $actor, 'partecipare' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		\AssociazioneSemplice\EventRequests::member_request( (int) ( $post['session_id'] ?? 0 ), $person_id );
		return 'Richiesta inviata. La segreteria esamina le richieste in ordine di arrivo e ti scrive.';
	}

	/** Chiede l'iscrizione a un corso (per sé o per un proprio ospite o minore): la segreteria approva. @return string messaggio */
	public static function do_course_request( array $post ): string {
		$actor     = self::actor();
		$person_id = (int) ( $post['person_id'] ?? $actor['id'] );
		self::assert_profile( $actor );
		self::require_cap( 'asem_book_for', $person_id );
		$subject = self::booking_subject( $actor, $person_id );
		if ( ! Plugin::people()->is_active_member( (int) $subject['id'] ) ) {
			throw new \InvalidArgumentException( self::card_invalid( $subject, $actor, 'iscriverti' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		\AssociazioneSemplice\EventRequests::course_member_request( (int) ( $post['activity_id'] ?? 0 ), $person_id );
		return 'Richiesta inviata. La segreteria esamina le richieste in ordine di arrivo e ti scrive.';
	}

	/** Prenota sé stessi o un proprio ospite. @return string messaggio */
	public static function do_book( array $post ): string {
		$actor     = self::actor();
		$person_id = (int) ( $post['person_id'] ?? $actor['id'] );
		self::assert_profile( $actor );
		self::require_cap( 'asem_book_for', $person_id );
		$ward  = \AssociazioneSemplice\Guardians::is_guardian_of( (int) $actor['id'], $person_id ) ? Plugin::people()->get( $person_id ) : null; // un minore prenota con la propria tessera, per mano del tutore
		$block = \AssociazioneSemplice\Regulation::booking_block( $ward ?: $actor );
		if ( '' !== $block ) {
			throw new \InvalidArgumentException( $block ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		if ( ! Plugin::people()->is_active_member( (int) ( $ward ? $ward['id'] : $actor['id'] ) ) ) {
			throw new \InvalidArgumentException( self::card_invalid( $ward ?: $actor, $actor, 'prenotare' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$session = Plugin::activities()->session( (int) ( $post['session_id'] ?? 0 ) );
		if ( ! $session ) {
			throw new \InvalidArgumentException( 'Questo evento non c\'è più: ricarica la pagina.' );
		}
		if ( ! \AssociazioneSemplice\ActivityService::online_bookable( $session ) ) {
			throw new \InvalidArgumentException( \AssociazioneSemplice\ActivityService::last_day( $session ) >= current_time( 'Y-m-d' ) ? 'Le prenotazioni online si chiudono il giorno prima: per questa data rivolgiti alla segreteria.' : 'Questo evento è già passato.' );
		}
		$list_key = sanitize_key( (string) ( $post['price_list'] ?? '' ) );
		$act_row  = Plugin::activities()->get( (int) $session['activity_id'] );
		if ( '' === $list_key && $act_row && \AssociazioneSemplice\PriceLists::for_activity( $act_row ) ) { // con i listini ne va scelto uno: il contributo base non basta
			throw new \InvalidArgumentException( 'Scegli uno dei contributi proposti per questa attività.' );
		}
		Plugin::activities()->book( (int) $session['id'], $person_id, array( 'price_list' => $list_key ) ); // ospiti e pacchetti già pagati: solo la segreteria
		$person = Plugin::people()->get( $person_id );
		return 'Prenotazione registrata' . ( $person ? ' per ' . $person['first_name'] : '' ) . '.';
	}

	/** Mette in lista d'attesa sé stessi o un proprio ospite per una data senza più posti. */
	public static function do_waitlist_join( array $post ): string {
		$actor     = self::actor();
		$person_id = (int) ( $post['person_id'] ?? $actor['id'] );
		self::assert_profile( $actor );
		self::require_cap( 'asem_book_for', $person_id );
		$subject = self::booking_subject( $actor, $person_id );
		$block   = \AssociazioneSemplice\Regulation::booking_block( $subject );
		if ( '' !== $block ) {
			throw new \InvalidArgumentException( $block ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		if ( ! Plugin::people()->is_active_member( (int) $subject['id'] ) ) {
			throw new \InvalidArgumentException( self::card_invalid( $subject, $actor, 'prenotare' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$sid = (int) ( $post['session_id'] ?? 0 );
		\AssociazioneSemplice\Waitlist::join( $sid, $person_id, (int) $actor['id'], sanitize_key( (string) ( $post['price_list'] ?? '' ) ) );
		return 'Sei in lista d\'attesa (posizione ' . (int) \AssociazioneSemplice\Waitlist::position( $sid, $person_id ) . '): se si libera un posto vieni prenotato automaticamente e ricevi un\'email.';
	}

	public static function do_waitlist_leave( array $post ): string {
		$actor     = self::actor();
		$person_id = (int) ( $post['person_id'] ?? $actor['id'] );
		self::require_cap( 'asem_book_for', $person_id );
		\AssociazioneSemplice\Waitlist::leave( (int) ( $post['session_id'] ?? 0 ), $person_id );
		return 'Hai lasciato la lista d\'attesa.';
	}

	/** Il socio accetta il regolamento in vigore. */
	public static function do_accept_rules( array $post ): string {
		$actor = self::actor();
		if ( ! \AssociazioneSemplice\Regulation::enabled() ) {
			throw new \InvalidArgumentException( 'Non c\'è nessun regolamento da accettare.' );
		}
		if ( empty( $post['rules_ok'] ) ) {
			throw new \InvalidArgumentException( 'Per continuare spunta la casella di accettazione.' );
		}
		\AssociazioneSemplice\Regulation::accept( (int) $actor['id'], 'web' );
		return 'Grazie: hai accettato il ' . mb_strtolower( \AssociazioneSemplice\Regulation::title(), 'UTF-8' ) . '.';
	}

	/** Il tutore accetta il regolamento e/o dà il consenso privacy per conto di un minore: resta registrato chi ha accettato. */
	public static function do_accept_for( array $post ): string {
		$actor     = self::actor();
		$person_id = (int) ( $post['person_id'] ?? 0 );
		self::require_cap( 'asem_book_for', $person_id );
		$ward = \AssociazioneSemplice\Guardians::is_guardian_of( (int) $actor['id'], $person_id ) ? Plugin::people()->get( $person_id ) : null;
		if ( ! $ward ) {
			throw new \InvalidArgumentException( 'Non sei il tutore di questa persona.' );
		}
		$done = 0;
		if ( ! empty( $post['rules_ok'] ) && \AssociazioneSemplice\Regulation::applies_to( $ward ) && ! \AssociazioneSemplice\Regulation::accepted( $ward ) ) {
			\AssociazioneSemplice\Regulation::accept( $person_id, 'web', (int) $actor['id'] );
			$done++;
		}
		if ( ! empty( $post['privacy_ok'] ) && ! \AssociazioneSemplice\Privacy::has_consent( $ward ) ) {
			\AssociazioneSemplice\Privacy::set_consent( $person_id, 'web', (int) $actor['id'] );
			$done++;
		}
		if ( 0 === $done ) {
			throw new \InvalidArgumentException( 'Per continuare spunta la casella di accettazione.' );
		}
		return 'Registrato: hai accettato per conto di ' . $ward['first_name'] . '.';
	}

	/** Annulla una prenotazione se la regola lo consente: gratis sempre; a pagamento solo se l'evento è cancellabile e nei termini. */
	public static function do_cancel_booking( array $post ): string {
		$actor     = self::actor();
		$person_id = (int) ( $post['person_id'] ?? $actor['id'] );
		self::require_cap( 'asem_book_for', $person_id );
		$session_id = (int) ( $post['session_id'] ?? 0 );
		if ( ! Plugin::activities()->session( $session_id ) ) {
			throw new \InvalidArgumentException( 'Questo evento non c\'è più: ricarica la pagina.' );
		}
		$eval = Plugin::activities()->cancellation_for( $session_id, $person_id );
		if ( ! $eval['allowed'] ) {
			throw new \InvalidArgumentException( $eval['message'] ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		Plugin::activities()->cancel_booking( $session_id, $person_id );
		return 'Prenotazione annullata.';
	}

	/**
	 * Cambia il nominativo di una prenotazione: a un proprio ospite già inserito, a sé stessi, oppure a un nuovo ospite
	 * (nome e cognome). Se il nuovo partecipante ha un contributo maggiore la differenza resta da pagare.
	 */
	public static function do_transfer_booking( array $post ): string {
		$actor      = self::actor();
		$from_id    = (int) ( $post['person_id'] ?? $actor['id'] );
		$session_id = (int) ( $post['session_id'] ?? 0 );
		self::require_cap( 'asem_book_for', $from_id );
		$subject = self::booking_subject( $actor, $from_id );
		if ( ! Plugin::people()->is_active_member( (int) $subject['id'] ) ) {
			throw new \InvalidArgumentException( self::card_invalid( $subject, $actor, 'gestire le prenotazioni' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$block = \AssociazioneSemplice\Regulation::booking_block( $subject );
		if ( '' !== $block ) {
			throw new \InvalidArgumentException( $block ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$to_id = (int) ( $post['to_person_id'] ?? 0 );
		$first = trim( (string) ( $post['new_first_name'] ?? '' ) );
		$last  = trim( (string) ( $post['new_last_name'] ?? '' ) );
		if ( ! $to_id && ( '' !== $first || '' !== $last ) ) {
			self::require_cap( 'asem_add_guest', (int) $actor['id'] );
			$to_id = Plugin::people()->create( array( 'type' => MemberType::GUEST, 'host_person_id' => (int) $actor['id'], 'first_name' => $first, 'last_name' => $last, 'phone' => (string) ( $post['new_phone'] ?? '' ) ) );
		}
		if ( ! $to_id ) {
			throw new \InvalidArgumentException( 'Scegli a chi cedere il posto, oppure scrivi nome e cognome di un nuovo ospite.' );
		}
		self::require_cap( 'asem_book_for', $to_id );
		Plugin::activities()->transfer_booking( $session_id, $from_id, $to_id, true );
		$b   = Plugin::activities()->bookings_for_session( $session_id );
		$msg = 'Posto ceduto.';
		foreach ( $b as $row ) {
			if ( (int) $row['person_id'] === $to_id && $row['remaining'] > 0 ) {
				$msg .= ' Resta da pagare: ' . \AssociazioneSemplice\Money::format( (int) $row['remaining'] ) . ' (in sede).';
			}
		}
		return $msg;
	}

	/**
	 * Avvia il pagamento online delle voci scelte (dovute da lui o dai suoi ospiti).
	 * @return string indirizzo della pagina di pagamento del gateway
	 */
	/** Chi si è attivato dal sito deve prima completare indirizzo e codice fiscale (vedi Limits «profile_gate»). */
	public static function assert_profile( array $actor ): void {
		if ( Plugin::people()->profile_blocks( $actor ) ) {
			throw new \InvalidArgumentException( 'Prima di prenotare o pagare completa i tuoi dati (indirizzo e codice fiscale) nel riquadro «Il mio profilo».' );
		}
	}


	/** Il socio si fa mandare per email le coordinate del bonifico (con le voci da pagare e la causale): sempre e solo al suo indirizzo. */
	public static function do_bank_email( array $post ): string {
		$actor = self::actor();
		self::require_cap( 'asem_view_payments', (int) $actor['id'] );
		$dues = Plugin::payments()->dues_for( $actor );
		$keys = array_map( 'strval', (array) ( $post['items'] ?? array() ) );
		if ( $keys ) { // solo le voci scelte (se non ne sceglie nessuna, tutte quelle dovute)
			$dues = array_intersect_key( $dues, array_flip( $keys ) );
		}
		Bank::send_to_member( $actor, array_values( $dues ), \AssociazioneSemplice\MemberSession::actor_key() );
		return 'Ti abbiamo inviato le coordinate per il bonifico: controlla la tua email.';
	}

	/** Spesa registrata dal tesoriere (con scontrino e fatture allegati). Non vede né modifica altro della prima nota. */
	public static function do_expense( array $post ): string {
		self::require_cap( 'asem_add_expense', 0 );
		$date = (string) ( $post['date'] ?? '' );
		if ( $date > current_time( 'Y-m-d' ) ) {
			throw new \InvalidArgumentException( 'La data della spesa non può essere nel futuro.' );
		}
		$docs = Attachments::prepare( Attachments::from_request() ); // controllati prima: se un file non va, non si registra nulla
		$tx   = Plugin::ledger()->record_expense(
			array(
				'date'         => $date,
				'account_id'   => (int) ( $post['account_id'] ?? 0 ),
				'method'       => (string) ( $post['method'] ?? '' ),
				'category_id'  => (int) ( $post['category_id'] ?? 0 ),
				'amount_cents' => Money::parse( $post['amount'] ?? '' ) ?? 0,
				'activity_id'  => (int) ( $post['activity_id'] ?? 0 ),
				'description'  => $post['description'] ?? '',
				'person_id'    => (int) apply_filters( 'asem_expense_person', 0, array( 'fund_auto' => '1' ) ), // nell'area soci non si sceglie né il beneficiario né il fondo: un'estensione imposta chi ha anticipato (chi registra) e l'attribuzione è sempre automatica
				'document_ref' => $post['document_ref'] ?? '',
			)
		);
		$ids = Attachments::add( $tx, $docs );
		return 'Spesa registrata' . ( $ids ? ' con ' . count( $ids ) . ( 1 === count( $ids ) ? ' documento.' : ' documenti.' ) : '.' );
	}

	/** Altri documenti su una spesa registrata dallo stesso utente. */
	public static function do_expense_docs( array $post ): string {
		self::require_cap( 'asem_add_expense', 0 );
		$tx   = (int) ( $post['transaction_id'] ?? 0 );
		$mine = Plugin::ledger()->expenses_by_user( get_current_user_id(), 200 );
		if ( ! in_array( $tx, array_map( 'intval', array_column( $mine, 'id' ) ), true ) ) {
			throw new \InvalidArgumentException( 'Puoi aggiungere documenti solo alle spese che hai registrato tu.' );
		}
		$ids = Attachments::add( $tx, Attachments::prepare( Attachments::from_request(), $tx ) );
		if ( ! $ids ) {
			throw new \InvalidArgumentException( 'Scegli almeno un file.' );
		}
		return count( $ids ) . ( 1 === count( $ids ) ? ' documento aggiunto.' : ' documenti aggiunti.' );
	}

	/** Messaggio dopo una registrazione di ingresso: chi, e se c'è un contributo ancora da versare. */
	private static function checkin_message( array $r, int $session_id, int $person_id ): string {
		$name = '';
		$due  = '';
		foreach ( Plugin::activities()->bookings_for_session( $session_id ) as $b ) {
			if ( (int) $b['person_id'] === $person_id ) {
				$name = trim( $b['first_name'] . ' ' . $b['last_name'] );
				if ( $b['active'] && (int) $b['remaining'] > 0 ) {
					$due = ' (contributo da pagare ' . Money::format( (int) $b['remaining'] ) . ')';
				}
			}
		}
		switch ( $r['status'] ) {
			case 'recorded':
				return 'Ingresso registrato: ' . $name . $due . '.';
			case 'already':
				return 'Ingresso già registrato alle ' . mysql2date( 'H:i', $r['at'] ) . ': ' . $name . '.';
			case 'undone':
				return 'Ingresso annullato: ' . $name . '.';
		}
		return 'Nessun ingresso da annullare per ' . $name . '.';
	}

	/** Iscrizione di un nuovo socio ordinario dall'area soci (tesoriere): bastano nome e cognome, il resto si completa dopo. */
	public static function do_new_member( array $post ): string {
		self::require_cap( 'asem_register_member', 0 );
		$first = trim( sanitize_text_field( (string) ( $post['first_name'] ?? '' ) ) );
		$last  = trim( sanitize_text_field( (string) ( $post['last_name'] ?? '' ) ) );
		if ( '' === $first || '' === $last ) {
			throw new \InvalidArgumentException( 'Indica nome e cognome.' );
		}
		$email = trim( (string) ( $post['email'] ?? '' ) );
		if ( '' !== $email && ! is_email( $email ) ) {
			throw new \InvalidArgumentException( 'L\'email non è valida.' );
		}
		$level = \AssociazioneSemplice\Levels::get( (int) ( $post['level_id'] ?? 0 ) );
		if ( ! \AssociazioneSemplice\Edition::has( 'levels' ) ) { // una quota sola: il tipo di socio non si sceglie
			$only  = \AssociazioneSemplice\Levels::choices( MemberType::ORDINARY );
			$level = $only ? $only[0] : null;
		}
		if ( ! $level || empty( $level['active'] ) || MemberType::ORDINARY !== $level['base_type'] ) {
			throw new \InvalidArgumentException( 'Scegli il tipo di socio.' );
		}
		$id = Plugin::people()->create(
			array(
				'type' => MemberType::ORDINARY, 'level_id' => (int) $level['id'], 'first_name' => $first, 'last_name' => $last,
				'email' => $email, 'phone' => trim( (string) ( $post['phone'] ?? '' ) ),
			)
		);
		\AssociazioneSemplice\Audit::log( 'person.registered_front', 'person', (int) $id );
		$p = Plugin::people()->get( (int) $id );
		return 'Socio registrato: ' . Plugin::people()->full_name( $p ) . ( ! empty( $p['card_number'] ) ? ' (tessera n. ' . $p['card_number'] . ')' : '' ) . '. Ora puoi incassare la quota associativa.';
	}

	/** Incasso del tesoriere dall'area soci. */
	public static function do_collect( array $post ): string {
		self::require_cap( 'asem_collect', 0 );
		$ledger = Plugin::ledger();
		$lines  = array();
		foreach ( (array) ( $post['lines'] ?? array() ) as $l ) {
			$what = (string) ( $l['what'] ?? '' );
			if ( '' === $what ) {
				continue;
			}
			$cents = Money::parse( $l['amount'] ?? '' ) ?? 0;
			if ( 'm' === $what ) {
				$lines[] = array( 'category_id' => $ledger->category_id_of_kind( 'membership' ), 'amount_cents' => $cents );
			} elseif ( 0 === strpos( $what, 's:' ) ) {
				$s = Plugin::activities()->session( (int) substr( $what, 2 ) );
				if ( ! $s ) {
					throw new \InvalidArgumentException( 'Questa data non c\'è più: ricarica la pagina.' );
				}
				$lines[] = array( 'category_id' => $ledger->category_id_of_kind( 'activity_fee' ), 'amount_cents' => $cents, 'activity_id' => (int) $s['activity_id'], 'session_id' => (int) $s['id'] );
			} elseif ( 0 === strpos( $what, 'k:' ) ) {
				$lines[] = array(
					'category_id' => $ledger->category_id_of_kind( 'activity_fee' ), 'amount_cents' => $cents, 'activity_id' => (int) substr( $what, 2 ),
					'competence_month' => Settings::social_year()->clamp( substr( current_time( 'Y-m-d' ), 0, 7 ) ),
				);
			} elseif ( 0 === strpos( $what, 'c:' ) ) {
				$lines[] = array( 'category_id' => (int) substr( $what, 2 ), 'amount_cents' => $cents );
			}
		}
		if ( ! $lines ) {
			throw new \InvalidArgumentException( 'Scegli almeno una voce da incassare.' );
		}
		$pid = (int) ( $post['person_id'] ?? 0 );
		$acts = Plugin::activities();
		$ledger->in_batch(
			function () use ( $post, $pid, $lines, $acts, $ledger ) {
				$people   = Plugin::people();
				$who      = $people->get( $pid );
				$cat_memb = $ledger->category_id_of_kind( 'membership' );
				$renewing = false;
				foreach ( $lines as $l ) {
					$renewing = $renewing || (int) $l['category_id'] === $cat_memb;
				}
				foreach ( $lines as $l ) {
					// Un socio con la tessera non in regola prenota solo se la rinnova nello stesso incasso
					if ( ! empty( $l['session_id'] ) && $who && MemberType::is_member( $who['type'] ) && ! $renewing && ! $people->is_active_member( $pid ) ) {
						throw new \InvalidArgumentException( 'La tessera di ' . trim( $who['first_name'] . ' ' . $who['last_name'] ) . ' non è valida: aggiungi la quota associativa nello stesso incasso.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
					}
				}
				foreach ( $lines as $l ) { // corsi: tessera in regola (o rinnovata qui), socio non sospeso, iscrizione se manca
					if ( ! empty( $l['competence_month'] ) && ! empty( $l['activity_id'] ) ) {
						$cname = $who ? trim( $who['first_name'] . ' ' . $who['last_name'] ) : '';
						if ( $who && MemberType::is_member( $who['type'] ) && ! MemberType::is_auto_renewed( $who['type'] ) && ! $renewing && ! $people->is_active_member( $pid ) ) {
							throw new \InvalidArgumentException( $cname . ': per un corso la tessera deve essere valida (aggiungi la quota associativa nello stesso incasso).' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
						}
						if ( $people->is_suspended( $pid ) ) {
							throw new \InvalidArgumentException( $cname . ' è sospeso (inattivo): va riattivato prima di iscriverlo a un corso.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
						}
						if ( ! in_array( (int) $l['activity_id'], $acts->active_activity_ids( $pid ), true ) ) {
							$acts->enroll( (int) $l['activity_id'], $pid, (string) $l['competence_month'] );
						}
					}
				}
				foreach ( $lines as $l ) {
					if ( ! empty( $l['session_id'] ) && ! $acts->has_active_booking( (int) $l['session_id'], $pid ) ) {
						$acts->book( (int) $l['session_id'], $pid, array( 'approved' => true ) ); // incasso dello staff: chi paga un evento senza prenotazione viene prenotato (se c'e posto)
					}
				}
				$ledger->record_receipt( array( 'date' => current_time( 'Y-m-d' ), 'account_id' => (int) ( $post['account_id'] ?? 0 ), 'method' => '', 'person_id' => $pid, 'check_due' => true, 'lines' => $lines ) );
			}
		);
		return 'Incasso registrato.';
	}

	/** Importo standard di una voce (quando il tesoriere lascia l'importo vuoto). */
	public static function standard_cents( string $kind, int $ref, ?array $person ): int {
		$type = $person ? (string) $person['type'] : MemberType::GUEST;
		if ( 'membership' === $kind ) {
			return \AssociazioneSemplice\Levels::fee_for( $person );
		}
		if ( 'event' === $kind ) {
			$s = Plugin::activities()->session( $ref );
			$a = $s ? Plugin::activities()->get( (int) $s['activity_id'] ) : null;
			if ( ! $a ) {
				return 0;
			}
			if ( $person && Plugin::activities()->has_active_booking( $ref, (int) $person['id'] ) ) {
				foreach ( Plugin::activities()->bookings_for_session( $ref ) as $row ) {
					if ( (int) $row['person_id'] === (int) $person['id'] ) {
						return (int) $row['remaining'];
					}
				}
			}
			return Plugin::activities()->fee_for( $a, $type );
		}
		$a = Plugin::activities()->get( $ref );
		return $a ? Plugin::activities()->fee_for( $a, $type ) : 0;
	}



	/** Registra (o annulla) l'ingresso di una persona prenotata: solo per chi gestisce l'evento (referente, gestori indicati, amministratori). */
	public static function do_checkin( array $post ): string {
		$sid     = (int) ( $post['session_id'] ?? 0 );
		$pid     = (int) ( $post['person_id'] ?? 0 );
		$session = Plugin::activities()->session( $sid );
		if ( ! $session ) {
			throw new \InvalidArgumentException( 'Questa data non c\'è più: ricarica la pagina.' );
		}
		self::require_cap( 'asem_manage_event', (int) $session['activity_id'] );
		$r = Plugin::activities()->check_in( $sid, $pid, ! empty( $post['undo'] ), current_user_can( Plugin::CAP_OPS ) );
		return self::checkin_message( $r, $sid, $pid );
	}


	/** Ingresso da QR scansionato: accetta l'indirizzo letto dal QR (o il solo codice). */
	public static function do_checkin_scan( array $post ): string {
		$raw = trim( (string) ( $post['ticket'] ?? '' ) );
		if ( false !== strpos( $raw, 'asem_ticket=' ) ) {
			parse_str( (string) wp_parse_url( $raw, PHP_URL_QUERY ), $q );
			$raw = (string) ( $q['asem_ticket'] ?? '' );
		}
		$t = CardToken::ticket_parse( $raw );
		if ( ! $t || ! CardToken::ticket_valid( $t[0], $t[1], $t[2], Settings::card_secret() ) ) {
			throw new \InvalidArgumentException( 'QR non valido: non è un biglietto di questo sito.' );
		}
		$session = Plugin::activities()->session( $t[0] );
		if ( ! $session ) {
			throw new \InvalidArgumentException( 'Questa prenotazione non c\'è più: ricarica la pagina.' );
		}
		self::require_cap( 'asem_manage_event', (int) $session['activity_id'] );
		return self::checkin_message( Plugin::activities()->check_in( $t[0], $t[1], false, current_user_can( Plugin::CAP_OPS ) ), $t[0], $t[1] );
	}

	/** Il socio vota: un solo voto per votazione, solo se ha diritto di voto (controllo in Polls). */
	public static function do_vote( array $post ): string {
		$actor   = self::actor();
		$choices = isset( $post['choice'] ) ? (array) $post['choice'] : array();
		\AssociazioneSemplice\Polls::vote( (int) ( $post['poll_id'] ?? 0 ), (int) $actor['id'], array_map( 'intval', $choices ) );
		return 'Voto registrato. Grazie.';
	}

	/** Avviso agli iscritti di un'attività: solo chi la tiene o chi gestisce l'evento (e gli amministratori). */
	public static function do_notice( array $post ): string {
		$aid = (int) ( $post['activity_id'] ?? 0 );
		if ( ! \AssociazioneSemplice\Notices::can_send( $aid ) ) {
			throw new \InvalidArgumentException( 'Non hai il permesso di inviare avvisi per questa attività.' );
		}
		\AssociazioneSemplice\Contacts::assert_can_write(); // invio manuale: servono i contatti della segreteria
		$r = \AssociazioneSemplice\Notices::send( $aid, ! empty( $post['session_id'] ) ? (int) $post['session_id'] : null, (string) ( $post['subject'] ?? '' ), (string) ( $post['body'] ?? '' ) );
		return 'Avviso inviato a ' . $r['recipients'] . ( 1 === $r['recipients'] ? ' persona' : ' persone' ) . ( $r['emailed'] < $r['recipients'] ? ' (' . ( $r['recipients'] - $r['emailed'] ) . ' email non inviate)' : '' ) . '.';
	}

	public static function do_add_guest( array $post ): string {
		if ( ! Settings::guests_enabled() ) {
			throw new \InvalidArgumentException( 'L\'associazione non prevede ospiti.' );
		}
		$actor = self::actor();
		self::require_cap( 'asem_add_guest', (int) $actor['id'] );
		$phone = (string) ( $post['phone'] ?? '' );
		// Nessun limite automatico: si evita solo il doppione evidente tra i propri ospiti e chi è già socio (il resto lo segnalano gli elenchi a chi gestisce).
		foreach ( Plugin::people()->find_by_phone( $phone ) as $h ) {
			if ( MemberType::is_member( $h['type'] ) ) {
				throw new \InvalidArgumentException( 'Non puoi aggiungere questo numero come ospite: scrivi alla segreteria.' ); // non si dice perché: nessuno può scoprire chi è socio provando dei numeri
			}
			if ( (int) $h['host_person_id'] === (int) $actor['id'] ) {
				throw new \InvalidArgumentException( 'Hai già questo ospite tra i tuoi.' );
			}
		}
		foreach ( Plugin::people()->guests_of( (int) $actor['id'] ) as $g ) {
			if ( \AssociazioneSemplice\Text::normalize( $g['first_name'] . $g['last_name'] ) === \AssociazioneSemplice\Text::normalize( ( $post['first_name'] ?? '' ) . ( $post['last_name'] ?? '' ) ) ) {
				throw new \InvalidArgumentException( 'Hai già questo ospite tra i tuoi.' );
			}
		}
		Plugin::people()->create(
			array(
				'type'           => MemberType::GUEST,
				'host_person_id' => (int) $actor['id'],
				'first_name'     => $post['first_name'] ?? '',
				'last_name'      => $post['last_name'] ?? '',
				'email'          => $post['email'] ?? '',
				'phone'          => $post['phone'] ?? '',
			)
		);
		return 'Ospite aggiunto.';
	}

	public static function do_profile( array $post ): string {
		$actor = self::actor();
		self::require_cap( 'asem_edit_own_profile', (int) $actor['id'] );
		$people = Plugin::people();
		$in     = array(
			'phone' => $post['phone'] ?? '', 'tax_code' => $post['tax_code'] ?? '', 'address' => $post['address'] ?? '', 'zip' => $post['zip'] ?? '',
			'city'  => $post['city'] ?? '', 'province' => $post['province'] ?? '',
		);
		$in['tax_code'] = \AssociazioneSemplice\TaxCode::normalize( (string) $in['tax_code'] );
		if ( '' !== $in['tax_code'] && ! \AssociazioneSemplice\TaxCode::is_valid( $in['tax_code'] ) ) {
			throw new \InvalidArgumentException( 'Il codice fiscale non è valido: controllalo (16 caratteri).' );
		}
		if ( '' !== (string) $in['zip'] && ! preg_match( '/^[0-9A-Za-z\- ]{3,12}$/', (string) $in['zip'] ) ) {
			throw new \InvalidArgumentException( 'Il CAP non è valido.' );
		}
		$people->update( (int) $actor['id'], $in );
		$fresh = $people->get( (int) $actor['id'] );
		if ( ! empty( $actor['profile_due'] ) && $fresh && $people->profile_complete( $fresh ) ) {
			$people->set_profile_due( (int) $actor['id'], false ); // dati completi: nessun blocco
			return 'Profilo completato: ora puoi prenotare e pagare.';
		}
		return 'Profilo aggiornato.';
	}
}
