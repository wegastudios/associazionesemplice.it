<?php
namespace AssociazioneSemplice;

use AssociazioneSemplice\Frontend\Shortcodes;

defined( 'ABSPATH' ) || exit;

/**
 * Le aree del sito: ogni vista (shortcode, blocco, widget) appartiene a un'area, così blocchi e widget si scelgono in ordine.
 *  - Soci: tessera, attività, pagamenti, ospiti, profilo;
 *  - Segreteria: il punto d'ingresso di chi lavora con la segreteria (anche presidente e vicepresidente);
 *  - Tesoriere: incassi, spese, iscrizioni e vendita eventi;
 *  - Eventi: gestione per il responsabile e lo staff (ingressi, avvisi, iscritti);
 *  - Pubblico: elenco attività, prossimi eventi, bonifico, donazioni, 5 per mille, accesso.
 */
final class Areas {

	/** Area => [titolo, viste]. */
	const BASE_GROUPS = array(
		'soci'       => array( 'Soci', array( 'area_soci', 'tessera', 'mie_attivita', 'pagamenti', 'regolamento', 'ospiti', 'minori', 'profilo', 'avvisi', 'calendario', 'votazioni', 'documenti_soci', 'convenzioni_soci' ) ),
		'segreteria' => array( 'Segreteria', array( 'segreteria' ) ),
		'tesoriere'  => array( 'Tesoriere', array( 'tesoriere' ) ),
		'eventi'     => array( 'Eventi', array( 'area_volontari', 'ingressi' ) ),
		'pubblico'   => array( 'Pubblico', array( 'attivita', 'prossimi_eventi', 'eventi', 'calendario_eventi', 'evento_locandina', 'evento_dati', 'evento_prenotazione', 'evento_dove', 'evento_navigazione', 'evento_condividi', 'bonifico', 'donazioni', 'privacy', 'adesione', 'documenti', 'convenzioni', 'accesso' ) ),
	);

	/** Le aree con le loro viste, comprese quelle di un'estensione (filtro `asem_areas`). */
	public static function groups(): array {
		return (array) apply_filters( 'asem_areas', self::BASE_GROUPS );
	}

	/** Viste che funzionano ma non si propongono più negli elenchi (nome vecchio di una vista). */
	const ALIASES = array( 'spese' => 'tesoriere' );

	public static function titles(): array {
		$out = array();
		foreach ( self::groups() as $key => $g ) {
			$out[ $key ] = $g[0];
		}
		return $out;
	}

	/** @return string|null chiave dell'area di una vista */
	public static function area_of( string $view ): ?string {
		$view = self::ALIASES[ $view ] ?? $view;
		foreach ( self::groups() as $key => $g ) {
			if ( in_array( $view, $g[1], true ) ) {
				return $key;
			}
		}
		return null;
	}

	/**
	 * Viste per blocchi e widget: slug => «Area · etichetta», in ordine per area.
	 *
	 * @return array<string,string>
	 */
	public static function options(): array {
		$out = array();
		foreach ( self::groups() as $g ) {
			foreach ( $g[1] as $view ) {
				if ( isset( Shortcodes::views()[ $view ] ) && Shortcodes::available( $view ) ) {
					$out[ $view ] = $g[0] . ' · ' . Shortcodes::views()[ $view ];
				}
			}
		}
		foreach ( self::ALIASES as $old => $new ) { // il nome precedente resta selezionabile, in fondo, per le pagine già fatte
			if ( isset( Shortcodes::views()[ $old ] ) && Shortcodes::available( $old ) ) {
				$out[ $old ] = ( self::groups()[ self::area_of( $old ) ][0] ?? '' ) . ' · ' . Shortcodes::views()[ $old ];
			}
		}
		return $out;
	}

	/** Viste dichiarate ma senza area: non devono esistere (controllato dai test). */
	public static function unassigned(): array {
		$out = array();
		foreach ( array_keys( Shortcodes::views() ) as $view ) {
			if ( null === self::area_of( $view ) ) {
				$out[] = $view;
			}
		}
		return $out;
	}
}
