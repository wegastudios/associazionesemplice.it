/* Associazione Semplice — front-end: conferme prima di annullare, e totale dei pagamenti online. */
(function () {
	'use strict';
	document.addEventListener('click', function (e) {
		var t = e.target && e.target.closest ? e.target.closest('[data-confirm]') : null;
		if (t && !window.confirm(t.getAttribute('data-confirm') || 'Confermi?')) {
			e.preventDefault();
		}
	});

	// Moduli che chiedono conferma all'invio (non al clic su un campo)
	document.addEventListener('submit', function (e) {
		var f = e.target;
		if (f && f.getAttribute && f.hasAttribute('data-asemf-confirm') && !window.confirm(f.getAttribute('data-asemf-confirm') || 'Confermi?')) {
			e.preventDefault();
		}
	});

	// Coordinate bancarie: pulsante «Copia» (negli appunti; se il browser non lo consente si seleziona il testo)
	document.addEventListener('click', function (e) {
		var b = e.target && e.target.closest ? e.target.closest('[data-asemf-copy]') : null;
		if (!b) { return; }
		var text = b.getAttribute('data-asemf-copy') || '';
		var done = function () { var old = b.textContent; b.textContent = 'Copiato'; setTimeout(function () { b.textContent = old; }, 1500); };
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(done, function () {});
			return;
		}
		var t = document.createElement('textarea'); t.value = text; t.setAttribute('readonly', ''); t.style.position = 'fixed'; t.style.opacity = '0';
		document.body.appendChild(t); t.select();
		try { document.execCommand('copy'); done(); } catch (err) {}
		document.body.removeChild(t);
	});

	function euro(cents) {
		return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(cents / 100);
	}
	function updateTotal(form) {
		var total = 0, any = false;
		form.querySelectorAll('input[type="checkbox"][data-cents]').forEach(function (c) {
			if (c.checked) { total += parseInt(c.getAttribute('data-cents'), 10) || 0; any = true; }
		});
		var gift = form.querySelector('input[type="checkbox"][data-donation]');
		if (gift && gift.checked) { // la donazione si somma al totale ma da sola non basta per pagare
			var g = form.querySelector('input[name="donation_amount"]');
			var v = g ? Math.round(parseFloat(String(g.value).replace(',', '.')) * 100) : 0;
			if (v >= 100 && v <= 100000) { total += v; }
		}
		var out = form.querySelector('.asemf-pay-total'); if (out) { out.textContent = euro(total); }
		form.querySelectorAll('button[type="submit"]').forEach(function (btn) { btn.disabled = !any; });
	}
	document.addEventListener('change', function (e) {
		var form = e.target && e.target.closest ? e.target.closest('.asemf-pay form') : null;
		if (form && e.target.matches('input[type="checkbox"][data-cents], input[type="checkbox"][data-donation], input[name="donation_amount"]')) { updateTotal(form); }
	});

	// Documenti del tesoriere: le foto si riducono sul telefono prima dell'invio (max 1600 px, JPEG).
	function shrink(file) {
		return new Promise(function (resolve) {
			if (!/^image\/(jpeg|png|webp)$/.test(file.type) || !window.createImageBitmap || !window.DataTransfer) { resolve(file); return; }
			window.createImageBitmap(file).then(function (bmp) {
				var scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
				if (scale === 1 && file.size < 1500000) { resolve(file); return; }
				var c = document.createElement('canvas');
				c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
				c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
				c.toBlob(function (blob) {
					if (!blob || blob.size >= file.size) { resolve(file); return; }
					resolve(new File([blob], file.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg', lastModified: Date.now() }));
				}, 'image/jpeg', 0.82);
			}).catch(function () { resolve(file); });
		});
	}
	document.addEventListener('change', function (e) {
		var input = e.target;
		if (!input.classList || !input.classList.contains('asem-doc-input') || !input.files || !input.files.length) { return; }
		Promise.all(Array.prototype.map.call(input.files, shrink)).then(function (files) {
			var dt = new DataTransfer();
			files.forEach(function (f) { dt.items.add(f); });
			input.files = dt.files;
			var box = input.closest('.asemf-docs'), info = box && box.querySelector('.asemf-doc-info');
			if (box && !info) { info = document.createElement('span'); info.className = 'asemf-doc-info asemf-small'; box.appendChild(info); }
			var n = 0;
			Array.prototype.forEach.call(input.form.querySelectorAll('.asem-doc-input'), function (i) { n += i.files.length; });
			if (info) { info.textContent = n + (n === 1 ? ' file pronto' : ' file pronti'); }
		});
	});

	// Ingressi agli eventi: ricerca e filtri sulla lista dei prenotati.
	function applyFilter(root) {
		var q = (root.querySelector('.asemf-search') || { value: '' }).value.toLowerCase().replace(/[^a-z0-9]/g, '');
		var chip = root.querySelector('.asemf-chip.is-on');
		var f = chip ? chip.getAttribute('data-filter') : 'all';
		root.querySelectorAll('.asemf-booked').forEach(function (li) {
			var ok = (f === 'all' || li.getAttribute('data-state') === f) && (q === '' || (li.getAttribute('data-name') || '').indexOf(q) !== -1);
			li.hidden = !ok;
		});
	}
	document.addEventListener('input', function (e) {
		var root = e.target && e.target.closest ? e.target.closest('.asemf-checkin') : null;
		if (root && e.target.classList.contains('asemf-search')) { applyFilter(root); }
	});
	document.addEventListener('click', function (e) {
		var chip = e.target && e.target.closest ? e.target.closest('.asemf-chip') : null;
		if (!chip) { return; }
		var root = chip.closest('.asemf-checkin');
		root.querySelectorAll('.asemf-chip').forEach(function (c) { c.classList.remove('is-on'); });
		chip.classList.add('is-on');
		applyFilter(root);
	});

	// Ingressi agli eventi: scansione del QR dal telefono (dove il browser sa leggere i QR; altrimenti basta la fotocamera del telefono).
	document.addEventListener('click', function (e) {
		var btn = e.target && e.target.closest ? e.target.closest('[data-asemf-scan]') : null;
		if (!btn) { return; }
		var box = btn.closest('.asemf-scan'), msg = box.querySelector('.asemf-scan-msg'), video = box.querySelector('.asemf-scan-video');
		if (!('BarcodeDetector' in window) || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
			msg.textContent = 'Questo browser non legge i QR da qui: apri la fotocamera del telefono e inquadra il QR del biglietto, poi tocca il link per registrare l\'ingresso.';
			return;
		}
		var detector = new window.BarcodeDetector({ formats: ['qr_code'] }), stream = null, timer = null;
		function stop() { if (timer) { clearInterval(timer); } if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); } video.hidden = true; }
		navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }).then(function (s) {
			stream = s; video.srcObject = s; video.hidden = false; video.play();
			msg.textContent = 'Inquadra il QR del biglietto…';
			timer = setInterval(function () {
				detector.detect(video).then(function (codes) {
					for (var i = 0; i < codes.length; i++) {
						if (String(codes[i].rawValue).indexOf('asem_ticket=') !== -1) {
							stop();
							var form = box.querySelector('.asemf-scan-form');
							form.querySelector('input[name="ticket"]').value = codes[i].rawValue;
							form.submit();
							return;
						}
					}
				}).catch(function () {});
			}, 300);
		}).catch(function () { msg.textContent = 'Impossibile aprire la fotocamera: controlla il permesso del browser.'; });
	});
})();

/* Stampa della tessera: si stampa solo la tessera (il resto della pagina resta nascosto dallo stile di stampa) */
(function () {
	document.addEventListener('click', function (e) {
		var b = e.target && e.target.closest ? e.target.closest('.asemf-print-card') : null;
		if (!b) { return; }
		e.preventDefault();
		document.body.classList.add('asemf-printing');
		var done = function () { document.body.classList.remove('asemf-printing'); window.removeEventListener('afterprint', done); };
		window.addEventListener('afterprint', done);
		window.print();
	});
})();

/* Incasso crediti: lo schermo dello staff con il QR si aggiorna da solo quando il socio paga */
(function () {
	var box = document.querySelector('[data-asemf-credit-poll]');
	if (!box || !window.fetch) { return; }
	var url = box.getAttribute('data-url'), out = box.querySelector('.asemf-credit-status');
	function tick() {
		fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
			out.textContent = d.message;
			box.setAttribute('data-state', d.state);
			if (d.state === 'ok') { setTimeout(tick, 2000); }
		}).catch(function () { setTimeout(tick, 4000); });
	}
	if (box.getAttribute('data-state') === 'ok') { setTimeout(tick, 2000); }
})();

/* Domanda di adesione: chi ha meno di 18 anni indica anche il genitore o tutore (il blocco compare solo in quel caso). */
(function () {
	'use strict';
	function adult(birth) {
		var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(birth || '');
		if (!m) { return null; }
		var now = new Date(), age = now.getFullYear() - parseInt(m[1], 10);
		if (now.getMonth() + 1 < parseInt(m[2], 10) || (now.getMonth() + 1 === parseInt(m[2], 10) && now.getDate() < parseInt(m[3], 10))) { age--; }
		return age >= 18;
	}
	function sync(form) {
		var box = form.querySelector('[data-asemf-guardian]'), birth = form.querySelector('[data-asemf-birth]');
		if (!box || !birth) { return; }
		var a = adult(birth.value);
		box.hidden = a !== false; // nascosto finché non si scrive una data da cui risulta un minore
		form.querySelectorAll('[data-asemf-adult-required]').forEach(function (i) { i.required = (a === true); }); // chi ha 18 anni o più deve dare email e cellulare, per un minore bastano quelli del genitore
	}
	document.addEventListener('change', function (e) {
		var form = e.target && e.target.closest ? e.target.closest('.asemf-apply form') : null;
		if (form && e.target.matches('[data-asemf-birth]')) { sync(form); }
	});
	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('.asemf-apply form').forEach(sync);
	});
})();

// Barra di salto dell'area soci: sta sotto l'intestazione fissa del tema (se c'è), altrimenti in cima.
(function () {
	'use strict';
	var bar = document.querySelector('.asemf-jump');
	if (!bar) { return; }
	function headerBottom() {
		var el = document.elementFromPoint(Math.round(window.innerWidth / 2), 2);
		while (el && el !== document.body && el !== document.documentElement) {
			if (!bar.contains(el)) {
				var pos = window.getComputedStyle(el).position;
				if (pos === 'fixed' || pos === 'sticky') { return Math.max(0, Math.round(el.getBoundingClientRect().bottom)); }
			}
			el = el.parentElement;
		}
		return 0;
	}
	var busy = false;
	function place() {
		busy = false;
		var off = headerBottom();
		bar.style.top = off + 'px';
		document.documentElement.style.setProperty('--asemf-off', (off + bar.offsetHeight) + 'px');
	}
	function ask() { if (!busy) { busy = true; window.requestAnimationFrame(place); } }
	window.addEventListener('scroll', ask, { passive: true });
	window.addEventListener('resize', ask);
	window.addEventListener('load', ask);
	ask();
})();

/* Area soci da telefono: le sezioni richiudibili partono chiuse, tranne la prima; da computer restano tutte aperte. La barra in basso apre la sezione scelta. */
(function () {
	'use strict';
	function init() {
		var all = document.querySelectorAll('.asemf-collapse');
		if (!all.length) { return; }
		if (window.matchMedia && window.matchMedia('(max-width: 700px)').matches) {
			all.forEach(function (d, i) { if (i > 0) { d.removeAttribute('open'); } });
		}
	}
	document.addEventListener('click', function (e) {
		var a = e.target && e.target.closest ? e.target.closest('.asemf-jump a[href^="#"]') : null;
		var t = a ? document.getElementById(a.getAttribute('href').slice(1)) : null;
		var d = t ? t.querySelector('.asemf-collapse') : null;
		if (d) { d.setAttribute('open', ''); }
	});
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
