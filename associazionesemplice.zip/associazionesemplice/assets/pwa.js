/* Associazione Semplice — app installabile e notifiche (nessuna dipendenza). */
(function () {
	'use strict';
	var C = window.ASEM_PWA || {};
	var deferred = null;

	function $$(s) { return Array.prototype.slice.call(document.querySelectorAll(s)); }

	function b64uToBytes(s) {
		var pad = '='.repeat((4 - s.length % 4) % 4);
		var raw = atob((s + pad).replace(/-/g, '+').replace(/_/g, '/'));
		var out = new Uint8Array(raw.length);
		for (var i = 0; i < raw.length; i++) { out[i] = raw.charCodeAt(i); }
		return out;
	}
	function bytesToB64u(buf) {
		var b = new Uint8Array(buf), s = '';
		for (var i = 0; i < b.length; i++) { s += String.fromCharCode(b[i]); }
		return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
	}

	if ('serviceWorker' in navigator && C.sw) {
		window.addEventListener('load', function () {
			navigator.serviceWorker.register(C.sw, { scope: C.scope || '/' }).catch(function () {});
		});
	}

	/* Installa l'app */
	window.addEventListener('beforeinstallprompt', function (e) {
		e.preventDefault();
		deferred = e;
		$$('[data-asem-install]').forEach(function (b) { b.hidden = false; });
	});
	window.addEventListener('appinstalled', function () {
		deferred = null;
		$$('[data-asem-install]').forEach(function (b) { b.hidden = true; });
	});
	document.addEventListener('click', function (e) {
		var b = e.target.closest ? e.target.closest('[data-asem-install]') : null;
		if (!b || !deferred) { return; }
		var d = deferred;
		d.prompt();
		deferred = null;
		b.hidden = true;
		/* Se il sistema viene chiuso senza installare, l'invito sotto la tessera sparisce (come con «Non ora»). */
		if (d.userChoice && d.userChoice.then) {
			d.userChoice.then(function (r) {
				if (r && 'accepted' !== r.outcome) {
					$$('[data-asem-tip]').forEach(function (t) { t.hidden = true; });
					try { window.localStorage.setItem('asemTipClosed', String(Date.now())); } catch (er) {}
				}
			});
		}
	});
	var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone;
	$$('[data-asem-ios]').forEach(function (n) {
		var ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
		n.hidden = !(ios && !standalone);
	});

	/* Notifiche */
	function post(action, data) {
		var f = new FormData();
		f.append('action', action);
		f.append('nonce', C.nonce || '');
		Object.keys(data).forEach(function (k) { f.append(k, data[k]); });
		return fetch(C.ajax, { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json(); });
	}
	function say(box, text) { var m = box.querySelector('[data-asem-push-msg]'); if (m) { m.textContent = text; } }

	function init(box) {
		var on = box.querySelector('[data-asem-push-on]'), off = box.querySelector('[data-asem-push-off]');
		if (!C.push || !C.vapid || !('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
			box.querySelectorAll('[data-asem-push-on],[data-asem-push-off]').forEach(function (b) { b.hidden = true; });
			say(box, 'Questo dispositivo o browser non supporta le notifiche' + ((/iphone|ipad|ipod/i.test(navigator.userAgent) && !standalone) ? ': su iPhone aggiungi prima l\'app alla schermata Home.' : '.'));
			return;
		}
		function refresh() {
			navigator.serviceWorker.ready.then(function (reg) { return reg.pushManager.getSubscription(); }).then(function (sub) {
				if (on) { on.hidden = !!sub; }
				if (off) { off.hidden = !sub; }
				say(box, sub ? 'Le notifiche sono attive su questo dispositivo.' : (Notification.permission === 'denied' ? 'Le notifiche sono bloccate nelle impostazioni del browser.' : ''));
			});
		}
		if (on) {
			on.addEventListener('click', function () {
				Notification.requestPermission().then(function (perm) {
					if (perm !== 'granted') { say(box, 'Permesso negato: puoi cambiarlo dalle impostazioni del browser.'); return null; }
					return navigator.serviceWorker.ready.then(function (reg) {
						return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64uToBytes(C.vapid) });
					}).then(function (sub) {
						var j = sub.toJSON();
						return post('asem_push_subscribe', { endpoint: j.endpoint, p256dh: (j.keys || {}).p256dh || '', auth: (j.keys || {}).auth || '' }).then(function (r) {
							if (!r.success) { sub.unsubscribe(); say(box, (r.data && r.data.message) || 'Non è stato possibile attivare le notifiche.'); }
							refresh();
						});
					});
				}).catch(function () { say(box, 'Non è stato possibile attivare le notifiche.'); });
			});
		}
		if (off) {
			off.addEventListener('click', function () {
				navigator.serviceWorker.ready.then(function (reg) { return reg.pushManager.getSubscription(); }).then(function (sub) {
					if (!sub) { refresh(); return; }
					var ep = sub.endpoint;
					return sub.unsubscribe().then(function () { return post('asem_push_unsubscribe', { endpoint: ep }); }).then(refresh);
				});
			});
		}
		refresh();
	}
	$$('[data-asem-push]').forEach(init);
})();

/* Invito a installare l'app sotto la tessera: solo se si può installare (o su iPhone), mai nell'app già installata, e per 30 giorni dopo «Non ora». */
(function () {
	var tips = document.querySelectorAll('[data-asem-tip]');
	if (!tips.length) { return; }
	var KEY = 'asemTipClosed', now = Date.now();
	var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone;
	var closed = 0;
	try { closed = parseInt(window.localStorage.getItem(KEY) || '0', 10); } catch (e) {}
	if (standalone || (closed && now - closed < 30 * 864e5)) { return; }
	var ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
	function show() {
		tips.forEach(function (t) {
			t.hidden = false;
			var a = t.querySelector('[data-asem-tip-android]'), i = t.querySelector('[data-asem-tip-ios]');
			if (a) { a.hidden = ios; }
			if (i) { i.hidden = !ios; }
		});
	}
	if (ios) { show(); }
	window.addEventListener('beforeinstallprompt', show);
	window.addEventListener('appinstalled', function () { tips.forEach(function (t) { t.hidden = true; }); });
	document.addEventListener('click', function (e) {
		var c = e.target.closest ? e.target.closest('[data-asem-tip-close]') : null;
		if (!c) { return; }
		tips.forEach(function (t) { t.hidden = true; });
		try { window.localStorage.setItem(KEY, String(now)); } catch (er) {}
	});
}());
