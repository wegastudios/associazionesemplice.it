<?php
namespace AssociazioneSemplice\Frontend;

use AssociazioneSemplice\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Ritorno del socio dalla pagina di pagamento di Stripe/PayPal: il sito verifica il pagamento DIRETTAMENTE col gateway
 * (non si fida dei parametri dell'indirizzo) e poi riporta il socio alla pagina con l'esito.
 */
final class PayReturn {

	const PARAMS = array( 'asem_pay', 'asem_ret', 'token', 'PayerID', 'paymentId', 'asemf_ok', 'asemf_err', 'asemf_sig' );

	public static function register(): void {
		add_action( 'template_redirect', array( __CLASS__, 'handle' ), 1 );
	}

	public static function handle(): void {
		if ( ! isset( $_GET['asem_pay'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$public = sanitize_text_field( wp_unslash( $_GET['asem_pay'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$ret    = isset( $_GET['asem_ret'] ) && 'ok' === sanitize_key( wp_unslash( $_GET['asem_ret'] ) ) ? 'ok' : 'cancel'; // phpcs:ignore WordPress.Security.NonceVerification
		$url    = Restrict::current_url();
		$engine = \AssociazioneSemplice\PaymentService::engine();
		$known  = $engine->get_by_public( $public );
		if ( $known && 0 === (int) $known['payer_user_id'] ) { // quota di una domanda di adesione: chi paga non ha ancora un accesso, il codice del pagamento è il suo lasciapassare
			$clean = remove_query_arg( self::PARAMS, $url );
			try {
				wp_safe_redirect( \AssociazioneSemplice\Flash::url( $clean, 'asemf', $engine->handle_return( $public, $ret, 0 ) ) );
			} catch ( \Throwable $e ) {
				wp_safe_redirect( \AssociazioneSemplice\Flash::url( $clean, 'asemf', '', 'Non è stato possibile verificare il pagamento. Se hai pagato, lo registreremo appena Stripe o PayPal lo confermano.' ) );
			}
			exit;
		}
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $url ) ); // dopo l'accesso si torna qui e il pagamento viene verificato
			exit;
		}
		$clean = remove_query_arg( self::PARAMS, $url );
		try {
			$msg = \AssociazioneSemplice\PaymentService::engine()->handle_return( $public, $ret, get_current_user_id() );
			wp_safe_redirect( \AssociazioneSemplice\Flash::url( $clean, 'asemf', $msg ) );
		} catch ( \InvalidArgumentException $e ) {
			wp_safe_redirect( \AssociazioneSemplice\Flash::url( $clean, 'asemf', '', $e->getMessage() ) );
		} catch ( \Throwable $e ) {
			wp_safe_redirect( \AssociazioneSemplice\Flash::url( $clean, 'asemf', '', 'Non è stato possibile verificare il pagamento. Se hai pagato, lo registreremo appena Stripe o PayPal lo confermano.' ) );
		}
		exit;
	}
}
