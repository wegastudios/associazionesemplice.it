<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/**
 * Quali funzioni esistono in questa installazione.
 *
 * Il plugin gratuito contiene il nucleo; le funzioni avanzate stanno nel plugin Associazione Semplice Pro, che aggiunge la propria cartella con
 * {@see Edition::add_dir()}. Una funzione c'è se il suo file di riferimento si trova in una delle cartelle: niente interruttori, niente
 * chiavi, niente codice «spento». Il resto del plugin chiede `Edition::has( 'payments' )` prima di mostrare o usare una funzione avanzata.
 */
final class Edition {

	/** Funzione => file (dentro includes/) che la contiene. */
	const FEATURES = array(
		'license'    => 'License.php',             // verifica della licenza (nel gratuito: chiave gratuita e servizi collegati)
		'vat'        => 'Admin/VatFields.php',     // IVA: campi nei moduli e impostazioni fiscali
		'levels'     => 'Admin/LevelsEditor.php',  // più livelli di socio, ognuno con la sua quota
		'payments'   => 'PaymentService.php',      // pagamenti online
		'funds'      => 'Admin/AccountsPage.php',  // conti multipli, giroconti, fondi e cassa per più persone
		'reports'    => 'Admin/ReportsPage.php',   // report di gestione (saldi, attività)
		'fiscal'     => 'Admin/YearsPage.php',     // anni solari, contabilità e rendiconto per il commercialista
		'fivepm'     => 'FivePerMille.php',        // 5 per mille
		'insurance'  => 'Insurance.php',           // assicurazioni e presenze
		'broadcasts' => 'Broadcasts.php',          // comunicazioni di massa
		'pwa'        => 'Pwa.php',                 // app installabile e notifiche
		'wallet'     => 'Wallet.php',              // tessera in Apple e Google Wallet
		'receipts'   => 'Receipts.php',            // ricevute PDF
		'door_sales' => 'DoorSales.php',           // incasso sul posto
		'resources'  => 'Resources.php',           // risorse prenotabili: campi, sale, posti auto, armadietti, posti barca
		'texts'      => 'TextsEngine.php',         // personalizzazione dei testi, lingue, tipo di ente e termini
	);

	/** Pagine di amministrazione di ogni funzione avanzata: se la funzione non c'è, spariscono dal menu e dalle schede. */
	const PAGES = array(
		'payments'   => array( 'asem-payments' ),
		'funds'      => array( 'asem-accounts', 'asem-transfer', 'asem-group' ),
		'reports'    => array( 'asem-reports' ),
		'fiscal'     => array( 'asem-accounting', 'asem-years', 'asem-statement', 'asem-acct' ),
		'fivepm'     => array( 'asem-fivepm' ),
		'insurance'  => array( 'asem-volunteers', 'asem-attendance' ),
		'broadcasts' => array( 'asem-messages' ),
		'pwa'        => array( 'asem-app' ),
		'texts'      => array( 'asem-texts' ),
		'resources'  => array( 'asem-resources', 'asem-resource' ),
	);

	/** @return string[] pagine di amministrazione delle funzioni che questa installazione non ha */
	public static function missing_pages(): array {
		$out = array();
		foreach ( self::PAGES as $feature => $pages ) {
			if ( ! self::has( $feature ) ) {
				$out = array_merge( $out, $pages );
			}
		}
		return $out;
	}

	/** @var string[] cartelle (con la barra finale) in cui cercare i file: la prima è quella di questo plugin */
	private static $dirs = array();

	/** @return string[] */
	public static function dirs(): array {
		if ( ! self::$dirs ) {
			self::$dirs = array( ASEM_DIR . 'includes/' );
		}
		return self::$dirs;
	}

	/** @var string livello di compatibilità di Associazione Semplice Pro rifiutato perché diverso da quello di Associazione Semplice ('' = nessun problema) */
	private static $mismatch = '';

	/**
	 * Associazione Semplice e Associazione Semplice Pro hanno versioni indipendenti (si aggiorna uno o l'altro, in qualunque ordine); si parlano finché hanno lo
	 * stesso «livello di compatibilità», un numero che cambia solo quando cambia ciò che si scambiano.
	 */
	public static function compatible( int $pro_api, int $free_api ): bool {
		return $pro_api === $free_api;
	}

	/** Il livello di compatibilità di Associazione Semplice Pro rifiutato perché non corrisponde (vuoto se tutto a posto). */
	public static function mismatch(): string {
		return self::$mismatch;
	}

	/** Il plugin Pro dichiara qui la propria cartella `includes/`. Se il suo livello di compatibilità non è quello di Associazione Semplice non si carica niente. */
	public static function add_dir( string $dir ): void {
		if ( defined( 'ASEM_PRO_API' ) && defined( 'ASEM_API' ) && ! self::compatible( (int) ASEM_PRO_API, (int) ASEM_API ) ) {
			self::$mismatch = (string) ASEM_PRO_API;
			return;
		}
		$dir = rtrim( $dir, '/\\' ) . '/';
		if ( ! in_array( $dir, self::dirs(), true ) ) {
			self::$dirs[] = $dir;
			self::$found  = array();
		}
	}

	/** Percorso del file di una classe (null se non esiste in nessuna cartella). */
	public static function locate( string $relative ): ?string {
		foreach ( self::dirs() as $d ) {
			if ( is_readable( $d . $relative ) ) {
				return $d . $relative;
			}
		}
		return null;
	}

	/** Il file della funzione c'è, a prescindere dalla licenza? */
	public static function installed( string $feature ): bool {
		if ( ! isset( self::FEATURES[ $feature ] ) ) {
			return false;
		}
		if ( ! isset( self::$found[ $feature ] ) ) { // il disco si interroga una volta sola per funzione e per richiesta
			self::$found[ $feature ] = null !== self::locate( self::FEATURES[ $feature ] );
		}
		return self::$found[ $feature ];
	}

	/** @var array<string,bool> funzioni già cercate sul disco (si svuota quando cambiano le cartelle) */
	private static $found = array();

	/** Con Associazione Semplice Pro presente ma la licenza non in regola il plugin torna alle funzioni di base. */
	public static function degraded(): bool {
		return self::installed( 'license' ) && function_exists( 'get_option' ) && method_exists( License::class, 'degraded' ) && License::degraded();
	}

	/**
	 * La funzione avanzata si può usare? C'è nella cartella e, se c'è il sistema di licenza, la licenza è in regola. Con la licenza scaduta
	 * tutte le funzioni avanzate spariscono e resta il comportamento dell'edizione gratuita; la licenza stessa si può sempre correggere.
	 */
	public static function has( string $feature ): bool {
		return self::installed( $feature ) && ( 'license' === $feature || ( ! self::degraded() && ! self::plan_blocks( $feature ) ) );
	}

	/** Funzioni fiscali: solo con la licenza Pro Full (IVA, 5 per mille, anni solari e rendiconto; più avanti la fatturazione elettronica). */
	const FISCAL = array( 'vat', 'fivepm', 'fiscal' );

	/** Funzioni di contabilità: conti e fondi, report, ricevute. Mancano nel Pro Lite; ci sono nel Pro Full e nel vecchio livello contabile. */
	const ACCOUNTING = array( 'funds', 'reports', 'receipts' );

	/** Il plugin Pro è presente (c'è almeno una sua funzione)? Solo allora una licenza non in regola sospende qualcosa. */
	public static function pro_present(): bool {
		return self::installed( 'payments' );
	}

	/**
	 * Il livello della licenza esclude questa funzione? Pro Full: nessuna esclusione; contabile: le funzioni fiscali; Pro Lite: fiscali e di contabilità;
	 * licenza gratuita (o nessuna chiave con la verifica attiva): tutte le funzioni Pro. Senza verifica attiva (standby) tutto è disponibile.
	 */
	public static function plan_blocks( string $feature ): bool {
		if ( 'license' === $feature || ! self::installed( 'license' ) || ! function_exists( 'get_option' ) || ! method_exists( License::class, 'plan' ) ) {
			return false;
		}
		switch ( License::plan() ) {
			case License::PLAN_FREE:
				return true;
			case License::PLAN_LITE:
				return in_array( $feature, self::FISCAL, true ) || in_array( $feature, self::ACCOUNTING, true );
			case License::PLAN_ACCOUNTING:
				return in_array( $feature, self::FISCAL, true );
		}
		return false;
	}

	/**
	 * Le funzioni di base non dipendono più dalla licenza: tutto ciò che c'è si può usare. Resta per i controlli già scritti.
	 */
	public static function allows( string $feature ): bool {
		return true;
	}

	/** Perché una funzione avanzata non è disponibile (da mostrare a chi prova a usarla). */
	public static function missing_message( string $feature = '' ): string {
		if ( '' !== $feature && self::installed( $feature ) && ! self::degraded() && self::plan_blocks( $feature ) ) {
			switch ( License::plan() ) {
				case License::PLAN_FREE:
					return LicensePolicy::STATUS_NOKEY === License::state()['status']
						? 'Questa funzione fa parte di Associazione Semplice Pro: inserisci la chiave di licenza in Impostazioni per usarla.'
						: 'Questa funzione fa parte di Associazione Semplice Pro (Lite o Full): la tua è la licenza gratuita.';
				case License::PLAN_LITE:
					return 'Questa funzione fa parte della licenza Associazione Semplice Pro Full: la tua licenza è Pro Lite, senza la parte contabile.';
			}
			return 'Questa funzione fa parte della licenza Associazione Semplice Pro Fiscale: la tua licenza è di livello contabile.';
		}
		if ( self::degraded() ) {
			return 'La licenza di Associazione Semplice Pro non è in regola: questa funzione è sospesa. Regolarizza la licenza e torna disponibile; intanto resta tutto il resto, con i tuoi dati.';
		}
		return 'Questa funzione fa parte di Associazione Semplice Pro e non è inclusa in questa edizione.';
	}

	/** Indirizzo del sito dove si presenta e si acquista Associazione Semplice Pro (modificabile con il filtro `asem_pro_url`). */
	public static function pro_url(): string {
		return (string) apply_filters( 'asem_pro_url', 'https://associazionesemplice.it' );
	}

	/** Come {@see Edition::missing_message()}, con il collegamento per regolarizzare quando la licenza è scaduta (HTML già pronto). */
	public static function missing_html(): string {
		$html = '<p>' . esc_html( self::missing_message() ) . '</p>';
		if ( ! self::degraded() && function_exists( 'admin_url' ) ) {
			$html .= '<p><a href="' . esc_url( admin_url( 'admin.php?page=asem-pro' ) ) . '">Scopri cosa comprende Associazione Semplice Pro →</a></p>';
		}
		if ( self::degraded() ) {
			$url   = License::payment_url();
			$html .= $url
				? '<p><a class="button button-primary" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">Regolarizza la licenza</a></p>'
				: '<p>Contatta il fornitore del servizio per regolarizzare la licenza, poi inseriscila in Impostazioni → Soci e quote.</p>';
		}
		return $html;
	}

	/** Azione di una funzione avanzata che non c'è (o è sospesa): chi ci arriva legge perché, invece di una pagina vuota. */
	public static function block_action( string $action ): void {
		add_action(
			'admin_post_' . $action,
			function () {
				wp_die( self::missing_html(), 'Funzione non disponibile', array( 'response' => 403, 'back_link' => true ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
		);
	}
}
